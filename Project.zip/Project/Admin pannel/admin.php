<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}


$host = "localhost";
$user = "root";
$pass = "";
$db = "mechano";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$customerCount = $conn->query("SELECT COUNT(*) as total FROM customers")->fetch_assoc()['total'];
$mechanicCount = $conn->query("SELECT COUNT(*) as total FROM mechanic")->fetch_assoc()['total'];
$vehicleCount = $conn->query("SELECT COUNT(*) as total FROM vehical")->fetch_assoc()['total'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Mechano Dashboard</title>
  <link rel="icon" type="image/jpeg" href="uploads/icon.jpg">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
  <style>
    body {
      margin: 0;
      background-color: #121212;
      color: #fff;
      font-family: Arial, sans-serif;
    }
    .navbar {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      background-color: #000;
      padding: 15px 20px;
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 1001;
    }
    .brand {
      color: #ff6f00;
      font-size: 35px;
      font-weight: bold;
      margin-left: 10px;
    }
    .menu-btn {
      font-size: 24px;
      color: #ff6f00;
      background: none;
      border: none;
      cursor: pointer;
    }
    .main {
      margin-top: 70px;
      padding: 20px;
    }
    .card-container {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
      margin-top: 40px;
    }
    .card {
      background-color: #1e1e1e;
      padding: 20px;
      border-radius: 12px;
      text-align: center;
      width: 200px;
      box-shadow: 0 0 10px rgba(255, 111, 0, 0.4);
      cursor: pointer;
      text-decoration: none;
      color: inherit;
    }
    .card:hover {
      background-color: #ff6f00;
      color: #000;
    }
    .card i {
      font-size: 50px;
      color:rgb(255, 255, 255);
      margin-bottom: 10px;
    }
    .card h2 {
      font-size: 40px;
      margin: 10px 0;
    }
    .card p {
      margin: 0;
      font-size: 18px;
      color: #aaa;
    }
  </style>
</head>
<body>

<?php include 'sidebar.php';?>
<div class="main">
 <h1>
    <span style="color: white;">Welcome </span>
    <span style="color: #ff6f00;">Admin!</span>
</h1>

  <hr style="margin: 30px 0; border-color: #444;">
  <div class="card-container">
    <a href="customer_tab.php" class="card">
      <i class="fas fa-user-friends"></i>
      <h2 class="count" data-count="<?php echo $customerCount; ?>">0</h2>
      <p>Customers</p>
    </a>
    <a href="mechanic_tab.php" class="card">
      <i class="fas fa-tools"></i>
      <h2 class="count" data-count="<?php echo $mechanicCount; ?>">0</h2>
      <p>Mechanics</p>
    </a>
    <a href="vehical_tab.php" class="card">
      <i class="fas fa-car"></i>
      <h2 class="count" data-count="<?php echo $vehicleCount; ?>">0</h2>
      <p>Vehicles</p>
    </a>
  </div>
</div>

<script>
  // Animate counters
  const counters = document.querySelectorAll('.count');
  counters.forEach(counter => {
    const updateCount = () => {
      const target = +counter.getAttribute('data-count');
      const count = +counter.innerText;
      const increment = Math.ceil(target / 50);
      if (count < target) {
        counter.innerText = count + increment > target ? target : count + increment;
        setTimeout(updateCount, 20);
      } else {
        counter.innerText = target;
      }
    };
    updateCount();
  });
</script>

</body>
</html>