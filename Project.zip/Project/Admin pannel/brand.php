<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}
?>

<?php
include 'config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$success = "";
$error = "";

// AJAX handler: fetch categories by vehicle type id
if (isset($_POST['ajax']) && $_POST['ajax'] === 'fetch_categories' && isset($_POST['vehical_type_id'])) {
    $vehical_type_id = intval($_POST['vehical_type_id']);
    // Get vehicle type name
    $stmt = $conn->prepare("SELECT vehical_type FROM vehical_type WHERE id = ?");
    $stmt->bind_param("i", $vehical_type_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $categories = [];
    if ($row = $result->fetch_assoc()) {
        $vehical_type_name = $row['vehical_type'];
        $stmt->close();

        // Fetch categories matching this vehicle type
        $stmt2 = $conn->prepare("SELECT id, category_name FROM vehicle_category WHERE vehical_type = ?");
        $stmt2->bind_param("s", $vehical_type_name);
        $stmt2->execute();
        $result2 = $stmt2->get_result();
        while ($cat = $result2->fetch_assoc()) {
            $categories[] = $cat;
        }
        $stmt2->close();
    } else {
        $stmt->close();
    }

    header('Content-Type: application/json');
    echo json_encode($categories);
    exit;
}

// Fetch vehicle types for dropdown
$vehicalTypes = [];
$res = $conn->query("SELECT id, vehical_type FROM vehical_type");
while ($row = $res->fetch_assoc()) {
    $vehicalTypes[] = $row;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['ajax'])) {
    $vehical_type_id = intval($_POST['vehical_type_id'] ?? 0);
    $vehicle_category_id = intval($_POST['vehicle_category_id'] ?? 0);
    $brand_name_input = trim($_POST['brand_name'] ?? '');
    $brand_name = ucwords(strtolower($brand_name_input));

    if ($vehical_type_id === 0 || $vehicle_category_id === 0 || $brand_name === '') {
        $error = "Please select vehicle type, category, and enter brand name.";
    } else {
        // Get vehicle type name
        $stmt = $conn->prepare("SELECT vehical_type FROM vehical_type WHERE id = ?");
        $stmt->bind_param("i", $vehical_type_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $vehical_type_name = $row['vehical_type'];
            $stmt->close();

            // Get category name and validate
            $stmt = $conn->prepare("SELECT category_name FROM vehicle_category WHERE id = ? AND vehical_type = ?");
            $stmt->bind_param("is", $vehicle_category_id, $vehical_type_name);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($cat_row = $result->fetch_assoc()) {
                $category_name = $cat_row['category_name'];
                $stmt->close();

                // Check duplicate brand for same vehical_type and vehicle_category (case insensitive)
                $stmt = $conn->prepare("SELECT id FROM brand WHERE LOWER(brand_name) = LOWER(?) AND vehical_type = ? AND vehicle_category = ?");
                $stmt->bind_param("sss", $brand_name, $vehical_type_name, $category_name);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    $error = "Brand '$brand_name' already exists for vehicle type '$vehical_type_name' and category '$category_name'.";
                    $stmt->close();
                } else {
                    $stmt->close();

                    // Insert new brand
                    $stmt = $conn->prepare("INSERT INTO brand (brand_name, vehical_type, vehicle_category) VALUES (?, ?, ?)");
                    $stmt->bind_param("sss", $brand_name, $vehical_type_name, $category_name);
                    if ($stmt->execute()) {
                        $success = "Brand '$brand_name' added successfully for vehicle type '$vehical_type_name' and category '$category_name'.";
                        $brand_name_input = '';
                    } else {
                        $error = "Failed to add brand: " . $stmt->error;
                    }
                    $stmt->close();
                }
            } else {
                $stmt->close();
                $error = "Invalid vehicle category selected.";
            }
        } else {
            $stmt->close();
            $error = "Invalid vehicle type selected.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Add Brand</title>
<link rel="icon" type="image/jpeg" href="uploads/icon.jpg" />
<style>
    body {
        background: #121212;
        color: #ddd;
        font-family: Arial, sans-serif;
        padding: 20px;
    }
    .add-customer-form select, .add-customer-form input[type=text] {
        width: 70%;
        padding: 12px;
        margin-bottom: 20px;
        border: 1px solid #ff6f00;
        border-radius: 6px;
        background: #1e1e1e;
        color: #fff;
        font-size: 16px;
    }
    .add-customer-form input::placeholder {
        color: #bbb;
    }
    .add-customer-form button {
        width: 20%;
        padding: 12px;
        background: #ff6f00;
        color: #000;
        border: none;
        border-radius: 6px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
    }
    .add-customer-form button:hover {
        background: #ff8c00;
    }
    .success-msg {
        margin-top: 10px;
        font-size: 15px;
        color: rgb(84, 251, 170);
    }
    .error-msg {
        margin-top: 10px;
        font-size: 15px;
        color: red;
    }
</style>
<script>
function loadCategories(vehicleTypeId) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                var categories = JSON.parse(xhr.responseText);
                var categorySelect = document.getElementById("vehicle_category_id");
                categorySelect.innerHTML = '<option value="">Select Vehicle Category</option>';
                categories.forEach(function(cat){
                    var option = document.createElement("option");
                    option.value = cat.id;
                    option.text = cat.category_name;
                    categorySelect.appendChild(option);
                });

                // Restore previously selected category if exists
                <?php if (isset($_POST['vehicle_category_id'])): ?>
                    categorySelect.value = "<?php echo intval($_POST['vehicle_category_id']); ?>";
                <?php endif; ?>
            } catch(e) {
                console.error("Error parsing categories JSON", e);
            }
        }
    };
    xhr.send("ajax=fetch_categories&vehical_type_id=" + vehicleTypeId);
}

window.onload = function() {
    var vehicleTypeSelect = document.getElementById("vehical_type_id");
    vehicleTypeSelect.addEventListener("change", function(){
        var val = this.value;
        if (val) {
            loadCategories(val);
        } else {
            document.getElementById("vehicle_category_id").innerHTML = '<option value="">Select Vehicle Category</option>';
        }
    });

    // Load categories if vehicle type preselected (for repopulating after submit)
    <?php if (isset($_POST['vehical_type_id']) && intval($_POST['vehical_type_id']) > 0): ?>
        loadCategories(<?php echo intval($_POST['vehical_type_id']); ?>);
    <?php endif; ?>
};
</script>
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main">
    <h1>Welcome to Mechano</h1>
    <hr style="margin: 30px 0; border-color: #444;">
    <h2>Add Brand</h2>

    <form method="POST" class="add-customer-form" autocomplete="off">
        <select id="vehical_type_id" name="vehical_type_id" required>
            <option value="">Select Vehicle Type</option>
            <?php foreach ($vehicalTypes as $type): ?>
                <option value="<?php echo $type['id']; ?>" <?php echo (isset($_POST['vehical_type_id']) && $_POST['vehical_type_id'] == $type['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($type['vehical_type']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <select id="vehicle_category_id" name="vehicle_category_id" required>
            <option value="">Select Vehicle Category</option>
            <!-- Options loaded by JS -->
        </select><br>

        <input type="text" name="brand_name" placeholder="Brand Name" required value="<?php echo htmlspecialchars($brand_name_input ?? ''); ?>" /><br>

        <button type="submit">Add Brand</button>

        <?php if ($success): ?>
            <div class="success-msg"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
    </form>
</div>

</body>
</html>
