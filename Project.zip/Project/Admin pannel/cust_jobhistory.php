<?php
session_start();

// Access Control
if (!isset($_SESSION['USR']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'mechanic')) {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "mechano");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Determine mechanic ID
if ($_SESSION['role'] === 'admin' && isset($_GET['mechanic_id'])) {
    $mechanicId = $_GET['mechanic_id'];
} else if ($_SESSION['role'] === 'mechanic') {
    $mechanicId = $_SESSION['mec_id'];
} else {
    echo "Invalid access.";
    exit();
}

// Fetch completed jobs grouped by month and day
$sql = "SELECT *, 
               DATE_FORMAT(request_time, '%M %Y') AS month_year, 
               DATE_FORMAT(request_time, '%d %M %Y') AS full_date 
        FROM breakdown_requests 
        WHERE mechanic_id = ? AND status = 'completed' 
        ORDER BY request_time DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $mechanicId);
$stmt->execute();
$result = $stmt->get_result();

// Grouping data
$grouped = [];
while ($row = $result->fetch_assoc()) {
    $month = $row['month_year'];
    $day = $row['full_date'];
    $grouped[$month][$day][] = $row;
}
?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
<style>
    body {
        background-color: black;
    }

    h2 {
        font-family: Arial, sans-serif;
        color: #ff6f00;
        text-align: center;
    }

    h3,
    h4 {
        color: #fff;
    }

    .month-block {
        margin-bottom: 30px;
    }

    .day-block {
        background-color: #170e0e;
        padding: 10px;
        margin-top: 10px;
        border-left: 5px solid #ff6f00;
        border-radius: 5px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    table th,
    table td {
        border: 1px solid #333;
        padding: 8px;
        text-align: center;
        font-family: Arial, sans-serif;
    }

    td {
        color: #fff;
    }

    th {
        background-color: #ff6f00;
        color: black;
    }

    .completed-status {
        color: green;
        font-weight: bold;
    }

    .no-data {
        color: #fff;
        text-align: center;
    }

    .back-button { display: inline-block;
      margin: 20px 0;
      padding: 10px 20px;
      background-color: #ff6f00;
      color: #000;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
    }
</style>


<div class="main">
    <h2>Job History</h2>

    <?php if ($_SESSION['role'] === 'admin') { ?>
        <a href="mechanic_tab.php" class="back-button"><i class="fas fa-arrow-left"></i> Back to Mechanic List</a>
    <?php } ?>

    <?php if (!empty($grouped)) { ?>
        <?php foreach ($grouped as $month => $days) { ?>
            <div class="month-block">
                <h3><?php echo $month; ?></h3>
                <?php foreach ($days as $day => $jobs) { ?>
                    <div class="day-block">
                        <h4><?php echo $day; ?></h4>
                        <table>
                            <tr>
                                <th>Sl. No</th>
                                <th>Vehicle Type</th>
                                <th>Vehicle Category</th>
                                <th>Brand</th>
                                <th>Model</th>
                                <th>Location</th>
                                <th>Breakdown Type</th>
                                <th>Contact</th>
                                <th>Request Time</th>
                                <th>Status</th>
                            </tr>
                            <?php $counter = 1; ?>
                            <?php foreach ($jobs as $row) { ?>
                                <tr>
                                    <td><?php echo $counter++; ?></td>
                                    <td><?php echo $row['vehicle_type']; ?></td>
                                    <td><?php echo $row['vehicle_category']; ?></td>
                                    <td><?php echo $row['brand']; ?></td>
                                    <td><?php echo $row['model']; ?></td>
                                    <td><?php echo $row['location']; ?></td>
                                    <td><?php echo $row['breakdown_type']; ?></td>
                                    <td><?php echo $row['contact']; ?></td>
                                    <td><?php echo $row['request_time']; ?></td>
                                    <td class="<?php echo $row['status'] == 'completed' ? 'completed-status' : ''; ?>">
                                        <?php echo $row['status']; ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                <?php } ?>
            </div>
        <?php } ?>
    <?php } else { ?>
        <p class="no-data">No completed jobs found.</p>
    <?php } ?>
</div>

<?php
$stmt->close();
$conn->close();
?>
