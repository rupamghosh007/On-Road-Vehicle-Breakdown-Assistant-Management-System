<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}


$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mechano";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$success = $error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Full name title case (capitalize first letter of each word)
    $name = htmlspecialchars($_POST["name"]);
    $name = ucwords(strtolower($name));

    $phone = htmlspecialchars($_POST["phone"]);

    // Email lowercase
    $email = htmlspecialchars($_POST["email"]);
    $email = strtolower($email);

    if (!empty($name) && !empty($phone) && !empty($email)) {
        $stmt = $conn->prepare("INSERT INTO customers (name, phone, email) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $phone, $email);

        if ($stmt->execute()) {
            header("Location: customer.php?success=" . urlencode("Customer '$name' added successfully."));
            exit();
        } else {
            $error = "Failed to add customer.";
        }

        $stmt->close();
    } else {
        $error = "All fields are required.";
    }
}

if (isset($_GET['success'])) {
    $success = htmlspecialchars($_GET['success']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Add Customer - Mechano</title>
   <link rel="icon" type="image/jpeg" href="uploads/icon.jpg">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #121212;
      color: white;
    }

    .main {
      margin-left: 250px;
      padding: 30px;
    }

    h1 {
      color: white;
    }

    .add-customer-form {
      max-width: 600px;
      margin-top: 30px;
      padding: 10px;
    }

    .add-customer-form input {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: 1px solid #ff6f00;
      border-radius: 6px;
      background: #1e1e1e;
      color: #fff;
      font-size: 16px;
    }

    .add-customer-form input::placeholder {
      color: #bbb;
    }

    .add-customer-form button {
      width: 100%;
      padding: 12px;
      background: #ff6f00;
      color: #000;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
    }

    .add-customer-form button:hover {
      background: #ff8c00;
    }

    .success-msg {
      margin-top: 10px;
      font-size: 15px;
    }
  </style>
</head>
<body>
<?php include 'sidebar.php';?>

<div class="main">
  <h1>Welcome to Mechano</h1>
  <hr style="margin: 30px 0; border-color: #444;">
  <h1>Add Customer</h1>

  <div class="add-customer-form">
    <form method="POST" action="" id="customerForm">
      <input type="text" name="name" placeholder="Full Name" required />
      <input type="text" name="phone" placeholder="Phone Number" required />
      <input type="email" name="email" placeholder="Email Address" required />
      <button type="submit" name="addCustomer">Add Customer</button>
    </form>

    <?php if ($success): ?>
      <p class="success-msg" style="color: rgb(111, 247, 111);"><?php echo $success; ?></p>
    <?php elseif ($error): ?>
      <p class="success-msg" style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
  </div>
</div>

<script>
  // Title case function for full name
  function toTitleCase(str) {
    return str.toLowerCase().split(' ').map(function(word) {
      return word.charAt(0).toUpperCase() + word.slice(1);
    }).join(' ');
  }

  const nameInput = document.querySelector('input[name="name"]');
  const emailInput = document.querySelector('input[name="email"]');
  const form = document.getElementById('customerForm');

  nameInput.addEventListener('blur', () => {
    nameInput.value = toTitleCase(nameInput.value);
  });

  emailInput.addEventListener('blur', () => {
    emailInput.value = emailInput.value.toLowerCase();
  });

  form.addEventListener('submit', (e) => {
    nameInput.value = toTitleCase(nameInput.value);
    emailInput.value = emailInput.value.toLowerCase();
  });
</script>
</body>
</html>
