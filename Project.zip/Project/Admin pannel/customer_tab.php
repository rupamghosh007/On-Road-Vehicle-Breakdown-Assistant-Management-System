<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}


$conn = new mysqli("localhost", "root", "", "mechano");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? '';
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$searchTerm = "%$search%";

// Determine total rows for pagination
$count_sql = "SELECT COUNT(*) FROM customers WHERE name LIKE ? OR phone LIKE ?";
$count_stmt = $conn->prepare($count_sql);
$count_stmt->bind_param("ss", $searchTerm, $searchTerm);
$count_stmt->execute();
$count_stmt->bind_result($total_rows);
$count_stmt->fetch();
$count_stmt->close();

$total_pages = ceil($total_rows / $limit);

// Build sorting order
$order = '';
switch ($sort) {
    case 'name_asc':  $order = " ORDER BY name ASC"; break;
    case 'name_desc': $order = " ORDER BY name DESC"; break;
    case 'phone_asc': $order = " ORDER BY phone ASC"; break;
    case 'phone_desc':$order = " ORDER BY phone DESC"; break;
    default: $order = " ORDER BY name ASC"; // default sorting
}

// Main query with limit and offset
$sql = "SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ?" . $order . " LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssii", $searchTerm, $searchTerm, $limit, $offset);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Customer Details - Mechano</title>
  <link rel="icon" type="image/jpeg" href="uploads/icon.jpg" />
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
  />
  <style>
    body {
      background-color: #121212;
      color: #fff;
      font-family: Arial, sans-serif;
      margin: 0;
    }
    header {
      background-color: #000;
      padding: 15px 20px;
      display: flex;
      align-items: center;
    }
    .brand {
      color: #ff6f00;
      font-size: 30px;
      font-weight: bold;
    }
    .container {
      padding: 30px;
    }
    h1 {
      text-align: center;
      color: #ff6f00;
      margin-bottom: 20px;
    }
    .search-bar {
      margin-bottom: 20px;
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      justify-content: center;
    }
    .search-bar input,
    .search-bar select {
      padding: 8px 12px;
      border: none;
      border-radius: 5px;
      background-color: #1e1e1e;
      color: white;
    }
    .search-bar button {
      background-color: #ff6f00;
      color: #000;
      border: none;
      padding: 8px 15px;
      border-radius: 5px;
      cursor: pointer;
    }
    .search-bar button:hover {
      background-color: #e65c00;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background-color: #1e1e1e;
      box-shadow: 0 0 10px rgba(255, 111, 0, 0.3);
    }
    th,
    td {
      padding: 12px 15px;
      border: 1px solid #333;
      text-align: left;
    }
    th {
      background-color: #ff6f00;
      color: #000;
    }
    tr:hover {
      background-color: #222;
    }
    .back-btn {
      display: inline-block;
      margin: 20px 0;
      padding: 10px 20px;
      background-color: #ff6f00;
      color: #000;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
    }
    .back-btn:hover {
      background-color: #e65c00;
    }
    .actions a {
      text-decoration: none;
      font-weight: bold;
      margin-right: 10px;
    }
    .edit-link {
      color: #00d1b2;
    }
    .delete-link {
      color: #ff3860;
    }
    .pagination a {
      margin: 0 5px;
      padding: 8px 12px;
      background-color: #1e1e1e;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }
    .pagination a.active {
      background-color: #ff6f00;
      color: #000;
    }
    .pagination span {
      margin: 0 5px;
      padding: 8px 12px;
      color: #555;
      border-radius: 5px;
      display: inline-block;
    }
  </style>
</head>
<body>
  <header>
    <div class="brand">
      <i class="fas fa-users"></i> Mechano - Customers
    </div>
  </header>

  <div class="container">
    <a href="admin.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    <h1>Customer Details</h1>

    <form method="GET" class="search-bar">
      <input
        type="text"
        name="search"
        placeholder="Search by name or phone..."
        value="<?= htmlspecialchars($search) ?>"
      />
      <select name="sort">
        <option value="">Sort by</option>
        <option value="name_asc" <?= $sort === 'name_asc' ? 'selected' : '' ?>>Name (A-Z)</option>
        <option value="name_desc" <?= $sort === 'name_desc' ? 'selected' : '' ?>>Name (Z-A)</option>
        <option value="phone_asc" <?= $sort === 'phone_asc' ? 'selected' : '' ?>>Phone (Asc)</option>
        <option value="phone_desc" <?= $sort === 'phone_desc' ? 'selected' : '' ?>>Phone (Desc)</option>
      </select>
      <button type="submit"><i class="fas fa-search"></i> Search</button>
    </form>

    <table>
      <tr>
        <th>S/No.</th>
        <th>Name</th>
        <th>Phone</th>
        <th>Email</th>
        <th>Actions</th>
      </tr>
      <?php if ($result->num_rows === 0): ?>
        <tr>
          <td colspan="5" style="text-align:center;">No customers found.</td>
        </tr>
      <?php else: ?>
        <?php $count = $offset + 1; while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= $count++ ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['phone']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td class="actions">
              <a href="edit_customer.php?id=<?= $row['id'] ?>" class="edit-link"><i class="fas fa-edit"></i> Edit</a>
              <a href="delete_customer.php?id=<?= $row['id'] ?>" class="delete-link" onclick="return confirm('Are you sure you want to delete this customer?');"><i class="fas fa-trash"></i> Remove</a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php endif; ?>
    </table>

    <!-- Pagination Links -->
    <div class="pagination" style="text-align: center; margin-top: 20px;">
      <?php if ($total_pages > 1): ?>

        <!-- Previous Button -->
        <?php if ($page > 1): ?>
          <a href="?search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&page=<?= $page - 1 ?>">&#171; Previous</a>
        <?php else: ?>
          <span>&#171; Previous</span>
        <?php endif; ?>

        <!-- Page Number Links -->
        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
          <a href="?search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&page=<?= $i ?>"
             class="<?= $i === $page ? 'active' : '' ?>">
             <?= $i ?>
          </a>
        <?php endfor; ?>

        <!-- Next Button -->
        <?php if ($page < $total_pages): ?>
          <a href="?search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&page=<?= $page + 1 ?>">Next &#187;</a>
        <?php else: ?>
          <span>Next &#187;</span>
        <?php endif; ?>

      <?php endif; ?>
    </div>
  </div>
</body>
</html>
