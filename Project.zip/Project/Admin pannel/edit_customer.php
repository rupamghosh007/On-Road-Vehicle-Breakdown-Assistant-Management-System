<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}



$conn = new mysqli("localhost", "root", "", "mechano");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'] ?? '';
if (empty($id)) {
    header("Location: customer_tab.php"); // Redirect if no ID is provided
    exit();
}

$sql = "SELECT * FROM customers WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Customer not found!";
    exit();
}

$customer = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];

    $updateSql = "UPDATE customers SET name = ?, phone = ?, email = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("sssi", $name, $phone, $email, $id);
    $updateStmt->execute();

    header("Location:customer_tab.php"); // Redirect back to customer list after update
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Customer - Mechano</title>
  <link rel="icon" type="image/jpeg" href="uploads/icon.jpg">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
      body {
      background-color: #121212;
      color: #fff;
      font-family: Arial, sans-serif;
      margin: 0;
    }
    .container {
      max-width: 600px;
      margin: 50px auto;
      background-color: #1e1e1e;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(255, 111, 0, 0.3);
    }
    h2 {
      text-align: center;
      color: #ff6f00;
    }
     label {
      display: block;
      margin: 15px 0 5px;
    }
    input, select {
      width: 100%;
      padding: 10px;
      border-radius: 5px;
      border: none;
      background-color: #2e2e2e;
      color: white;
    }
     button {
      margin-top: 20px;
      width: 100%;
      background-color: #ff6f00;
      color: black;
      font-weight: bold;
      padding: 12px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    a.back-btn {
      display: inline-block;
      margin-top: 20px;
      text-align: center;
      width: 100%;
      text-decoration: none;
      background: #333;
      color: #ff6f00;
      padding: 10px;
      border-radius: 5px;
      font-weight: bold;
    }
  </style>
</head>
<body>



<div class="container">
  <h2>Edit Customer </h2>

  <form method="POST">
    <label for="name">Name:</label>
    <input type="text" name="name" id="name" value="<?= htmlspecialchars($customer['name']) ?>" required><br><br>
    
    <label for="phone">Phone:</label>
    <input type="text" name="phone" id="phone" value="<?= htmlspecialchars($customer['phone']) ?>" required><br><br>
    
    <label for="email">Email:</label>
    <input type="email" name="email" id="email" value="<?= htmlspecialchars($customer['email']) ?>" required><br><br>

       <button type="submit"><i class="fas fa-save"></i> Update Customer</button>
  </form>
  
  <a href="customer_tab.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to List</a>
</div>

</body>
</html>