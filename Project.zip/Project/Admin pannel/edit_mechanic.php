<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "mechano");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM mechanic WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$mechanic = $stmt->get_result()->fetch_assoc();

$allSpecs = $conn->query("SELECT * FROM specialization");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $specs = $_POST['specializations'] ?? [];

    // Use the specialization names (not IDs) and update the mechanic table
    $specStr = implode(", ", $specs);

    $stmt = $conn->prepare("UPDATE mechanic SET name=?, phone=?, specializations=? WHERE id=?");
    $stmt->bind_param("sssi", $name, $phone, $specStr, $id);
    $stmt->execute();

    header("Location: mechanic_tab.php");
    exit();
}

$currentSpecs = array_map('trim', explode(',', $mechanic['specializations']));
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Edit Mechanic</title>
  <link rel="icon" type="image/jpeg" href="uploads/icon.jpg">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    body {
      background-color: #121212;
      color: #fff;
      font-family: Arial, sans-serif;
      margin: 0;
    }
    .container {
      max-width: 600px;
      margin: 50px auto;
      background-color: #1e1e1e;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(255, 111, 0, 0.3);
    }
    h2 {
      text-align: center;
      color: #ff6f00;
    }
    label {
      display: block;
      margin: 15px 0 5px;
    }
    input, select {
      width: 100%;
      padding: 10px;
      border-radius: 5px;
      border: none;
      background-color: #2e2e2e;
      color: white;
    }
    select[multiple] {
      height: 120px;
    }
    button {
      margin-top: 20px;
      width: 100%;
      background-color: #ff6f00;
      color: black;
      font-weight: bold;
      padding: 12px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    a.back {
      display: inline-block;
      margin-top: 20px;
      text-align: center;
      width: 100%;
      text-decoration: none;
      background: #333;
      color: #ff6f00;
      padding: 10px;
      border-radius: 5px;
      font-weight: bold;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Edit Mechanic</h2>
  <form method="POST">
    <label>Name:</label>
    <input type="text" name="name" value="<?= htmlspecialchars($mechanic['name']) ?>" required>

    <label>Phone:</label>
    <input type="text" name="phone" value="<?= htmlspecialchars($mechanic['phone']) ?>" required>

    <label>Specializations:</label>
    <select name="specializations[]" multiple>
      <?php while ($spec = $allSpecs->fetch_assoc()): ?>
        <option value="<?= htmlspecialchars($spec['specialization']) ?>"
          <?= in_array($spec['specialization'], $currentSpecs) ? 'selected' : '' ?>>
          <?= htmlspecialchars($spec['specialization']) ?>
        </option>
      <?php endwhile; ?>
    </select>

    <button type="submit"><i class="fas fa-save"></i> Update Mechanic</button>
  </form>

  <a href="mechanic_tab.php" class="back"><i class="fas fa-arrow-left"></i> Back to List</a>
</div>

</body>
</html>