<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}



$success = "";
$error = "";

// Get vehicle ID from URL
$vehical_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch brands by type
$brands = [];
$brandResult = $conn->query("SELECT brand_name, vehical_type FROM brand");
while ($row = $brandResult->fetch_assoc()) {
    $brands[$row['vehical_type']][] = $row['brand_name'];
}

// Fetch existing vehicle data
$vehicalData = null;
if ($vehical_id > 0) {
    $stmt = $conn->prepare("SELECT vehical_type, brand, model FROM vehical WHERE id = ?");
    $stmt->bind_param("i", $vehical_id);
    $stmt->execute();
    $vehicalData = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST["id"]);
    $type = trim($_POST["type"]);
    $brand = trim($_POST["brand"]);
    $model = trim($_POST["model"]);

    if (empty($type) || empty($brand) || empty($model)) {
        $error = "All fields are required.";
    } else {
        $stmt = $conn->prepare("UPDATE vehical SET vehical_type=?, brand=?, model=? WHERE id=?");
        $stmt->bind_param("sssi", $type, $brand, $model, $id);
        if($stmt->execute()){
        header("Location:vehical_tab.php"); // Redirect back to customer list after update
    exit();
    }
    else{
      $error="failed to update".$stmt ->error;
    }
      $stmt->close();
  }
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Vehicle - Mechano</title>
  <link rel="icon" type="image/jpeg" href="uploads/icon.jpg">
  <style>
     body {
      background-color: #121212;
      color: #fff;
      font-family: Arial, sans-serif;
      margin: 0;
    }
    .main {
      max-width: 600px;
      margin: 50px auto;
      background-color: #1e1e1e;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(255, 111, 0, 0.3);
    }
      .add-customer-form input, .add-customer-form select{
            width: 100%;
      padding: 10px;
      border-radius: 5px;
      border: none;
      background-color: #2e2e2e;
      color: white;
        }
         h2 {
      text-align: center;
      color: #ff6f00;
    }
    label {
      display: block;
      margin: 15px 0 5px;
    }
        .add-customer-form input::placeholder,
        .add-customer-form select option {
            color: #bbb;
        }
        .add-customer-form button:hover {
            background: #ff8c00;
        }
        .add-customer-form button {
            width: 100%;
            padding: 12px;
            background: #ff6f00;
            color: #000;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }
        button {
      margin-top: 20px;
      width: 100%;
      background-color: #ff6f00;
      color: black;
      font-weight: bold;
      padding: 12px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    a.back {
      display: inline-block;
      margin-top: 20px;
      text-align: center;
      width: 100%;
      text-decoration: none;
      background: #333;
      color: #ff6f00;
      padding: 10px;
      border-radius: 5px;
      font-weight: bold;
    }
  </style>
  </style>
  <script>
    function updateBrands() {
      const type = document.querySelector('select[name="type"]').value;
      const brandSelect = document.querySelector('select[name="brand"]');
      brandSelect.innerHTML = '<option value="">Select Brand</option>';
      const brands = <?php echo json_encode($brands); ?>;
      if (brands[type]) {
        brands[type].forEach(brand => {
          const option = document.createElement('option');
          option.value = brand;
          option.textContent = brand;
          brandSelect.appendChild(option);
        });
      }
    }

    window.addEventListener('DOMContentLoaded', () => {
      updateBrands();
      const selectedBrand = "<?php echo $vehicalData['brand'] ?? ''; ?>";
      const brandSelect = document.querySelector('select[name="brand"]');
      if (selectedBrand) {
        setTimeout(() => {
          const option = brandSelect.querySelector(`option[value="${selectedBrand}"]`);
          if (option) option.selected = true;
        }, 100);
      }
    });
  </script>
</head>
<body>


<div class="main">
  <h2>Edit Vehicle</h2>
  <form method="POST" class="add-customer-form">
    <input type="hidden" name="id" value="<?php echo htmlspecialchars($vehical_id); ?>">
<lable> Vehicle Type</lable>
    <select name="type" onchange="updateBrands()" required>
      <option value="">Select Vehicle Type</option>
      <?php
      $typeResult = $conn->query("SELECT DISTINCT vehical_type FROM vehical_type");
      while ($row = $typeResult->fetch_assoc()) {
          $selected = ($vehicalData && $vehicalData['vehical_type'] === $row['vehical_type']) ? 'selected' : '';
          echo '<option value="' . htmlspecialchars($row['vehical_type']) . '" ' . $selected . '>' . htmlspecialchars($row['vehical_type']) . '</option>';
      }
      ?>
    </select><br>
<lable> Brand Name</lable>
    <select name="brand" required>
      <option value="">Select Brand</option>
    </select><br>
<lable> Model</lable>
    <input type="text" name="model" placeholder="Enter Model Name" value="<?php echo htmlspecialchars($vehicalData['model'] ?? ''); ?>" required>

    <button type="submit"><i class="fas fa-save"></i> Update Vehicle</button>
  </form>

  <a href="vehical_tab.php" class="back"><i class="fas fa-arrow-left"></i> Back to List</a>

    
  </form>
</div>
</body>
</html>