<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $phone = htmlspecialchars($_POST['phone']);
    $email = strtolower(htmlspecialchars($_POST['email']));

    // 🔐 Secure hashed password
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $specializations = isset($_POST['specializations']) ? $_POST['specializations'] : [];
    $specializationStr = implode(', ', $specializations);

    $fileName = $_FILES['photo']['name'];
    $tmpName = $_FILES['photo']['tmp_name'];
    $uniqueName = basename($fileName);
    $destination = 'uploads/' . $uniqueName;

    if (!is_dir('uploads')) {
        mkdir('uploads');
    }

    // Backend validations
    $checkEmail = $conn->prepare("SELECT id FROM mechanic WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $checkEmail->store_result();

    if ($checkEmail->num_rows > 0) {
        $error = "Email is already registered.";
    } elseif (!preg_match('/^\d{10}$/', $phone)) {
        $error = "Phone number must be exactly 10 digits.";
    } elseif (move_uploaded_file($tmpName, $destination)) {
        $stmt = $conn->prepare("INSERT INTO mechanic (name, phone, email, password, photo, specializations) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("ssssss", $name, $phone, $email, $password, $uniqueName, $specializationStr);
            if ($stmt->execute()) {
                $success = true;
                $successName = $name;
                $mid = $stmt->insert_id;

                // Insert into mapping table
                $mapStmt = $conn->prepare("INSERT INTO mechanic_spe_map (machenic_id, specialization_id) VALUES (?, ?)");
                foreach ($specializations as $spe) {
                    $mapStmt->bind_param("ii", $mid, $spe);
                    $mapStmt->execute();
                }
                $mapStmt->close();
            } else {
                $error = "Failed to insert mechanic data.";
            }
            $stmt->close();
        } else {
            $error = "Failed to prepare SQL statement.";
        }
    } else {
        $error = "Failed to upload photo.";
    }
}

$specOptions = $conn->query("SELECT * FROM specialization");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Mechano Dashboard</title>
  <link rel="icon" type="image/jpeg" href="uploads/icon.jpg">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #121212;
      color: #fff;
      font-family: Arial, sans-serif;
    }

    form { max-width: 500px; }
    input[type="text"], input[type="tel"], input[type="email"], input[type="password"], input[type="file"], select {
      width: 100%;
      padding: 10px;
      margin: 10px 0 20px 0;
      border:1px solid #ff6f00;
      background: #1e1e1e;
      color: #fff;
      border-radius: 5px;
    }

    .select2-container--default .select2-selection--multiple {
      background-color: #1e1e1e;
      border: 1px solid #ff6f00;
      color: #fff;
    }

    .select2-container--default .select2-selection--multiple .select2-selection__choice {
      background-color: #ff6f00;
      color: #000;
      font-weight: bold;
    }

    .select2-results__option {
      background: #1e1e1e;
      color: #fff;
    }

    .select2-container--default .select2-results__option--highlighted[aria-selected] {
      background-color: #ff6f00;
      color: #000;
    }

    button[type="submit"] {
      background-color: #ff6f00;
      color: #000;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      font-weight: bold;
      cursor: pointer;
    }

    .success {
      color: rgb(111, 247, 111);
      margin-top: 15px;
      font-weight: bold;
    }

    .error {
      color: red;
      margin-top: 15px;
      font-weight: bold;
    }
  </style>
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main">
  <h1>Welcome to Mechano</h1>
  <hr style="margin: 30px 0; border-color: #444;">
  <h1>Mechanic Manager</h1>

  <form method="POST" enctype="multipart/form-data" id="mechanicForm">
    <label>Mechanic Name:</label>
    <input type="text" name="name" placeholder="Enter name" required>

    <label>Phone Number:</label>
    <input type="tel" name="phone" placeholder="Enter 10-digit phone number" pattern="[0-9]{10}" maxlength="10" required>

    <label>Email Address:</label>
    <input type="email" name="email" placeholder="Enter email" required>

    <label>Password:</label>
    <div style="position: relative;">
      <input type="password" name="password" id="password" placeholder="Enter password" required>
      <i class="fa fa-eye" id="togglePassword" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer; color: #ff6f00;"></i>
    </div>

    <label>Upload Photo:</label>
    <input type="file" name="photo" accept="image/*" required><br>

    <label>Specializations (Search or Select multiple):</label>
    <select id="specializations" name="specializations[]" multiple required>
      <?php if ($specOptions && $specOptions->num_rows > 0): ?>
        <?php while ($row = $specOptions->fetch_assoc()): ?>
          <option value="<?= htmlspecialchars($row['id']) ?>"><?= htmlspecialchars($row['specialization']) ?></option>
        <?php endwhile; ?>
      <?php else: ?>
        <option disabled>No Specializations Available</option>
      <?php endif; ?>
    </select>

    <div class="form-group" style="margin-top: 20px;">
      <button type="submit">Add Mechanic</button>
    </div>

    <?php if (!empty($success)): ?>
      <div class="success">Mechanic <strong><?= htmlspecialchars($successName) ?></strong> added successfully!</div>
    <?php elseif (!empty($error)): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
  </form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
  $(document).ready(function() {
    $('#specializations').select2({
      placeholder: "Select specializations",
      width: '100%'
    });
  });

  document.getElementById("togglePassword").addEventListener("click", function () {
    const passwordInput = document.getElementById("password");
    const icon = this;
    const isVisible = passwordInput.type === "text";
    passwordInput.type = isVisible ? "password" : "text";
    icon.classList.toggle("fa-eye-slash", !isVisible);
    icon.classList.toggle("fa-eye", isVisible);
  });

  document.getElementById("mechanicForm").addEventListener("submit", function(e) {
    const phone = document.querySelector('input[name="phone"]').value;
    if (!/^\d{10}$/.test(phone)) {
      alert("Phone number must be exactly 10 digits.");
      e.preventDefault();
      return false;
    }
  });

  const nameInput = document.querySelector('input[name="name"]');
  nameInput.addEventListener('blur', function() {
    this.value = this.value
      .toLowerCase()
      .split(' ')
      .filter(Boolean)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  });

  const emailInput = document.querySelector('input[name="email"]');
  emailInput.addEventListener('blur', function() {
    this.value = this.value.toLowerCase();
  });
</script>
</body>
</html>
