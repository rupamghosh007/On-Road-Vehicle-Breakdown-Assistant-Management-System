<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}



$conn = new mysqli("localhost", "root", "", "mechano");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 5; // changed here to 5 members per page
$offset = ($page - 1) * $limit;

$where = " WHERE name LIKE ? OR phone LIKE ?";

$order = '';
switch ($sort) {
    case 'name_asc': $order = " ORDER BY name ASC"; break;
    case 'name_desc': $order = " ORDER BY name DESC"; break;
    case 'phone_asc': $order = " ORDER BY phone ASC"; break;
    case 'phone_desc': $order = " ORDER BY phone DESC"; break;
}

$count_sql = "SELECT COUNT(*) as total FROM mechanic" . $where;
$count_stmt = $conn->prepare($count_sql);
$like = "%$search%";
$count_stmt->bind_param("ss", $like, $like);
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_rows = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);

$data_sql = "SELECT * FROM mechanic" . $where . $order . " LIMIT ? OFFSET ?";
$data_stmt = $conn->prepare($data_sql);
$data_stmt->bind_param("ssii", $like, $like, $limit, $offset);
$data_stmt->execute();
$result = $data_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Mechanic Details - Mechano</title>
  <link rel="icon" type="image/jpeg" href="uploads/icon.jpg" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    body {
      background-color: #121212;
      color: #fff;
      font-family: Arial, sans-serif;
      margin: 0;
    }
    header {
      background-color: #000;
      padding: 15px 20px;
      display: flex;
      align-items: center;
    }
    .brand {
      color: #ff6f00;
      font-size: 30px;
      font-weight: bold;
    }
    .container {
      padding: 30px;
    }
    h1 {
      text-align: center;
      color: #ff6f00;
      margin-bottom: 20px;
    }
    form {
      display: flex;
      gap: 10px;
      justify-content: center;
      margin-bottom: 25px;
      flex-wrap: wrap;
    }
    input[type="text"], select {
      padding: 8px 12px;
      border: none;
      border-radius: 5px;
      background-color: #1e1e1e;
      color: white;
    }
    button {
      background-color: #ff6f00;
      color: black;
      padding: 8px 16px;
      border: none;
      border-radius: 4px;
      font-weight: bold;
      cursor: pointer;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background-color: #1e1e1e;
      box-shadow: 0 0 10px rgba(255, 111, 0, 0.3);
    }
    th, td {
      padding: 12px 15px;
      border: 1px solid #333;
      text-align: left;
    }
    th {
      background-color: #ff6f00;
      color: #000;
    }
    tr:hover {
      background-color: #222;
    }
    .back-btn {
      display: inline-block;
      margin: 20px 0;
      padding: 10px 20px;
      background-color: #ff6f00;
      color: #000;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
    }
    .back-btn:hover {
      background-color: #e65c00;
    }
    .actions a {
      text-decoration: none;
      font-weight: bold;
      margin-right: 10px;
    }
    .edit-link {
      color: #00d1b2;
    }
    .delete-link {
      color: #ff3860;
    }
    img {
      height: 50px;
      width: 50px;
      object-fit: cover;
      border-radius: 5px;
    }
    .pagination {
      margin-top: 20px;
      text-align: center;
    }
    .pagination a, .pagination span {
      display: inline-block;
      padding: 8px 12px;
      margin: 0 4px;
      background-color: #ff6f00;
      color: #000;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      cursor: pointer;
    }
    .pagination a:hover {
      background-color: #e65c00;
    }
    .pagination .current {
      background-color: #e65c00;
      cursor: default;
    }
  </style>
</head>
<body>

<header>
  <div class="brand"><i class="fas fa-tools"></i> Mechano - Mechanics</div>
</header>

<div class="container">
  <a href="admin.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
  <h1>Mechanic Details</h1>

  <form method="get">
    <input type="text" name="search" placeholder="Search by name or phone..." value="<?= htmlspecialchars($search) ?>" />
    <select name="sort" onchange="this.form.submit()">
      <option value="">Sort by</option>
      <option value="name_asc" <?= ($sort == 'name_asc') ? 'selected' : '' ?>>Name A-Z</option>
      <option value="name_desc" <?= ($sort == 'name_desc') ? 'selected' : '' ?>>Name Z-A</option>
      <option value="phone_asc" <?= ($sort == 'phone_asc') ? 'selected' : '' ?>>Phone 0-9</option>
      <option value="phone_desc" <?= ($sort == 'phone_desc') ? 'selected' : '' ?>>Phone 9-0</option>
    </select>
    <button type="submit"><i class="fas fa-search"></i> Search</button>
  </form>

  <table>
    <tr>
      <th>S/No.</th>
      <th>Name</th>
      <th>Phone</th>
      <th>Specializations</th>
      <th>Photo</th>
      <th>Actions</th>
    </tr>
    <?php
      $count = $offset + 1;
      if ($result->num_rows > 0):
        while ($row = $result->fetch_assoc()):
    ?>
    <tr>
      <td><?= $count++ ?></td>
      <td><?= htmlspecialchars($row['name']) ?></td>
      <td><?= htmlspecialchars($row['phone']) ?></td>
      <td>
        <?php
          $resx=mysqli_query($conn,"SELECT * FROM `mechanic_spe_map` join specialization where mechanic_spe_map.specialization_id=specialization.id and mechanic_spe_map.machenic_id='".$row['id']."'"); 
          while($rowx=mysqli_fetch_array( $resx ))
          {
            echo ( $rowx['specialization'])."<br>";
          }
          //htmlspecialchars($row['specializations']) 
        ?>
      </td>
      <td>
        <?php if (!empty($row['photo'])): ?>
          <img src="uploads/<?= htmlspecialchars($row['photo']) ?>" alt="Photo" />
        <?php else: ?>
          <span style="color: #888;">No photo</span>
        <?php endif; ?>
      </td>
     <td class="actions">
    <a href="edit_mechanic.php?id=<?= $row['id'] ?>" class="edit-link"><i class="fas fa-edit"></i> Edit</a>
    <a href="delete_mechanic.php?id=<?= $row['id'] ?>" class="delete-link" onclick="return confirm('Are you sure you want to delete this mechanic?');"><i class="fas fa-trash"></i> Remove</a>
    <a href="cust_jobhistory.php?mechanic_id=<?= $row['id'] ?>" class="history-link" style="color: #ffa500;"><i class="fas fa-history"></i> Job History</a>
    <a href="payment_list.php?mechanic_id=<?= $row['id'] ?>" class="payment-link" style="color: #00ff00;"><i class="fas fa-money-bill-wave"></i> Payment</a>
</td>

    </tr>
    <?php endwhile; else: ?>
    <tr>
      <td colspan="6" style="text-align:center; color: #aaa;">No mechanics found.</td>
    </tr>
    <?php endif; ?>
  </table>

  <?php if ($total_rows > $limit): ?>
  <div class="pagination">
    <?php if ($page > 1): ?>
      <a href="?search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&page=<?= $page - 1 ?>"><i class="fas fa-chevron-left"></i> Prev</a>
    <?php endif; ?>

    <?php
    $start = max(1, $page - 3);
    $end = min($total_pages, $page + 3);
    for ($i = $start; $i <= $end; $i++): ?>
      <?php if ($i == $page): ?>
        <span class="current"><?= $i ?></span>
      <?php else: ?>
        <a href="?search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&page=<?= $i ?>"><?= $i ?></a>
      <?php endif; ?>
    <?php endfor; ?>

    <?php if ($page < $total_pages): ?>
      <a href="?search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&page=<?= $page + 1 ?>">Next <i class="fas fa-chevron-right"></i></a>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>

</body>
</html>

<?php $conn->close(); ?>
