
<?php
session_start();
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mechano";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Session Check
if (!isset($_SESSION['USR']) || $_SESSION['role'] != 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Fetch invoices for the current month
$currentMonth = date('Y-m');
$sql = "SELECT * FROM invoice WHERE DATE_FORMAT(payment_date, '%Y-%m') = '$currentMonth' ORDER BY payment_date DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Monthly Invoice Report</title>
    <style>
        h1 { text-align: center; color: #ff6f00; }
        h2 { color: #ff6f00; border-bottom: 2px solid #ff6f00; margin-top: 40px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: center; }
        th { background-color: #ff6f00; color: white; }
        tr:hover { background-color: #f1f1f1; }
        a { text-decoration: none; color: #ff6f00; }
        .total-section { font-size: 20px; color: #ff6f00; font-weight: bold; margin-top: 20px; text-align: right; }
    </style>
</head>
<body>

<?php include "sidebar.php"; ?>
<div class="main">
    <h1>Payment List</h1>

    <?php
    if (mysqli_num_rows($result) > 0) {
        $current_date = '';
        $counter = 1;
        $monthly_total = 0;
        $daily_total = 0;

        while ($row = mysqli_fetch_assoc($result)) {
            $invoice_date = date('Y-m-d', strtotime($row['payment_date']));

            if ($invoice_date != $current_date) {
                // New Date Section
                if ($current_date != '') {
                    // Show daily total
                    echo "<tr><td colspan='6' class='total-section'>Daily Total: ₹ " . $daily_total . "</td></tr>";
                    echo "</table>";
                }

                // Display date header
                echo "<h2>Date: " . $invoice_date . "</h2>";
                echo "<table>";
                echo "<tr>
                        <th>Sl. No.</th>
                        <th>Customer Name</th>
                        <th>Mechanic Name</th>
                        
                        <th>Payment Method</th>
                        <th>Total Amount (₹)</th>
                      </tr>";

                // Reset counters
                $counter = 1;
                $daily_total = 0;
                $current_date = $invoice_date;
            }

            // Display invoice row
            echo "<tr>";
            echo "<td>" . $counter++ . "</td>";
            echo "<td>" . $row['customer_name'] . "</td>";
            echo "<td>" . $row['mechanic_name'] . "</td>";
           
            echo "<td>" . $row['payment_method'] . "</td>";
           echo "<td>₹ " . $row['total_amount'] . "</td>";
            echo "</tr>";

            // Add to daily and monthly totals
            $daily_total += $row['total_amount'];
            $monthly_total += $row['total_amount'];
        }

        // Close last table and show last daily total
        echo "<tr><td colspan='6' class='total-section'>Daily Total: ₹ " . $daily_total . "</td></tr>";
        echo "</table>";

        // Show monthly total
        echo "<div class='total-section'>Total Monthly Earnings: ₹ " . $monthly_total . "</div>";
    } else {
        echo "<p style='text-align:center; color: red;'>No invoices found for this month.</p>";
    }
    ?>
</div>

</body>
</html>
