<?php
session_start();

// Access Control: Allow only admin and mechanic
if (!isset($_SESSION['USR']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'mechanic')) {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "mechano");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Determine mechanic ID
if ($_SESSION['role'] === 'admin' && isset($_GET['mechanic_id'])) {
    $mechanicId = $_GET['mechanic_id'];
} else if ($_SESSION['role'] === 'mechanic') {
    $mechanicId = $_SESSION['mec_id'];
} else {
    echo "Invalid access.";
    exit();
}

// Get mechanic name
$mechanicName = '';
$name_sql = "SELECT name FROM mechanic WHERE id = ?";
$name_stmt = $conn->prepare($name_sql);
$name_stmt->bind_param("i", $mechanicId);
$name_stmt->execute();
$name_result = $name_stmt->get_result();

if ($name_row = $name_result->fetch_assoc()) {
    $mechanicName = $name_row['name'];
} else {
    echo "Mechanic not found.";
    exit();
}

$name_stmt->close();

// Fetch payment history ordered by date
$sql = "SELECT total_amount, payment_method, payment_date FROM invoice WHERE mechanic_name = ? ORDER BY payment_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $mechanicName);
$stmt->execute();
$result = $stmt->get_result();

// Prepare day-wise list
$paymentsByDate = [];
$totalEarning = 0;

while ($row = $result->fetch_assoc()) {
    $date = date('Y-m-d', strtotime($row['payment_date']));
    $paymentsByDate[$date][] = $row;
    $totalEarning += $row['total_amount'];
}
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
<style>
    body { background-color: black; font-family: Arial, sans-serif; }
    h2 { color: #ff6f00; text-align: center; }
    h3 { color: #ff6f00; margin-top: 30px; }
    table { width: 100%; border-collapse: collapse; margin: 20px auto; }
    th, td { border: 1px solid #333; padding: 10px; text-align: center; color: #fff; }
    th { background-color: #ff6f00; color: black; }
    .no-data { color: #fff; text-align: center; margin-top: 20px; }
    .back-button { display: inline-block; margin: 20px; padding: 10px 20px; background-color: #ff6f00; color: #000; text-decoration: none; border-radius: 5px; font-weight: bold; }
    .back-button:hover { background-color: #e65c00; }
    .total { font-size: 20px; font-weight: bold; color: #00ff00; text-align: right; margin: 20px; }
</style>

<div class="main">
    <h2>Payment History</h2>

    <?php if ($_SESSION['role'] === 'admin') { ?>
        <a href="mechanic_tab.php" class="back-button"><i class="fas fa-arrow-left"></i> Back to Mechanic List</a>
    <?php } else { ?>
        <a href="job_history.php" class="back-button"><i class="fas fa-arrow-left"></i> Back to Job History</a>
    <?php } ?>

    <?php if (!empty($paymentsByDate)) { ?>
        <?php foreach ($paymentsByDate as $paymentDate => $payments) { ?>
            <?php
                $formattedDate = date('d F Y', strtotime($paymentDate)); // Example: 18 June 2025
                echo "<h3>$formattedDate</h3>";
            ?>
            <table>
                <tr>
                    <th>Sl. No</th>
                    <th>Payment Time</th>
                    <th>Amount (₹)</th>
                    <th>Payment Method</th>
                </tr>
                <?php
                    $counter = 1;
                    foreach ($payments as $payment) {
                        $time = date('H:i:s', strtotime($payment['payment_date']));
                ?>
                <tr>
                    <td><?php echo $counter++; ?></td>
                    <td><?php echo $time; ?></td>
                    <td><?php echo number_format($payment['total_amount'], 2); ?></td>
                    <td><?php echo $payment['payment_method']; ?></td>
                </tr>
                <?php } ?>
            </table>
        <?php } ?>

        <div class="total">
            Total Earning: ₹<?php echo number_format($totalEarning, 2); ?>
        </div>

    <?php } else { ?>
        <p class="no-data">No payment records found.</p>
    <?php } ?>
</div>

<?php
$stmt->close();
$conn->close();
?>
