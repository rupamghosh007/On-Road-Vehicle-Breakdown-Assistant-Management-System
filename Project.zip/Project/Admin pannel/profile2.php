<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "mechano");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// AJAX Handler
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit();
    }

    $username = $_SESSION['username'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact_number'];
    $password = $_POST['password'];
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // ✅ Hash password
    $photoPath = '';

    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $photoName = basename($_FILES['photo']['name']);
        $photoPath = 'uploads/' . $photoName;
        move_uploaded_file($_FILES['photo']['tmp_name'], $photoPath);

        $sql = "UPDATE admin SET name=?, email=?, contact_number=?, password=?, photo=? WHERE username=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $name, $email, $contact, $hashedPassword, $photoPath, $username);
    } else {
        $sql = "UPDATE admin SET name=?, email=?, contact_number=?, password=? WHERE username=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $name, $email, $contact, $hashedPassword, $username);
    }

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'photo' => $photoPath, 'message' => 'Profile updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Update failed.']);
    }

    $stmt->close();
    $conn->close();
    exit();
}

// Page Load
$username = $_SESSION['username'];
$sql = "SELECT * FROM admin WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Profile</title>
    <style>
        body {
            background-color: #121212;
            color: white;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .profile-container {
            background-color: #1e1e1e;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 0 20px 5px #ff6f00;
            text-align: center;
            width: 400px;
        }
        .profile-container img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            border: 4px solid #ff6f00;
            margin-bottom: 20px;
        }
        .profile-container h2 {
            color: #ff6f00;
            margin-bottom: 20px;
        }
        .profile-details {
            text-align: left;
            margin: 0 auto;
        }
        .profile-details .row {
            display: flex;
            margin: 8px 0;
        }
        .profile-details .label {
            min-width: 80px;
            font-weight: bold;
            color: #ff6f00;
            margin-right: 5px;
        }
        .profile-details .value {
            flex: 1;
            color: white;
        }
        .edit-btn, .save-btn, .cancel-btn {
            background-color: #ff6f00;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            color: black;
            font-weight: bold;
            margin-top: 20px;
            margin-right: 10px;
        }
        .edit-btn:hover, .save-btn:hover, .cancel-btn:hover {
            background-color: #ff9900;
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ff6f00;
            background-color: #2a2a2a;
            color: white;
        }
        input[type="file"] {
            color: white;
        }
        #successMsg {
            display: none;
            color: #00ff00;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="profile-container">

    <div id="successMsg"></div> <!-- ✅ Success message -->

    <!-- View Mode -->
    <div id="viewMode">
        <img id="profilePhoto" src="<?php echo htmlspecialchars($admin['photo']); ?>" alt="Admin Photo">
        <h2>Admin Profile</h2>
        <div class="profile-details" id="profileDetails">
            <div class="row">
                <div class="label">Name:</div>
                <div class="value" id="name"><?php echo htmlspecialchars($admin['name']); ?></div>
            </div>
            <div class="row">
                <div class="label">Email:</div>
                <div class="value" id="email"><?php echo htmlspecialchars($admin['email']); ?></div>
            </div>
            <div class="row">
                <div class="label">Contact:</div>
                <div class="value" id="contact"><?php echo htmlspecialchars($admin['contact_number']); ?></div>
            </div>
            <div class="row">
                <div class="label">Username:</div>
                <div class="value"><?php echo htmlspecialchars($admin['username']); ?></div>
            </div>
        </div>

        <button class="edit-btn" onclick="toggleEdit(true)">Edit Profile</button>
    </div>

    <!-- Edit Mode -->
    <div id="editMode" style="display: none;">
        <h2>Edit Profile</h2>
        <form id="editForm" enctype="multipart/form-data">
            <div class="profile-details">
                <div class="row">
                    <div class="label">Name:</div>
                    <div class="value"><input type="text" name="name" id="editName" required></div>
                </div>
                <div class="row">
                    <div class="label">Email:</div>
                    <div class="value"><input type="email" name="email" id="editEmail" required></div>
                </div>
                <div class="row">
                    <div class="label">Contact:</div>
                    <div class="value"><input type="text" name="contact_number" id="editContact" required></div>
                </div>
                <div class="row">
                    <div class="label">Password:</div>
                    <div class="value"><input type="password" name="password" id="editPassword" required></div>
                </div>
                <div class="row">
                    <div class="label">Photo:</div>
                    <div class="value"><input type="file" name="photo" id="editPhoto"></div>
                </div>
            </div>

            <button type="submit" class="save-btn">Save</button>
            <button type="button" class="cancel-btn" onclick="toggleEdit(false)">Cancel</button>
        </form>
    </div>

</div>

<script>
    function toggleEdit(isEdit) {
        if (isEdit) {
            document.getElementById('editName').value = document.getElementById('name').innerText;
            document.getElementById('editEmail').value = document.getElementById('email').innerText;
            document.getElementById('editContact').value = document.getElementById('contact').innerText;
            document.getElementById('editPassword').value = '';
        }
        document.getElementById('viewMode').style.display = isEdit ? 'none' : 'block';
        document.getElementById('editMode').style.display = isEdit ? 'block' : 'none';
        document.getElementById('successMsg').style.display = 'none';
    }

    document.getElementById('editForm').addEventListener('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(this);

        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('name').innerText = formData.get('name');
                document.getElementById('email').innerText = formData.get('email');
                document.getElementById('contact').innerText = formData.get('contact_number');

                if (data.photo && data.photo !== '') {
                    document.getElementById('profilePhoto').src = data.photo + '?' + new Date().getTime();
                }

                document.getElementById('successMsg').innerText = data.message;
                document.getElementById('successMsg').style.display = 'block';

                document.getElementById('editMode').style.display = 'none';

                setTimeout(() => {
                    window.location.href = 'profile2.php'; // ✅ Redirect after 2 sec
                }, 2000);
            } else {
                console.error(data.message || 'Update failed.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
</script>

</body>
</html>
