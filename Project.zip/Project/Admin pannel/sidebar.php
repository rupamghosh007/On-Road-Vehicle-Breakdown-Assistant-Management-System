

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Mechano Dashboard</title>
  <link rel="icon" type="image/jpeg" href="uploads/icon.jpg">

  <!-- Font Awesome for icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

  <style>
    body {
      margin: 0;
      background-color: #121212;
      color: #fff;
      font-family: Arial, sans-serif;
    }

    .navbar {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      background-color: #000;
      padding: 15px 20px;
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 1001;
    }

    .brand {
      color: #ff6f00;
      font-size: 35px;
      font-weight: bold;
      margin-left: 10px;
    }

    .menu-btn {
      font-size: 24px;
      color: #ff6f00;
      background: none;
      border: none;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0;
      left: -250px;
      width: 250px;
      height: 100vh;
      background-color: #000;
      padding-top: 60px;
      transition: left 0.3s ease;
      z-index: 1000;
      overflow-y: auto;
    }

    .sidebar.active {
      left: 0;
    }

    .sidebar .close-btn {
      position: absolute;
      top: 10px;
      right: 15px;
      font-size: 28px;
      color: #ff6f00;
      cursor: pointer;
      display: none;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
      margin-top: 30px;
    }

    .sidebar ul li {
      position: relative;
    }

    .sidebar ul li a {
      display: block;
      padding: 15px 20px;
      color: #fff;
      text-decoration: none;
      transition: 0.2s;
    }

    .sidebar ul li a:hover {
      font-weight: bold;
    }

    .sidebar ul li a i {
      margin-right: 10px;
    }

    .submenu {
      display: none;
      background-color: #111;
    }

    .submenu a {
      padding-left: 40px;
    }

    .sidebar ul li.active > .submenu {
      display: block;
    }

    .main {
      margin: 0px;
      padding: 30px;
      flex:1;
      transition: margin-left 0.3s ease;
    }

    .sidebar.active ~ .main {
      margin-left: 250px;
    }

    @media (max-width: 768px) {
      .sidebar.active ~ .main {
        margin-left: 0;
      }

      .sidebar .close-btn {
        display: block;
      }
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <div class="navbar">
    <button class="menu-btn" id="toggleSidebar"><i class="fas fa-bars"></i></button>
    <span class="brand">Mechano</span>
  </div>

  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <span class="close-btn" id="closeSidebar">&times;</span>
    <ul>
      <li><a href=""><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
      <li><a href="admin.php"><i class="fas fa-home"></i> Home</a></li>

      <li id="customerToggle">
        <a href="javascript:void(0)"><i class="fas fa-user-friends"></i> Customers <i class="fas fa-chevron-down" style="float:right;"></i></a>
        <div class="submenu">
          <a href="customer.php"><i class="fas fa-user-plus"></i> Add Customer</a>
        </div>
      </li>

      <li id="vehicleTypeToggle">
        <a href="javascript:void(0)"><i class="fas fa-list"></i> Vehicle Types <i class="fas fa-chevron-down" style="float:right;"></i></a>
        <div class="submenu">
          <a href="vehical_type.php"><i class="fas fa-plus-square"></i> Add Vehicle Type</a>
        </div>
      </li>

      <!-- Vehicle Categories shifted under Vehicle Types -->
      <li id="vehicleCategoryToggle">
        <a href="javascript:void(0)">
          <i class="fas fa-th-list"></i> Vehicle Categories
          <i class="fas fa-chevron-down" style="float:right;"></i>
        </a>
        <div class="submenu">
          <a href="vehicle_category.php"><i class="fas fa-plus-square"></i> Add Vehicle Category</a>
        </div>
      </li>

      <li id="brandTypeToggle">
        <a href="javascript:void(0)"><i class="fas fa-list"></i> Brand Types <i class="fas fa-chevron-down" style="float:right;"></i></a>
        <div class="submenu">
          <a href="brand.php"><i class="fas fa-plus-square"></i> Add Brand Name</a>
        </div>
      </li>

      <li id="vehicleToggle">
        <a href="javascript:void(0)"><i class="fas fa-car"></i> Vehicles <i class="fas fa-chevron-down" style="float:right;"></i></a>
        <div class="submenu">
          <a href="vehical.php"><i class="fas fa-car-side"></i> Add Vehicle</a>
        </div>
      </li>

      <li id="specializationToggle">
        <a href="javascript:void(0)"><i class="fa-solid fa-user-gear"></i> Specialization <i class="fas fa-chevron-down" style="float:right;"></i></a>
        <div class="submenu">
          <a href="specialization.php"><i class="fas fa-user-plus"></i> Add Specialization </a>
        </div>
      </li>

      <li id="mechanicToggle">
        <a href="javascript:void(0)"><i class="fas fa-tools"></i> Mechanics <i class="fas fa-chevron-down" style="float:right;"></i></a>
        <div class="submenu">
          <a href="mechanic.php"><i class="fas fa-user-plus"></i> Add Mechanic</a>
        </div>
      </li>
     <li>
    <a href="payment.php"><i class="fas fa-wallet"></i> Payment</a>
</li>

    

      <li id="settingsToggle">
        <a href="javascript:void(0)"><i class="fas fa-cog"></i> Settings <i class="fas fa-chevron-down" style="float:right;"></i></a>
        <div class="submenu">
          <a href="profile2.php"><i class="fas fa-user-circle"></i> Profile</a>
          <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </li>
    </ul>
  </div>

  <!-- Main Content -->
  <div class="main">
  </div>  

  <!-- JavaScript -->
  <script>
    const toggleBtn = document.getElementById('toggleSidebar');
    const closeBtn = document.getElementById('closeSidebar');
    const sidebar = document.getElementById('sidebar');

    const toggleItems = [
      "settingsToggle",
      "specializationToggle",
      "mechanicToggle",
      "customerToggle",
      "vehicleTypeToggle",
      "vehicleCategoryToggle",  // Moved here under vehicleTypeToggle
      "vehicleToggle",
      "brandTypeToggle"
    ];

    toggleItems.forEach(id => {
      const item = document.getElementById(id);
      if (item) {
        item.addEventListener('click', () => {
          item.classList.toggle('active');
        });
      }
    });

    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('active');
    });

    closeBtn.addEventListener('click', () => {
      sidebar.classList.remove('active');
    });
  </script>
</body>
</html> 