<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}
?>

<?php
include 'config.php';
$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mechanicSpecialization = ucwords(strtolower(trim($_POST["special"])));

    if (!empty($mechanicSpecialization)) {
        // Check if the specialization already exists
        $checkStmt = $conn->prepare("SELECT id FROM specialization WHERE specialization = ?");
        $checkStmt->bind_param("s", $mechanicSpecialization);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows > 0) {
            $error = "'$mechanicSpecialization' already exists.";
        } else {
            // Insert new specialization
            $stmt = $conn->prepare("INSERT INTO specialization (specialization) VALUES (?)");
            $stmt->bind_param("s", $mechanicSpecialization);

            if ($stmt->execute()) {
                $success = "'$mechanicSpecialization' added successfully.";
                $_POST['special'] = ""; // clear input
            } else {
                $error = "Failed to add specialization.";
            }
            $stmt->close();
        }
        $checkStmt->close();
    } else {
        $error = "Please enter a specialization.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Mechanic Specialization</title>
  <link rel="icon" type="image/jpeg" href="uploads/icon.jpg">
  <style>
    body {
      background: #121212;
      color: #fff;
      font-family: Arial, sans-serif;
    }
    .add-customer-form {
      padding: 20px;
    }
    .add-customer-form input {
      width: 70%;
      padding: 12px;
      margin-bottom: 20px;
      border: 1px solid #ff6f00;
      border-radius: 6px;
      background: #1e1e1e;
      color: #fff;
      font-size: 16px;
    }
    .add-customer-form input::placeholder {
      color: #bbb;
    }
    .add-customer-form button {
      width: 25%;
      padding: 12px;
      background: #ff6f00;
      color: #000;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
    }
    .add-customer-form button:hover {
      background: #ff8c00;
    }
    .success-msg {
      font-size: 15px;
      color: rgb(111, 247, 111);
    }
    .error-msg {
      font-size: 15px;
      color: red;
    }
  </style>
</head>
<body>
  <?php include 'sidebar.php'; ?>
  <div class="main">
    <h1>Welcome to Mechano</h1>
    <hr style="margin: 30px 0; border-color: #444;">
    <h2>Add Mechanic Specialization</h2>

    <form method="POST" class="add-customer-form">
      <input type="text" name="special" placeholder="Enter the Mechanic specialization"
             value="<?php echo isset($_POST['special']) ? htmlspecialchars($_POST['special']) : ''; ?>"><br>
      <button type="submit">Add Mechanic Specialization</button>
      
      <?php if ($success): ?>
        <p class="success-msg"><?php echo htmlspecialchars($success); ?></p>
      <?php elseif ($error): ?>
        <p class="error-msg"><?php echo htmlspecialchars($error); ?></p>
      <?php endif; ?>
    </form>
  </div>
</body>
</html>
