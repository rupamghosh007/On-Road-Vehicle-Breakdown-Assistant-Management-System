<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}
?>

<?php
include 'config.php'; // DB connection

// AJAX handler to fetch categories based on vehicle type
if (isset($_GET['action']) && $_GET['action'] === 'fetch_categories') {
    header('Content-Type: application/json');
    $vehical_type = $_GET['vehical_type'] ?? '';
    if (empty($vehical_type)) {
        echo json_encode(['error' => 'vehical_type parameter missing']);
        exit;
    }
    $sql = "SELECT DISTINCT category_name FROM vehicle_category WHERE vehical_type = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo json_encode(['error' => 'Prepare failed: ' . $conn->error]);
        exit;
    }
    $stmt->bind_param("s", $vehical_type);
    $stmt->execute();
    $result = $stmt->get_result();
    $categories = [];
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row['category_name'];
    }
    $stmt->close();
    echo json_encode($categories);
    exit;
}

// AJAX handler to fetch brands based on vehicle type and category
if (isset($_GET['action']) && $_GET['action'] === 'fetch_brands') {
    header('Content-Type: application/json');
    $vehical_type = $_GET['vehical_type'] ?? '';
    $vehicle_category = $_GET['vehicle_category'] ?? '';
    if (empty($vehical_type) || empty($vehicle_category)) {
        echo json_encode(['error' => 'Required parameters missing']);
        exit;
    }
    $sql = "SELECT brand_name FROM brand WHERE vehical_type = ? AND vehicle_category = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo json_encode(['error' => 'Prepare failed: ' . $conn->error]);
        exit;
    }
    $stmt->bind_param("ss", $vehical_type, $vehicle_category);
    $stmt->execute();
    $result = $stmt->get_result();
    $brands = [];
    while ($row = $result->fetch_assoc()) {
        $brands[] = $row['brand_name'];
    }
    $stmt->close();
    echo json_encode($brands);
    exit;
}

// Fetch vehicle types for dropdown (from vehicle_category table)
$vehicalTypes = [];
$sql = "SELECT DISTINCT vehical_type FROM vehical_type";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $vehicalTypes[] = $row['vehical_type'];
    }
}

// Handle form submission
$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addVehical'])) {
    $vehical_type = $_POST['vehical_type'] ?? '';
    $vehicle_category = $_POST['vehicle_category'] ?? '';
    $brand_name = $_POST['brand'] ?? '';
    $model = trim($_POST['model'] ?? '');

    if ($vehical_type && $vehicle_category && $brand_name && $model) {
        // Check for duplicate
        $checkSQL = "SELECT id FROM vehical WHERE vehical_type = ? AND vehicle_category = ? AND brand = ? AND model = ?";
        $stmt = $conn->prepare($checkSQL);
        if ($stmt) {
            $stmt->bind_param("ssss", $vehical_type, $vehicle_category, $brand_name, $model);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $error = "This vehicle already exists.";
            } else {
                $stmt->close();
                // Insert new vehicle
                $insertSQL = "INSERT INTO vehical (vehical_type, vehicle_category, brand, model) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($insertSQL);
                if ($stmt) {
                    $stmt->bind_param("ssss", $vehical_type, $vehicle_category, $brand_name, $model);
                    if ($stmt->execute()) {
                        $success = "Vehicle added successfully: " .
                                   htmlspecialchars($vehical_type) . " → " .
                                   htmlspecialchars($vehicle_category) . " → " .
                                   htmlspecialchars($brand_name) . " → " .
                                   htmlspecialchars($model);
                    }
                    
                        
                    else {
                        $error = "Insert failed: " . $stmt->error;
                    }
                    $stmt->close();
                } else {
                    $error = "Failed to prepare insert query: " . $conn->error;
                }
            }
        } else {
            $error = "Failed to prepare duplicate check query: " . $conn->error;
        }
    } else {
        $error = "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Add Vehicle</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        body {
            background: #0d0d0d;
            color: #fff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .main {
            padding: 30px 50px;
        }
        h1, h2 {
            color: #fff;
        }
        hr {
            border-color: #333;
            margin: 20px 0;
        }
        form#vehicalForm {
            display: flex;
            flex-direction: column;
            gap: 15px;
            max-width: 500px;
            margin-top: 30px;
        }
        form#vehicalForm label {
            font-weight: bold;
        }
        form#vehicalForm select,
        form#vehicalForm input[type="text"] {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #ff7b00;
            border-radius: 6px;
            background-color: #1a1a1a;
            color: #fff;
            font-size: 16px;
        }
        form#vehicalForm input::placeholder {
            color: #aaa;
        }
        form#vehicalForm button {
            background-color: #ff6f00;
            color: #000;
            padding: 12px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
        }
        form#vehicalForm button:hover {
            background-color: #ff8c00;
        }
        .success-msg {
            font-size: 15px;
            color: rgb(84, 251, 170);
        }
        .error-msg {
            font-size: 15px;
            color: red;
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="main">
    <h1>Welcome to Mechano</h1>
    <hr />
    <h2>Add Vehicle</h2>
    <form method="POST" id="vehicalForm">
        <!-- VEHICLE TYPE -->
        <label for="vehical_type">Vehicle Type</label>
        <select name="vehical_type" id="vehical_type" required>
            <option value="">Select Vehicle Type</option>
            <?php foreach ($vehicalTypes as $type): ?>
                <option value="<?= htmlspecialchars($type) ?>"><?= htmlspecialchars($type) ?></option>
            <?php endforeach; ?>
        </select>

        <!-- VEHICLE CATEGORY -->
        <label for="vehicle_category">Vehicle Category</label>
        <select name="vehicle_category" id="vehicle_category" required>
            <option value="">Select Category</option>
        </select>

        <!-- BRAND -->
        <label for="brand">Brand</label>
        <select name="brand" id="brand" required>
            <option value="">Select Brand</option>
        </select>

        <!-- MODEL -->
        <label for="model">Model</label>
        <input type="text" name="model" placeholder="Enter Model" required />

        <button type="submit" name="addVehical">Add Vehicle</button>

        <?php if (!empty($success)): ?>
            <p class="success-msg"><?= htmlspecialchars($success) ?></p>
        <?php elseif (!empty($error)): ?>
            <p class="error-msg"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
    </form>
</div>

<script>
document.getElementById('vehical_type').addEventListener('change', function () {
    const vehicalType = this.value;
    const categorySelect = document.getElementById('vehicle_category');
    const brandSelect = document.getElementById('brand');

    // Reset categories and brands
    categorySelect.innerHTML = '<option value="">Loading categories...</option>';
    brandSelect.innerHTML = '<option value="">Select Brand</option>';

    if (!vehicalType) {
        categorySelect.innerHTML = '<option value="">Select Category</option>';
        return;
    }

    // Fetch categories for selected vehicle type
    fetch(`<?= basename(__FILE__) ?>?action=fetch_categories&vehical_type=${encodeURIComponent(vehicalType)}`)
        .then(response => response.json())
        .then(data => {
            categorySelect.innerHTML = '<option value="">Select Category</option>';
            if (!data || data.error || data.length === 0) {
                categorySelect.innerHTML = `<option value="">${data.error || 'No categories found'}</option>`;
                return;
            }
            data.forEach(category => {
                const option = document.createElement('option');
                option.value = category;
                option.textContent = category;
                categorySelect.appendChild(option);
            });
        })
        .catch(err => {
            console.error('Error fetching categories:', err);
            categorySelect.innerHTML = '<option value="">Failed to load categories</option>';
        });
});

// Load brands when both vehical_type and vehicle_category selected
function loadBrands() {
    const vehicalType = document.getElementById('vehical_type').value;
    const vehicleCategory = document.getElementById('vehicle_category').value;
    const brandSelect = document.getElementById('brand');

    if (!vehicalType || !vehicleCategory) {
        brandSelect.innerHTML = '<option value="">Select Brand</option>';
        return;
    }

    brandSelect.innerHTML = '<option value="">Loading brands...</option>';

    fetch(`<?= basename(__FILE__) ?>?action=fetch_brands&vehical_type=${encodeURIComponent(vehicalType)}&vehicle_category=${encodeURIComponent(vehicleCategory)}`)
        .then(response => response.json())
        .then(data => {
            brandSelect.innerHTML = '<option value="">Select Brand</option>';
            if (!data || data.error || data.length === 0) {
                brandSelect.innerHTML = `<option value="">${data.error || 'No brands found'}</option>`;
                return;
            }
            data.forEach(brand => {
                const option = document.createElement('option');
                option.value = brand;
                option.textContent = brand;
                brandSelect.appendChild(option);
            });
        })
        .catch(err => {
            console.error('Error fetching brands:', err);
            brandSelect.innerHTML = '<option value="">Failed to load brands</option>';
        });
}

document.getElementById('vehicle_category').addEventListener('change', loadBrands);
function capitalizeWords(str) {
    return str.replace(/\b\w/g, char => char.toUpperCase());
}

document.querySelector('input[name="model"]').addEventListener('input', function () {
    this.value = capitalizeWords(this.value);
});


</script>
</body>
</html>
