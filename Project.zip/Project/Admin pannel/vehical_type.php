<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}


include 'config.php';

$success = "";
$error = "";
$vehical_type_input = ""; // to retain input in form

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vehical_type_input = trim($_POST["vehical_type"] ?? "");

    // Convert to Title Case: each word's first letter capitalized
    $vehical_type = ucwords(strtolower($vehical_type_input));

    if (empty($vehical_type)) {
        $error = "Vehicle type cannot be empty.";
    } else {
        // Check if vehicle type already exists (case-insensitive)
        $check_stmt = $conn->prepare("SELECT id FROM vehical_type WHERE LOWER(vehical_type) = LOWER(?)");
        $check_stmt->bind_param("s", $vehical_type);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            $error = "This vehicle type already exists.";
        } else {
            // Insert into database
            $stmt = $conn->prepare("INSERT INTO vehical_type (vehical_type) VALUES (?)");
            $stmt->bind_param("s", $vehical_type);

            if ($stmt->execute()) {
                $success = "'" . htmlspecialchars($vehical_type) . "' added successfully.";
                $vehical_type_input = ""; // clear form input
            } else {
                $error = "Failed to add vehicle type: " . $stmt->error;
            }
            $stmt->close();
        }
        $check_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Add Vehicle Type</title>
    <link rel="icon" type="image/jpeg" href="uploads/icon.jpg" />
    <style>
        body {
            background-color: #121212;
            color: #fff;
            font-family: Arial, sans-serif;
        }
        .add-customer-form input {
            width: 70%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ff6f00;
            border-radius: 6px;
            background: #1e1e1e;
            color: #fff;
            font-size: 16px;
        }
        .add-customer-form input::placeholder {
            color: #bbb;
        }
        .add-customer-form button {
            width: 20%;
            padding: 12px;
            background: #ff6f00;
            color: #000;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }
        .add-customer-form button:hover {
            background: #ff8c00;
        }
        .success-msg {
            margin-top: 10px;
            font-size: 15px;
            color: rgb(84, 251, 170);
        }
        .error-msg {
            margin-top: 10px;
            font-size: 15px;
            color: #ff4c4c;
        }
        .main {
            padding: 30px;
            max-width: 800px;
            margin-left: 220px;
        }
        h1, h2 {
            margin-bottom: 20px;
        }
        hr {
            border-color: #444;
        }
    </style>
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main">
    <h1>Welcome to Mechano</h1>
    <hr />
    <h2>Add Vehicle Type</h2>

    <form method="POST" class="add-customer-form" novalidate>
        <input
            type="text"
            name="vehical_type"
            placeholder="Enter vehicle type"
            value="<?php echo htmlspecialchars($vehical_type_input); ?>"
            required
        /><br>

        <button type="submit">Add Vehicle Type</button>

        <?php if ($success): ?>
            <p class="success-msg"><?php echo $success; ?></p>
        <?php elseif ($error): ?>
            <p class="error-msg"><?php echo $error; ?></p>
        <?php endif; ?>
    </form>
</div>

</body>
</html>
