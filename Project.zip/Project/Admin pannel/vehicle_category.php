<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['USR']) || $_SESSION['role'] !== 'admin') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}
?>

<?php
include 'config.php';

// Enable full error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$success = "";
$error = "";
$category_name_input = ""; // Initialize

// Fetch all vehicle types for dropdown
$vehicalTypes = [];
$result = $conn->query("SELECT id, vehical_type FROM vehical_type");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $vehicalTypes[] = $row;
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category_name_input = trim($_POST["category_name"]);
    $category_name = ucwords(strtolower($category_name_input)); // Title case
    $vehical_type_id = intval($_POST["vehical_type_id"]);

    if (empty($category_name) || $vehical_type_id == 0) {
        $error = "Please enter a vehicle category and select a vehicle type.";
    } else {
        // Get vehicle type name
        $type_stmt = $conn->prepare("SELECT vehical_type FROM vehical_type WHERE id = ?");
        $type_stmt->bind_param("i", $vehical_type_id);
        $type_stmt->execute();
        $type_result = $type_stmt->get_result();

        if ($type_row = $type_result->fetch_assoc()) {
            $vehical_type_name = $type_row['vehical_type'];

            // Check if category exists (case-insensitive)
            $check_stmt = $conn->prepare("SELECT id FROM vehicle_category WHERE LOWER(category_name) = LOWER(?) AND vehical_type = ?");
            $check_stmt->bind_param("ss", $category_name, $vehical_type_name);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();

            if ($check_result->num_rows > 0) {
                $error = "Vehicle category '$category_name' for vehicle type '$vehical_type_name' already exists.";
            } else {
                // Insert new vehicle category
                $stmt = $conn->prepare("INSERT INTO vehicle_category (category_name, vehical_type) VALUES (?, ?)");
                $stmt->bind_param("ss", $category_name, $vehical_type_name);

                if ($stmt->execute()) {
                    $success = htmlspecialchars($category_name) . " added successfully.";
                    $category_name_input = ""; // Clear input
                } else {
                    $error = "Failed to add vehicle category: " . $stmt->error;
                }

                $stmt->close();
            }

            $check_stmt->close();
        } else {
            $error = "Invalid vehicle type selected.";
        }

        $type_stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Vehicle Category</title>
    <link rel="icon" type="image/jpeg" href="uploads/icon.jpg">
    <style>
        .add-customer-form input, .add-customer-form select {
            width: 70%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ff6f00;
            border-radius: 6px;
            background: #1e1e1e;
            color: #fff;
            font-size: 16px;
        }

        .add-customer-form input::placeholder,
        .add-customer-form select option {
            color: #bbb;
        }

        .add-customer-form button {
            width: 20%;
            padding: 12px;
            background: #ff6f00;
            color: #000;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .add-customer-form button:hover {
            background: #ff8c00;
        }

        .success-msg {
            margin-top: 10px;
            font-size: 15px;
            color: rgb(84, 251, 170);
        }

        .error-msg {
            margin-top: 10px;
            font-size: 15px;
            color: red;
        }
    </style>
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main">
    <h1>Welcome to Mechano</h1>
    <hr style="margin: 30px 0; border-color: #444;">
    <h2>Add Vehicle Category</h2>

    <form method="POST" class="add-customer-form">
        <!-- Dropdown for vehicle type -->
        <select name="vehical_type_id" required>
            <option value="" disabled <?php if (!isset($_POST['vehical_type_id'])) echo 'selected'; ?>>Select Vehicle Type</option>
            <?php foreach ($vehicalTypes as $type): ?>
                <option value="<?php echo $type['id']; ?>"
                    <?php echo (isset($_POST['vehical_type_id']) && $_POST['vehical_type_id'] == $type['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($type['vehical_type']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <!-- Input for vehicle category name -->
        <input type="text" name="category_name" placeholder="Enter the vehicle category"
               value="<?php echo htmlspecialchars($category_name_input); ?>" required><br>

        <button type="submit" name="addCustomer">Add Category</button>

        <?php if ($success): ?>
            <p class="success-msg"><?php echo $success; ?></p>
        <?php elseif ($error): ?>
            <p class="error-msg"><?php echo $error; ?></p>
        <?php endif; ?>
    </form>
</div>

</body>
</html>
