-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2025 at 09:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mechano`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `name`, `password`, `email`, `contact_number`, `photo`) VALUES
(1, 'admin', 'Rupam Ghosh', '1234', 'rupamilampur@gmail.com', '9832130985', 'uploads/my photo.jpg'),
(2, 'ankita002', 'Ankita dey', 'ankita99', 'ankitadey399@gmail.com', '8159085431', 'uploads/admin2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL,
  `brand_name` varchar(100) NOT NULL,
  `vehical_type` varchar(50) NOT NULL,
  `vehicle_category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `brand_name`, `vehical_type`, `vehicle_category`) VALUES
(188, 'ABC', '', ''),
(183, 'Aprilia', 'Two  Wheeler', 'Motorcycle'),
(170, 'Bajaj', 'Two  Wheeler', 'Motorcycle'),
(185, 'Benelli', 'Two  Wheeler', 'Motorcycle'),
(179, 'Bmw Motorrad', 'Two  Wheeler', 'Motorcycle'),
(186, 'Cf Moto', 'Two  Wheeler', 'Motorcycle'),
(181, 'Ducati', 'Two  Wheeler', 'Motorcycle'),
(180, 'Harley_ Davidson', 'Two  Wheeler', 'Motorcycle'),
(168, 'Hero', 'Two  Wheeler', 'Motorcycle'),
(174, 'Honda', 'Two  Wheeler', 'Motorcycle'),
(187, 'Husqvarna', 'Two  Wheeler', 'Motorcycle'),
(177, 'Kawasaki', 'Two  Wheeler', 'Motorcycle'),
(178, 'Ktm', 'Two  Wheeler', 'Motorcycle'),
(173, 'Mahindra', 'Two  Wheeler', 'Motorcycle'),
(184, 'Mv Agust', 'Two  Wheeler', 'Motorcycle'),
(172, 'Royal Enfield', 'Two  Wheeler', 'Motorcycle'),
(176, 'Suzuki', 'Two  Wheeler', 'Motorcycle'),
(182, 'Triumph', 'Two  Wheeler', 'Motorcycle'),
(171, 'Tvs', 'Two  Wheeler', 'Motorcycle'),
(175, 'Yamaha', 'Two  Wheeler', 'Motorcycle');

-- --------------------------------------------------------

--
-- Table structure for table `breakdown_requests`
--

CREATE TABLE `breakdown_requests` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `vehicle_type` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `breakdown_type` varchar(255) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `request_time` varchar(50) DEFAULT NULL,
  `status` enum('pending','assigned','rejected','completed') NOT NULL,
  `mechanic_id` int(11) DEFAULT NULL,
  `vehicle_category` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `breakdown_requests`
--

INSERT INTO `breakdown_requests` (`id`, `customer_id`, `vehicle_type`, `brand`, `model`, `location`, `breakdown_type`, `contact`, `request_time`, `status`, `mechanic_id`, `vehicle_category`) VALUES
(71, 0, 'Two  Wheeler', 'Hero', 'Hunk', 'kolkata', 'oil change', '8159085431', '2025-06-22 (Sunday) 22:06:04', 'completed', 43, 'Motorcycle'),
(72, 0, 'Two  Wheeler', 'Hero', 'Xtream Sports(150cc,Old Gen)', 'suhari', 'break repairing', '8159085431', '2025-06-22 (Sunday) 23:21:01', 'assigned', 43, 'Motorcycle'),
(73, 0, 'Two  Wheeler', 'Hero', 'Ignitor', 'suhari', 'puncture', '8159085431', '2025-06-28 (Saturday) 07:32:27', 'pending', 57, 'Motorcycle'),
(74, 0, 'Two  Wheeler', 'Hero', 'Karizma ZMR S', 'bardhaman', 'break repairing', '9867543569', '2025-06-28 (Saturday) 10:51:33', 'completed', 44, 'Motorcycle'),
(75, 0, 'Two  Wheeler', 'Hero', 'Karizma R', 'kolkata', '555', '8159085431', '2025-06-28 (Saturday) 11:21:43', 'assigned', 44, 'Motorcycle');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT 'default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `phone`, `email`, `password`, `photo`) VALUES
(67, 'Aarav Sharma', '9876543210', 'aarav.sharma1@gmail.com', 'pass1234', '1750173355_holi2.jpg'),
(68, 'Vivaan Patel', '9876543211', 'vivaan.patel2@gmail.com', 'pass5678', 'default.jpg'),
(69, 'Aditya Singh', '9876543212', 'aditya.singh3@gmail.com', 'pass91011', 'default.jpg'),
(70, 'Arjun Kumar', '9876543213', 'arjun.kumar4@gmail.com', 'pass1213', 'default.jpg'),
(71, 'Sai Reddy', '9876543214', 'sai.reddy5@gmail.com', 'pass1415', 'default.jpg'),
(72, 'Krishna Das', '9876543215', 'krishna.das6@gmail.com', 'pass1617', 'default.jpg'),
(73, 'Rohan Mehta', '9876543216', 'rohan.mehta7@gmail.com', 'pass1819', 'default.jpg'),
(74, 'Karan Joshi', '9876543217', 'karan.joshi8@gmail.com', 'pass2021', 'default.jpg'),
(75, 'Mihir Desai', '9876543218', 'mihir.desai9@gmail.com', 'pass2223', 'default.jpg'),
(76, 'Nikhil Rao', '9876543219', 'nikhil.rao10@gmail.com', 'pass2425', 'default.jpg'),
(77, 'Rajesh Gupta', '9876543220', 'rajesh.gupta11@gmail.com', 'pass2627', 'default.jpg'),
(78, 'Siddharth Iyer', '9876543221', 'siddharth.iyer12@gmail.com', 'pass2829', 'default.jpg'),
(79, 'Harsh Verma', '9876543222', 'harsh.verma13@gmail.com', 'pass3031', 'default.jpg'),
(80, 'Manish Singh', '9876543223', 'manish.singh14@gmail.com', 'pass3233', 'default.jpg'),
(81, 'Abhishek Kumar', '9876543224', 'abhishek.kumar15@gmail.com', 'pass3435', 'default.jpg'),
(83, 'Vikram Patel', '9876543226', 'vikram.patel17@gmail.com', 'pass3839', 'default.jpg'),
(84, 'Deepak Choudhary', '9876543227', 'deepak.choudhary18@gmail.com', 'pass4041', 'default.jpg'),
(85, 'Saurabh Joshi', '9876543228', 'saurabh.joshi19@gmail.com', 'pass4243', 'default.jpg'),
(86, 'Ritesh Mehta', '9876543229', 'ritesh.mehta20@gmail.com', 'pass4445', 'default.jpg'),
(87, 'Kunal Deshmukh', '9876543230', 'kunal.deshmukh21@gmail.com', 'pass4647', 'default.jpg'),
(88, 'Sanjay Nair', '9876543231', 'sanjay.nair22@gmail.com', 'pass4849', 'default.jpg'),
(89, 'Raghav Singh', '9876543232', 'raghav.singh23@gmail.com', 'pass5051', 'default.jpg'),
(91, 'Rahul Verma', '9876543234', 'rahul.verma25@gmail.com', 'pass5455', 'default.jpg'),
(92, 'Neeraj Reddy', '9876543235', 'neeraj.reddy26@gmail.com', 'pass5657', 'default.jpg'),
(93, 'Siddhant Sharma', '9876543236', 'siddhant.sharma27@gmail.com', 'pass5859', 'default.jpg'),
(94, 'Ashwin Joshi', '9876543237', 'ashwin.joshi28@gmail.com', 'pass6061', 'default.jpg'),
(95, 'Raman Gupta', '9876543238', 'raman.gupta29@gmail.com', 'pass6263', 'default.jpg'),
(96, 'Vivek Mehta', '9876543239', 'vivek.mehta30@gmail.com', 'pass6465', 'default.jpg'),
(97, 'Nitin Reddy', '9876543240', 'nitin.reddy31@gmail.com', 'pass6667', 'default.jpg'),
(98, 'Varun Das', '9876543241', 'varun.das32@gmail.com', 'pass6869', 'default.jpg'),
(99, 'Suresh Kumar', '9876543242', 'suresh.kumar33@gmail.com', 'pass7071', 'default.jpg'),
(100, 'Kartik Patel', '9876543243', 'kartik.patel34@gmail.com', 'pass7273', 'default.jpg'),
(101, 'Sanjay Mehta', '9876543244', 'sanjay.mehta35@gmail.com', 'pass7475', 'default.jpg'),
(102, 'Manoj Joshi', '9876543245', 'manoj.joshi36@gmail.com', 'pass7677', 'default.jpg'),
(103, 'Aakash Singh', '9876543246', 'aakash.singh37@gmail.com', 'pass7879', 'default.jpg'),
(104, 'Pranav Sharma', '9876543247', 'pranav.sharma38@gmail.com', 'pass8081', 'default.jpg'),
(105, 'Rohit Gupta', '9876543248', 'rohit.gupta39@gmail.com', 'pass8283', 'default.jpg'),
(107, 'Jayesh Reddy', '9876543250', 'jayesh.reddy41@gmail.com', 'pass8687', 'default.jpg'),
(108, 'Akash Das', '9876543251', 'akash.das42@gmail.com', 'pass8889', 'default.jpg'),
(109, 'Sanjay Kumar', '9876543252', 'sanjay.kumar43@gmail.com', 'pass9091', 'default.jpg'),
(110, 'Tarun Patel', '9876543253', 'tarun.patel44@gmail.com', 'pass9293', 'default.jpg'),
(111, 'Anil Sharma', '9876543254', 'anil.sharma45@gmail.com', 'pass9495', 'default.jpg'),
(112, 'Vinay Joshi', '9876543255', 'vinay.joshi46@gmail.com', 'pass9697', 'default.jpg'),
(113, 'Rakesh Singh', '9876543256', 'rakesh.singh47@gmail.com', 'pass9899', 'default.jpg'),
(114, 'Raj Kumar', '9876543257', 'raj.kumar48@gmail.com', 'pass100101', 'default.jpg'),
(115, 'Mohit Mehta', '9876543258', 'mohit.mehta49@gmail.com', 'pass102103', 'default.jpg'),
(116, 'Sahil Patel', '9876543259', 'sahil.patel50@gmail.com', 'pass104105', 'default.jpg'),
(117, 'ranu dey', '9832130985', 'roy@gmail.co', '1234', 'default.jpg'),
(118, 'Anik Santra', '9832103995', 'aniksantra1969@gmail.com', 'anik@2003', 'default.jpg'),
(119, 'Dipan Roy', '8965426523', 'dipan@gmail.com', 'abc123', 'default.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `mechanic_name` varchar(255) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_method` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `customer_name`, `mechanic_name`, `total_amount`, `payment_date`, `payment_method`) VALUES
(9, 'Rupam Ghosh', 'Arrav Meheta', 550.00, '2025-06-21 19:31:57', 'Cash'),
(10, 'Ankita', 'Arrav Meheta', 1500.00, '2025-06-21 19:46:39', 'Debit Card'),
(11, 'ram', 'Arrav Meheta', 5506.00, '2025-06-21 19:52:23', 'UPI'),
(12, 'swam', 'Rupam Ghosh', 250.00, '2025-06-21 20:13:18', 'Credit Card'),
(13, 'deep', 'Rupam Ghosh', 550.00, '2025-06-22 16:45:52', 'Cash'),
(14, 'deep', 'Rupam Ghosh', 550.00, '2025-06-22 16:48:08', 'Cash'),
(15, '899k9k', 'Arrav Meheta', 1020.00, '2025-06-28 06:50:52', 'Cash');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_services`
--

CREATE TABLE `invoice_services` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `service_description` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice_services`
--

INSERT INTO `invoice_services` (`id`, `invoice_id`, `service_description`, `amount`) VALUES
(1, 14, 'oil change', 550.00),
(2, 15, 'oil', 500.00),
(3, 15, 'jimmo', 520.00);

-- --------------------------------------------------------

--
-- Table structure for table `mechanic`
--

CREATE TABLE `mechanic` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `specializations` varchar(200) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mechanic`
--

INSERT INTO `mechanic` (`id`, `name`, `phone`, `specializations`, `photo`, `email`, `password`) VALUES
(43, 'Rupam Ghosh', '9832130985', '13', 'mechanic7.jpg', 'rupam@gmail.com', 'rupam99'),
(44, 'Arrav Meheta', '8159085431', '14', '683eaa9a08fb3_mechanic3.jpg', 'aaravmehta92@gmail.com', 'aarav99'),
(45, 'Sk Asraful', '9832344494', '18, 20', 'mechanic3.jpg', 'zxy123@gmail.com', '121345'),
(57, 'Santanu Dutta', '8637399648', '19', 'mechanic4.jpg', 'santanu677@gmail.com', 'nunu2123');

-- --------------------------------------------------------

--
-- Table structure for table `mechanic_spe_map`
--

CREATE TABLE `mechanic_spe_map` (
  `id` int(11) NOT NULL,
  `machenic_id` int(11) NOT NULL,
  `specialization_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mechanic_spe_map`
--

INSERT INTO `mechanic_spe_map` (`id`, `machenic_id`, `specialization_id`) VALUES
(1, 4, 2),
(2, 4, 3),
(3, 17, 2),
(4, 17, 3),
(5, 19, 3),
(6, 21, 3),
(7, 22, 3),
(8, 27, 3),
(9, 28, 2),
(10, 39, 3),
(11, 40, 2),
(12, 41, 1),
(13, 42, 1),
(14, 43, 13),
(15, 44, 14),
(16, 45, 18),
(17, 45, 20),
(18, 56, 19),
(19, 57, 19);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` varchar(50) NOT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `details` varchar(500) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `specialization`
--

CREATE TABLE `specialization` (
  `id` int(11) NOT NULL,
  `specialization` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `specialization`
--

INSERT INTO `specialization` (`id`, `specialization`) VALUES
(14, 'Battery & Electrical Technician'),
(18, 'Break & Suspension Mechanic'),
(20, 'Engine Specialist'),
(19, 'Exhaust System Specialist'),
(15, 'Fuel System Specialist'),
(16, 'Locksmith Specialist'),
(13, 'Tire & Puncture Specialist'),
(17, 'Wiring &lighting Specialist');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user',
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vehical`
--

CREATE TABLE `vehical` (
  `id` int(11) NOT NULL,
  `vehical_type` varchar(255) DEFAULT NULL,
  `vehicle_category` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehical`
--

INSERT INTO `vehical` (`id`, `vehical_type`, `vehicle_category`, `brand`, `model`) VALUES
(286, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Xpluse 200'),
(287, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Xpluse 200T'),
(288, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Karizma ZMR'),
(289, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Karizma R'),
(290, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Karizma ZMR S'),
(291, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Ignitor'),
(292, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Hunk'),
(293, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Achiever'),
(294, 'Two  Wheeler', 'Motorcycle', 'Hero', 'CBZ Xtream'),
(295, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Xtream 160R'),
(296, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Xtream 200'),
(297, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Xtream 200S'),
(298, 'Two  Wheeler', 'Motorcycle', 'Hero', 'Xtream Sports(150cc,Old Gen)'),
(299, 'Two  Wheeler', 'Motorcycle', 'Bajaj', 'Pulsar 125'),
(300, 'Two  Wheeler', 'Motorcycle', 'Bajaj', 'Pulsar 135 LS'),
(301, 'Two  Wheeler', 'Motorcycle', 'Bajaj', 'Pulsar 150'),
(302, 'Two  Wheeler', 'Motorcycle', 'Bajaj', 'Pulsar 180 UG4'),
(303, 'Two  Wheeler', 'Motorcycle', 'Tvs', 'Pulsar 220F'),
(304, 'Two  Wheeler', 'Motorcycle', 'Tvs', 'Pulsar NS160'),
(305, 'Two  Wheeler', 'Motorcycle', 'Bajaj', 'Pulsar NS220'),
(306, 'Two  Wheeler', 'Motorcycle', 'Bajaj', 'Pulsar Rs200');

-- --------------------------------------------------------

--
-- Table structure for table `vehical_type`
--

CREATE TABLE `vehical_type` (
  `id` int(11) NOT NULL,
  `vehical_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehical_type`
--

INSERT INTO `vehical_type` (`id`, `vehical_type`) VALUES
(6, 'Two  Wheeler'),
(7, 'Three Wheeler'),
(8, 'Four Wheeler'),
(9, 'Commercial Vehicle'),
(10, 'Public Transport Vehicle'),
(11, 'Emergency Vehicle'),
(12, 'Special Purpose Vehicle');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_category`
--

CREATE TABLE `vehicle_category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `vehical_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicle_category`
--

INSERT INTO `vehicle_category` (`id`, `category_name`, `vehical_type`) VALUES
(8, 'Electric Motorbike', 'Two  Wheeler'),
(7, 'Electric Scooter', 'Two  Wheeler'),
(5, 'Moped', 'Two  Wheeler'),
(3, 'Motorcycle', 'Two  Wheeler'),
(4, 'Scooter', 'Two  Wheeler');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_brand_per_type` (`brand_name`,`vehical_type`,`vehicle_category`);

--
-- Indexes for table `breakdown_requests`
--
ALTER TABLE `breakdown_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_services`
--
ALTER TABLE `invoice_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `mechanic`
--
ALTER TABLE `mechanic`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`);

--
-- Indexes for table `mechanic_spe_map`
--
ALTER TABLE `mechanic_spe_map`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specialization`
--
ALTER TABLE `specialization`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `specialization` (`specialization`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehical`
--
ALTER TABLE `vehical`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_vehicle` (`vehical_type`,`brand`,`model`);

--
-- Indexes for table `vehical_type`
--
ALTER TABLE `vehical_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_category`
--
ALTER TABLE `vehicle_category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_category_type` (`category_name`,`vehical_type`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=189;

--
-- AUTO_INCREMENT for table `breakdown_requests`
--
ALTER TABLE `breakdown_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `invoice_services`
--
ALTER TABLE `invoice_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mechanic`
--
ALTER TABLE `mechanic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `mechanic_spe_map`
--
ALTER TABLE `mechanic_spe_map`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `specialization`
--
ALTER TABLE `specialization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `vehical`
--
ALTER TABLE `vehical`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=307;

--
-- AUTO_INCREMENT for table `vehical_type`
--
ALTER TABLE `vehical_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `vehicle_category`
--
ALTER TABLE `vehicle_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice_services`
--
ALTER TABLE `invoice_services`
  ADD CONSTRAINT `invoice_services_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
