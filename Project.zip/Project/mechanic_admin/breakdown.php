<?php
session_start();

// Check if mechanic is logged in
if (!isset($_SESSION['mec_id']) || $_SESSION['role'] !== 'mechanic') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "mechano");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle actions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $requestId = $_POST['request_id'];
    $action = $_POST['action'];

    if ($action === "accept") {
         
        $stmt = $conn->prepare("UPDATE breakdown_requests SET status='assigned' WHERE id=?");
        $stmt->bind_param("i", $requestId);
        $stmt->execute();
          
        $_SESSION['accepted_request'] = $requestId;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    if ($action === "verify_otp") {
        $userOtp = $_POST['otp'];
        $hiddenOtp = $_POST['hidden_otp'];

        if ($userOtp == $hiddenOtp) {
            $stmt = $conn->prepare("UPDATE breakdown_requests SET status='completed' WHERE id=?");
            $stmt->bind_param("i", $requestId);
            $stmt->execute();
            $_SESSION['message'] = "✅ Request ID $requestId marked as <strong>completed</strong>.";
        } else {
            $_SESSION['message'] = "<span style='color:red;'>❌ Incorrect OTP for request ID $requestId.</span>";
        }

        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    if ($action === "reject") {
        $stmt = $conn->prepare("UPDATE breakdown_requests SET status='rejected' WHERE id=?");
        $stmt->bind_param("i", $requestId);
        $stmt->execute();
        $_SESSION['message'] = "❌ Request ID $requestId has been <strong>rejected</strong>.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// Only show pending and assigned requests
$sql = "SELECT * FROM breakdown_requests WHERE mechanic_id='" . $_SESSION['mec_id'] . "' AND status IN ('pending', 'assigned') ORDER BY request_time DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Breakdown Requests</title>
   <style>
    h2, h3 {
        text-align: center;
        color: #ff6f00;
    }

    .message {
        background: #d4edda;
        color: #155724;
        padding: 8px;
        margin: 12px auto;
        border: 1px solid #c3e6cb;
        border-radius: 5px;
        max-width: 600px;
        text-align: center;
    }

    strong {
        color: #ff6f00;
    }

    .request-card {
        background: #000;
        color: #fff;
        border-radius: 8px;
        padding: 10px;
        margin: 8px auto;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        max-width: 600px;
    }

    .request-header {
        font-weight: bold;
    }

    .info {
        margin: 4px 0;
    }

    .actions {
        margin-top: 8px;
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        justify-content: center;
    }

    .btn {
        padding: 6px 12px;
        margin-right: 6px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 0.9rem;
    }

    .accept {
        background-color: #28a745;
        color: #fff;
    }

    .reject {
        background-color: #dc3545;
        color: #fff;
    }

    .otp-popup {
        display: none;
        position: fixed;
        top: 30%;
        left: 50%;
        transform: translate(-50%, -30%);
        background: black;
        padding: 20px;
        border: 2px solid #ff6f00;
        border-radius: 10px;
        z-index: 9999;
        width: 300px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
    }

    .otp-popup h3 {
        margin-top: 0;
        text-align: center;
    }

    .otp-popup input {
        width: 100%;
        padding: 8px;
        margin: 10px 0;
    }

    .otp-popup button {
        width: 100%;
        padding: 10px;
        font-weight: bold;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .otp-popup button[type="submit"] {
        background-color: #ff6f00;
        color: white;
    }

    .otp-popup button[type="button"] {
        color: #ff6f00;
        margin-top: 8px;
    }

    .otp-debug {
        text-align: center;
        font-weight: bold;
        color: red;
        margin-top: 8px;
    }

    /* === Responsive Styling === */
    @media screen and (max-width: 600px) {
        .message,
        .request-card,
        .otp-popup {
            max-width: 90%;
            width: 90%;
            margin: 10px auto;
        }

        .actions {
            flex-direction: column;
            align-items: center;
        }

        .btn {
            width: 100%;
            margin-right: 0;
        }

        .otp-popup {
            top: 20%;
            transform: translate(-50%, -20%);
        }
    }
</style>

</head>
<body>

    <?php include 'dashboard.php'; ?>

    <div class="main">
        <h2>Breakdown Requests</h2>

        <?php if (!empty($_SESSION['message'])) : ?>
            <div class="message"><?= $_SESSION['message']; ?></div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <?php if ($result->num_rows > 0) : ?>
            <?php while ($row = $result->fetch_assoc()) : ?>
                <?php
                    $statusColor = [
                        'pending' => '#ffc107',
                        'assigned' => '#17a2b8'
                    ];
                    $currentColor = $statusColor[$row['status']] ?? '#6c757d';
                ?>
                <div class="request-card">
                    <div class="request-header" style="color: <?= $currentColor ?>;">
                        <?= htmlspecialchars($row['vehicle_type']) ?>
                    </div>
                    <div class="info"><strong>Brand:</strong> <?= htmlspecialchars($row['brand']) ?></div>
                    <div class="info"><strong>Model:</strong> <?= htmlspecialchars($row['model']) ?></div>
                    <div class="info"><strong>Location:</strong> <?= htmlspecialchars($row['location']) ?></div>
                    <div class="info"><strong>Breakdown:</strong> <?= htmlspecialchars($row['breakdown_type']) ?></div>
                    <div class="info"><strong>Contact:</strong> <?= htmlspecialchars($row['contact']) ?></div>
                    <div class="info"><strong>Time:</strong> <?= htmlspecialchars($row['request_time']) ?></div>

                    <div class="actions">
                        <?php if ($row['status'] === 'pending') : ?>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="request_id" value="<?= $row['id'] ?>">
                                <input type="hidden" name="action" value="accept">
                                <button type="submit" class="btn accept">Accept</button>
                            </form>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="request_id" value="<?= $row['id'] ?>">
                                <input type="hidden" name="action" value="reject">
                                <button type="submit" class="btn reject">Reject</button>
                            </form>
                        <?php elseif ($row['status'] === 'assigned') : ?>
                            <button class="btn accept" onclick="openOtpBox(<?= $row['id'] ?>)">Submit OTP</button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php elseif (!isset($_SESSION['message'])) : ?>
            <p style="text-align:center;">No new requests yet.</p>
        <?php endif; ?>
    </div>

    <div id="otpPopup" class="otp-popup">
        <div>
            <h3>Enter OTP</h3>
            <form method="POST">
                <div class="otp-debug" id="debugOtp"></div>
                <input type="hidden" id="otpRequestId" name="request_id" />
                <input type="text" name="otp" placeholder="Enter OTP" required />
                <input type="hidden" name="hidden_otp" id="hiddenOtp" />
                <input type="hidden" name="action" value="verify_otp" />
                <button type="submit">Submit OTP</button>
                <button type="button" onclick="closeOtpBox()">Cancel</button>
            </form>
        </div>
    </div>

    <script>
        function openOtpBox(requestId) {
            const otp = Math.floor(1000 + Math.random() * 9000);
            document.getElementById('otpRequestId').value = requestId;
            document.getElementById('hiddenOtp').value = otp;
            document.getElementById('debugOtp').innerText = "DEBUG OTP: " + otp;
            document.getElementById('otpPopup').style.display = 'block';
        }

        function closeOtpBox() {
            document.getElementById('otpPopup').style.display = 'none';
        }
    </script>
</body>
</html>
