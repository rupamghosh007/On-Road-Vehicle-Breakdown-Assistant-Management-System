<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Mechano Dashboard</title>
  <link rel="icon" type="image/jpeg" href="uploads/icon.jpg">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

  <style>
    body {
      margin: 0;
      background-color: #121212;
      color: #fff;
      font-family: Arial, sans-serif;
    }

    .navbar {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      background-color: #000;
      padding: 15px 20px;
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 1001;
    }

    .brand {
      color: #ff6f00;
      font-size: 35px;
      font-weight: bold;
      margin-left: 10px;
    }

    .menu-btn {
      font-size: 24px;
      color: #ff6f00;
      background: none;
      border: none;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0;
      left: -250px;
      width: 250px;
      height: 100vh;
      background-color: #000;
      padding-top: 60px;
      transition: left 0.3s ease;
      z-index: 1000;
      overflow-y: auto;
    }

    .sidebar.active {
      left: 0;
    }

    .sidebar .close-btn {
      position: absolute;
      top: 10px;
      right: 15px;
      font-size: 28px;
      color: #ff6f00;
      cursor: pointer;
      display: none;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
      margin-top: 30px;
    }

    .sidebar ul li a {
      display: block;
      padding: 15px 20px;
      color: #fff;
      text-decoration: none;
      transition: 0.2s;
    }

    .sidebar ul li a:hover {
      background-color: #1e1e1e;
      font-weight: bold;
    }

    .sidebar ul li a i {
      margin-right: 10px;
    }

    .main {
      margin: 0;
      padding: 90px 30px 30px 30px;
      transition: margin-left 0.3s ease;
    }

    .sidebar.active ~ .main {
      margin-left: 250px;
    }

    @media (max-width: 767px) {
      .sidebar.active ~ .main {
        margin-left: 0;
      }

      .sidebar .close-btn {
        display: block;
      }
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <div class="navbar">
    <button class="menu-btn" id="toggleSidebar"><i class="fas fa-bars"></i></button>
    <span class="brand">Mechanic Panel</span>
  </div>

  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <span class="close-btn" id="closeSidebar">&times;</span>
    <ul>
      <li><a href="#"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
      <li><a href="mec_home.php"><i class="fas fa-home"></i> Home</a></li>
      <li><a href="notification.php"><i class="fas fa-bell"></i> Notifications</a></li>
      <li><a href="breakdown.php"><i class="fas fa-tools"></i> Breakdown Request</a></li>
      <li><a href="jobhistory.php"><i class="fas fa-briefcase"></i> Job History</a></li>
      <li><a href="invoice.php"><i class="fas fa-briefcase"></i> invoice</a></li>
      <li>
        <a href="javascript:void(0)" id="settingsToggle"><i class="fas fa-cog"></i> Settings <i class="fas fa-chevron-down" style="float:right;"></i></a>
        <div class="submenu" style="display: none; background-color: #111;">
          <a href="mech_profile.php" style="padding-left: 40px;"><i class="fas fa-user-circle"></i> Profile</a>
          <a href="mech_logout.php" style="padding-left: 40px;"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </li>
    </ul>
  </div>
  
  <!-- JavaScript -->
  <script>
    const toggleBtn = document.getElementById('toggleSidebar');
    const closeBtn = document.getElementById('closeSidebar');
    const sidebar = document.getElementById('sidebar');
    const settingsToggle = document.getElementById('settingsToggle');
    const submenu = settingsToggle?.nextElementSibling;

    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('active');
    });

    closeBtn.addEventListener('click', () => {
      sidebar.classList.remove('active');
    });

    if (settingsToggle) {
      settingsToggle.addEventListener('click', () => {
        settingsToggle.classList.toggle('active');
        submenu.style.display = submenu.style.display === "block" ? "none" : "block";
      });
    }
  </script>
</body>
</html>
