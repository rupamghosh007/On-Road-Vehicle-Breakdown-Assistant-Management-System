<?php
session_start();
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "mechano";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Session Check
if (!isset($_SESSION['mec_id']) || $_SESSION['role'] != 'mechanic') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Save Invoice
if (isset($_POST['save_invoice'])) {

    // Safe variable retrieval
    $customer_name = isset($_POST['customer_name']) ? $_POST['customer_name'] : '';
    $mechanic_name = $_SESSION['user_name'];
    $mechanic_id = $_SESSION['mec_id'];
    $total_amount = isset($_POST['total_amount']) ? $_POST['total_amount'] : 0;
    $payment_method = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';

    // Insert Invoice
    $sql = "INSERT INTO invoice (customer_name, mechanic_name, total_amount, payment_method) VALUES ('$customer_name', '$mechanic_name', '$total_amount', '$payment_method')";
    if (mysqli_query($conn, $sql)) {
        $invoice_id = mysqli_insert_id($conn);

        $service_desc = isset($_POST['service_desc']) ? $_POST['service_desc'] : [];
        $service_amount = isset($_POST['service_amount']) ? $_POST['service_amount'] : [];

        if (count($service_desc) > 0 && count($service_amount) > 0) {
            for ($i = 0; $i < count($service_desc); $i++) {
                $desc = $service_desc[$i];
                $amount = $service_amount[$i];
                $sql_service = "INSERT INTO invoice_services (invoice_id, service_description, amount) VALUES ($invoice_id, '$desc', '$amount')";
                mysqli_query($conn, $sql_service);
            }
        }

        header("Location: invoice.php?invoice_id=$invoice_id");
        exit();
    } else {
        echo "Error saving invoice: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mechanic Invoice</title>
    <style>
        h1, h2 { text-align: center; color: #ff6f00; }
        table { width: 100%; border-collapse: collapse; }
        table td { padding: 8px; vertical-align: top; }
        table tr.heading td { background: #333; color: #ff6f00; font-weight: bold; }
        table tr.item td { border-bottom: 1px solid #eee; }
        .total { font-size: 18px; font-weight: bold; text-align: right; margin-top: 20px; color: #ff6f00; }
        .button-group { text-align: center; margin-top: 20px; }
        button { padding: 10px 20px; background-color: #ff6f00; color: white; border: none; cursor: pointer; }
        input, select { width: 90%; padding: 5px; }
        strong { color: #ff6f00; }
        p { color: #fff; }

        .signature-section { position: relative; width: 300px; margin-top: 50px; float: right; }
        .stamp { position: absolute; top: 0; left: 0; opacity: 0.2; transform: rotate(-20deg); z-index: 1; pointer-events: none; display: none; }
        .stamp img { width: 120px; }
        .signature { position: relative; z-index: 2; text-align: right; }
        .signature img { width: 150px; opacity: 0.9; }
        .signature p { margin-top: 0; color: #fff; font-weight: bold; }

        @media print {
            .stamp { display: block !important; }
            .signature { display: block !important; }
            .button-group { display: none !important; }
        }
    </style>
</head>
<body>

<?php include "dashboard.php"; ?>
<div class="main">
<?php if (isset($_GET['invoice_id'])) { ?>
    <?php
    $invoice_id = $_GET['invoice_id'];
    $sql_invoice = "SELECT * FROM invoice WHERE id = $invoice_id";
    $result_invoice = mysqli_query($conn, $sql_invoice);
    $row_invoice = mysqli_fetch_assoc($result_invoice);

    $sql_services = "SELECT * FROM invoice_services WHERE invoice_id = $invoice_id";
    $result_services = mysqli_query($conn, $sql_services);
    ?>

    <div class="invoice-box" id="invoice">
        <h1>INVOICE / BILL</h1>
        <h2>Invoice ID: <?php echo $row_invoice['id']; ?></h2>
        <p><strong>Customer Name:</strong> <?php echo $row_invoice['customer_name']; ?></p>
        <p><strong>Mechanic Name:</strong> <?php echo $row_invoice['mechanic_name']; ?></p>
        <p><strong>Payment Method:</strong> <?php echo $row_invoice['payment_method']; ?></p>
        <p><strong>Payment Date:</strong> <?php echo $row_invoice['payment_date']; ?></p>

        <table>
            <tr>
                <th>Service Description</th>
                <th>Amount (₹)</th>
            </tr>

            <?php while ($service = mysqli_fetch_assoc($result_services)) { ?>
                <tr>
                    <td><?php echo $service['service_description']; ?></td>
                    <td><?php echo $service['amount']; ?> ₹</td>
                </tr>
            <?php } ?>
        </table>

        <div class="total">
            Total: <?php echo $row_invoice['total_amount']; ?> ₹
        </div>

        <div class="signature-section">
            <div class="signature">
                <img src="picture/oprah-winfrey-signature-signaturely.png"" alt="Signature">
                <p>Authorized Signature</p>
            </div>
            <div class="stamp">
                <img src="picture/logologin.jpg" alt="PAID">
            </div>
        </div>

        <div class="button-group">
            <button onclick="printInvoice()">Print Invoice</button>
            <a href="invoice.php"><button type="button">Create New Invoice</button></a>
        </div>
    </div>

<?php } else { ?>
    <form method="POST" onsubmit="return validateForm()">
        <div class="invoice-box" id="invoice">
            <h1>Create Invoice</h1>

            <p><strong>Customer Name:</strong>
                <input type="text" name="customer_name" placeholder="Enter Customer Name" required>
            </p>

            <table id="serviceTable">
                <tr class="heading">
                    <td>Service Description</td>
                    <td>Amount (₹)</td>
                    <td>Action</td>
                </tr>
                <tr class="item">
                    <td><input type="text" name="service_desc[]" placeholder="Enter Service" required></td>
                    <td><input type="number" name="service_amount[]" placeholder="Enter Amount" oninput="calculateTotal()" required></td>
                    <td><button type="button" onclick="removeRow(this)">X</button></td>
                </tr>
            </table>

            <div class="button-group">
                <button type="button" onclick="addService()">Add Another Service</button>
            </div>

            <div class="total">
                Total: <span id="totalAmount">0 ₹</span>
            </div>

            <input type="hidden" name="total_amount" id="hiddenTotal">

            <p><strong>Payment Method:</strong>
                <select name="payment_method" required>
                    <option value="">Select Payment Method</option>
                    <option value="UPI">UPI</option>
                    <option value="Cash">Cash</option>
                    <option value="Debit Card">Debit Card</option>
                    <option value="Credit Card">Credit Card</option>
                </select>
            </p>

            <p><strong>Mechanic:</strong> <?php echo $_SESSION['user_name']; ?></p>
            <p><strong>Payment Date:</strong> <span id="paymentDate"></span></p>

            <div class="button-group">
                <button type="submit" name="save_invoice">Save Invoice</button>
            </div>
        </div>
    </form>
<?php } ?>
</div>

<script>
    document.getElementById('paymentDate') && (document.getElementById('paymentDate').innerText = getFormattedDateTime());

    function getFormattedDateTime() {
        const now = new Date();
        const options = { weekday: 'long' };
        const dayName = now.toLocaleDateString('en-US', options);
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();

        return `${dayName}, ${date} - ${time}`;
    }

    function addService() {
        const table = document.getElementById('serviceTable');
        const newRow = document.createElement('tr');
        newRow.classList.add('item');
        newRow.innerHTML = `
            <td><input type="text" name="service_desc[]" placeholder="Enter Service" required></td>
            <td><input type="number" name="service_amount[]" placeholder="Enter Amount" oninput="calculateTotal()" required></td>
            <td><button type="button" onclick="removeRow(this)">X</button></td>
        `;
        table.appendChild(newRow);
    }

    function removeRow(button) {
        button.parentElement.parentElement.remove();
        calculateTotal();
    }

    function calculateTotal() {
        let total = 0;
        const amounts = document.getElementsByName('service_amount[]');
        for (let i = 0; i < amounts.length; i++) {
            let value = parseFloat(amounts[i].value);
            if (!isNaN(value)) total += value;
        }
        document.getElementById('totalAmount').innerText = total + ' ₹';
        document.getElementById('hiddenTotal').value = total;
    }

    function validateForm() {
        calculateTotal();
        return true;
    }

    function printInvoice() {
        var invoiceContent = document.getElementById('invoice').innerHTML;
        var originalContent = document.body.innerHTML;

        document.body.innerHTML = invoiceContent;

        window.print();

        document.body.innerHTML = originalContent;
    }
</script>

</body>
</html>
