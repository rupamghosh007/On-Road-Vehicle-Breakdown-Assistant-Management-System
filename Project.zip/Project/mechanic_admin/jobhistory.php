<?php
session_start();

// Check if mechanic is logged in
if (!isset($_SESSION['mec_id']) || $_SESSION['role'] !== 'mechanic') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}



$mechanicId = $_SESSION['mec_id'];    
$conn = new mysqli("localhost", "root", "", "mechano");    

if ($conn->connect_error) {    
    die("Connection failed: " . $conn->connect_error);    
}    

// Fetch completed jobs grouped by month and day
$sql = "SELECT *, 
               DATE_FORMAT(request_time, '%M %Y') AS month_year, 
               DATE_FORMAT(request_time, '%d %M %Y') AS full_date 
        FROM breakdown_requests 
        WHERE mechanic_id = ? AND status = 'completed' 
        ORDER BY request_time DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $mechanicId);
$stmt->execute();
$result = $stmt->get_result();

// Grouping data
$grouped = [];
while ($row = $result->fetch_assoc()) {
    $month = $row['month_year'];
    $day = $row['full_date'];
    $grouped[$month][$day][] = $row;
}
?>

<style>
    body{
        background-color: black;
    }
    h2{
        font-family: Arial, sans-serif;
        color: #ff6f00;
        text-align: center;
    }
    h3,h4{
        color: #fff;
    }

    .month-block {
        margin-bottom: 30px;
    }

    .day-block {
        background-color:#170e0e;
        padding: 10px;
        margin-top: 10px;
        border-left: 5px solid #ff6f00;
        border-radius: 5px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    table th, table td {
        border: 1px solid #333;
        padding: 8px;
        text-align: center;
        font-family: Arial, sans-serif;
          }
          td{
            color:#fff;
          }

    th {
        background-color: #ff6f00;
        color: black;
    }

    .completed-status {
        color: green;
        font-weight: bold;
    }

    .no-data {
        
        color: #fff;
        text-align: center;
      
    }
</style>
    <?php include 'dashboard.php'; ?>
 <div class="main">
<h2>Your Job History</h2>

<?php if (!empty($grouped)) { ?>
    <?php foreach ($grouped as $month => $days) { ?>
        <div class="month-block">
            <h3><?php echo $month; ?></h3>
            <?php foreach ($days as $day => $jobs) { ?>
                <div class="day-block">
                    <h4><?php echo $day; ?></h4>
                    <table>
                        <tr>
                            <th>Sl. No</th>
                            <th>Vehicle Type</th>
                            <th>Vehicle Category</th>
                            <th>Brand</th>
                            <th>Model</th>
                            <th>Location</th>
                            <th>Breakdown Type</th>
                            <th>Contact</th>
                            <th>Request Time</th>
                            <th>Status</th>
                        </tr>
                        <?php $counter = 1; ?>
                        <?php foreach ($jobs as $row) { ?>
                            <tr>
                                <td><?php echo $counter++; ?></td>
                                <td><?php echo $row['vehicle_type']; ?></td>
                                <td><?php echo $row['vehicle_category']; ?></td>
                                <td><?php echo $row['brand']; ?></td>
                                <td><?php echo $row['model']; ?></td>
                                <td><?php echo $row['location']; ?></td>
                                <td><?php echo $row['breakdown_type']; ?></td>
                                <td><?php echo $row['contact']; ?></td>
                                <td><?php echo $row['request_time']; ?></td>
                                <td class="<?php echo $row['status'] == 'completed' ? 'completed-status' : ''; ?>">
                                    <?php echo $row['status']; ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </table>
                </div>
                </div>
            <?php } ?>
        </div>
    <?php } ?>
<?php } else { ?>
    <p class="no-data">No completed jobs found.</p>
<?php } ?>

<?php 
$stmt->close();
$conn->close(); 
?>