<?php
session_start();

// Check if mechanic is logged in
if (!isset($_SESSION['mec_id']) || $_SESSION['role'] !== 'mechanic') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}


// Fetch mechanic name from session
$mechanicName = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'Mechanic';

?>

<!DOCTYPE html>
<html>
<head>
    <title>Mechanic Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgb(7, 7, 7);
            color: #ff6600;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        
        .mechanic-name {
            color: #ff6600;
        }
        h1 {
            margin-bottom: 120%;
            font-size: 36px;
        }
        
    </style>
</head>
<body>

   <?php include 'dashboard.php'; ?>
     <div class="main">
        <div class="main">
        <h1>Welcome, <span class="mechanic-name"><?php echo htmlspecialchars($mechanicName); ?>!</span></h1></div>
     </div>
    

</body>
</html>
