<?php
session_start();

// Unset all session variables
$_SESSION = [];

// Destroy the session
session_destroy();

// Optionally clear cookies (like remember me)
setcookie("remember_email", "", time() - 3600, "/");

// Redirect to login page
header("Location: /project/user panel/signin.php");
exit();
?>