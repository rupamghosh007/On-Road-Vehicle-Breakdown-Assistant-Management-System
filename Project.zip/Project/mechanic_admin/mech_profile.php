<?php
session_start();

// Check if mechanic is logged in
if (!isset($_SESSION['mec_id']) || $_SESSION['role'] !== 'mechanic') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "mechano");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ✅ Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_SESSION['mec_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $specialization_id = intval($_POST['specialization']);
    $photo = $_FILES['photo'];

    $sql = "UPDATE mechanic SET name=?, email=?, phone=?, specializations=?";
    $params = [$name, $email, $phone, $specialization_id];
    $types = "sssi";

    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql .= ", password=?";
        $params[] = $hashed_password;
        $types .= "s";
    }

    if (!empty($photo['name'])) {
        $photoName = uniqid() . "_" . basename($photo["name"]);
        $targetDir = $_SERVER['DOCUMENT_ROOT'] . "/project/Admin pannel/uploads/";
        $targetFile = $targetDir . $photoName;
        move_uploaded_file($photo["tmp_name"], $targetFile);

        $sql .= ", photo=?";
        $params[] = $photoName;
        $types .= "s";
    }

    $sql .= " WHERE id=?";
    $params[] = $id;
    $types .= "i";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    // ✅ Redirect with success message
    header("Location: mech_profile.php?updated=1");
    exit();
}

// ✅ Fetch mechanic data
$mechanic_id = $_SESSION['mec_id'];
$sql = "SELECT m.*, s.specialization as specialization_name 
        FROM mechanic m 
        LEFT JOIN specialization s ON m.specializations = s.id 
        WHERE m.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $mechanic_id);
$stmt->execute();
$result = $stmt->get_result();
$mechanic = $result->fetch_assoc();
$stmt->close();

// ✅ Fetch all specializations
$specializations = [];
$spec_stmt = $conn->prepare("SELECT id, specialization FROM specialization");
$spec_stmt->execute();
$spec_result = $spec_stmt->get_result();
while ($row = $spec_result->fetch_assoc()) {
    $specializations[] = $row;
}
$spec_stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mechanic Profile</title>
    <style>
        body {
            background-color: #111;
            font-family: Arial, sans-serif;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .profile-card {
            background-color: #1a1a1a;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 20px #ff6a00;
            text-align: center;
            width: 400px;
            position: relative;
        }
        .profile-pic {
            width: 140px;
            height: 140px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 20px;
            border: 3px solid #ff6a00;
        }
        h2 {
            margin-bottom: 20px;
            color: #ff6a00;
        }
        .details {
            text-align: left;
            padding: 0 10px;
            font-size: 16px;
        }
        .details p {
            margin: 10px 0;
        }
        .details span {
            color: #ff6a00;
            font-weight: bold;
        }
        .edit-btn {
            margin-top: 20px;
            background-color: #ff6a00;
            color: #000;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.7);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background: #222;
            padding: 20px;
            border-radius: 12px;
            width: 400px;
            box-shadow: 0 0 20px #ff6a00;
        }
        .modal-content input,
        .modal-content select {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border-radius: 6px;
            border: none;
        }
        .modal-content button {
            background-color: #ff6a00;
            color: #000;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
        }
        label {
            color: #ff6a00;
            font-weight: bold;
        }
        #successMsg {
            display: none;
            background: #4CAF50;
            color: #fff;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 6px;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>
<body>

<?php include 'dashboard.php'; ?>

<div class="profile-card">
    <img src="/project/Admin pannel/uploads/<?= htmlspecialchars($mechanic['photo'] ?? 'default-user.png') ?>" class="profile-pic" alt="Profile Picture">
    <h2>Mechanic Profile</h2>
    <div class="details">
        <p><span>Name:</span> <?= htmlspecialchars($mechanic['name']) ?></p>
        <p><span>Email:</span> <?= htmlspecialchars($mechanic['email']) ?></p>
        <p><span>Contact:</span> <?= htmlspecialchars($mechanic['phone']) ?></p>
        <p><span>Specialization:</span> <?= htmlspecialchars($mechanic['specialization_name']) ?></p>
    </div>
    <button class="edit-btn" onclick="openModal()">Edit Profile</button>
</div>

<!-- Modal -->
<div class="modal" id="editModal">
    <div class="modal-content">
        <?php if (isset($_GET['updated'])): ?>
            <div id="successMsg">Profile updated successfully!</div>
        <?php endif; ?>

        <h3 style="text-align: center; color:#ff6a00;">Edit Profile</h3>
        <form method="POST" enctype="multipart/form-data">
            <label>Name:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($mechanic['name']) ?>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($mechanic['email']) ?>" required>

            <label>Contact Number:</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($mechanic['phone']) ?>" required>

            <label>Password:</label>
            <input type="text" name="password" placeholder="Leave blank to keep current">

            <label>Specialization:</label>
            <select name="specialization" required>
                <option value="">-- Select Specialization --</option>
                <?php foreach ($specializations as $spec): ?>
                    <option value="<?= $spec['id'] ?>" <?= ($spec['id'] == $mechanic['specializations']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($spec['specialization']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Profile Photo (optional):</label>
            <input type="file" name="photo">

            <button type="submit">Save Changes</button>
            <button type="button" onclick="closeModal()" style="margin-top:10px;">Cancel</button>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('editModal');

    function openModal() {
        modal.style.display = 'flex';
    }

    function closeModal() {
        modal.style.display = 'none';
    }

    window.addEventListener('DOMContentLoaded', () => {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('updated') === '1') {
            modal.style.display = 'flex';
            const msg = document.getElementById('successMsg');
            if (msg) msg.style.display = 'block';

            setTimeout(() => {
                window.location.href = 'mech_profile.php';
            }, 2000);
        }
    });
</script>

</body>
</html>
