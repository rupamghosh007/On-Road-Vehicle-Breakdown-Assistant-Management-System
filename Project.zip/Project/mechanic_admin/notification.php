<?php
session_start();

// Check if mechanic is logged in
if (!isset($_SESSION['mec_id']) || $_SESSION['role'] !== 'mechanic') {
    header("Location: /project/user panel/signin.php");
    exit();
}

// Session timeout (7 days = 604800 seconds)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 604800)) {
    // Session expired
    session_unset();
    session_destroy();
    header("Location: /project/user panel/signin.php");
    exit();
}




$conn = new mysqli('localhost', 'root', '', 'mechano');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$mechanic_id = $_SESSION['mec_id'];

// Handle AJAX delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['id'])) {
    $action = $_POST['action'];
    $id = intval($_POST['id']);

    if ($action === 'delete') {
        $stmt = $conn->prepare("DELETE FROM breakdown_requests WHERE id=? AND mechanic_id=?");
        $stmt->bind_param('ii', $id, $mechanic_id);
        if ($stmt->execute()) {
            echo 'success';
        } else {
            echo 'error';
        }
        $stmt->close();
    }

    $conn->close();
    exit();
}

// Fetch all notifications
$sql = "SELECT * FROM breakdown_requests WHERE mechanic_id = ? ORDER BY id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $mechanic_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Notifications</title>
    <style>
      
        h2 {
            color: #ff6600;
            text-align: center;
        }
        p {
            color: #fff;
        }
        strong {
            color: #ff6600;
        }
        .notification {
            background-color: #161010;
            padding: 15px;
            margin-bottom: 10px;
            border-left: 5px solid #ff6600;
            max-width: 50%;
            border-radius: 20px;
            position: relative;
            cursor: pointer;
        }
        .delete-text {
            color: #ff6600;
            cursor: pointer;
            position: absolute;
            bottom: 10px;
            right: 15px;
            text-decoration: underline;
        }
        .delete-text:hover {
            color: #e65c00;
        }
        .nodata {
            text-align: center;
            color: #aaa;
        }
    </style>
</head>
<body>
    <?php include 'dashboard.php'; ?>
    <div class="main">
        <h2>Your Notifications</h2>

        <div id="notifications">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="notification" id="notif_' . $row['id'] . '" onclick="goToBreakdownPage(' . $row['id'] . ')">';
                    echo '<p>You have a request for <strong>' . htmlspecialchars($row['breakdown_type']) . '</strong></p>';
                    echo '<div class="delete-text" onclick="event.stopPropagation(); deleteNotification(' . $row['id'] . ')">Delete</div>';
                    echo '</div>';
                }
            } else {
                echo '<p class="nodata">No notifications at the moment.</p>';
            }

            $stmt->close();
            $conn->close();
            ?>
        </div>
    </div>

    <script>
        function goToBreakdownPage(id) {
            window.location.href = 'breakdown.php?id=' + id;
        }

        function deleteNotification(id) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function () {
                if (xhr.status === 200 && xhr.responseText.trim() === 'success') {
                    var notif = document.getElementById('notif_' + id);
                    notif.parentNode.removeChild(notif);
                }
            };
            xhr.send('action=delete&id=' + id);
        }
    </script>
</body>
</html>