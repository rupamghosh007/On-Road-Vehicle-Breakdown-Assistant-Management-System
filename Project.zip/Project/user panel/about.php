<?php session_start() ?>
<!DOCTYPE html>
<lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Load Font Awesome with solid support -->
    <link rel="stylesheet" href="assets/css/about.css">
    <link href="https://fonts.googleapis.com/css2?family=Audiowide&display=swap" rel="stylesheet">

    
<body>
    
    <?php include "header.php"; ?>
    <div class="banner">
        <h1 style="font-size: 50px; font-family:'Audiowide', cursive;">ABOUT</h1>
        <div class="breadcrumb" style="font-size: 25px;">
            <a href="index.php">HOME</a>
           
            <span style="font-size: 30px; ">/</span>
            <a href="about.php" style="color: #fff;">About</a>

        </div>
    </div>
    
    <!-- Service Section -->
    <section class="services">
        <div class="service-card">
            <i class="fas fa-award"></i>
            <h3>Quality Servicing</h3>
            <p>Skilled hands. Reliable repairs. Trusted mechanics.</p>
            <a href="#">Read More</a>
        </div>

        <div class="service-card">
            <i class="fas fa-users-cog"></i>
            <h3>Expert Workers</h3>
            <p>Expert systems empower even non-experts to make expert-level decisions in critical vehicle failure situations.</p>
            <a href="#">Read More</a>
        </div>

        <div class="service-card">
            <i class="fas fa-tools"></i>
            <h3>Modern Equipment</h3>
            <p>Modern tools meet modern troubles— efficiently; Smart tools, faster fixes.</p>
            <a href="#">Read More</a>
        </div>
    </section>

     <!-- About Us Section -->
    <section class="about-us">
        <div class="about-us-img-container">
            <img src="usrimage/login.jpg" alt="About Us Image">
            <div class="experience-badge">
                <span>15</span>Years<br>Experience
            </div>
        </div>

        <div class="about-us-content">
            <h4 style="font-family: 'Audiowide', cursive;">// ABOUT US //</h4>
            <h2><span style="color: #ff6a00;">Mechano</span> Is The Best Place For Your Auto Care</h2>
            <p>Mechano stands at the forefront of the automotive service industry, blending reliability with cost-effectiveness for unparalleled vehicle care. We have expanded our presence across 50+ cities in India, offering comprehensive vehicle servicing solutions tailored to meet the diverse needs of our customers. Our dedicated team of over 100 skilled mechanics undergo meticulous training to ensure expertise in the latest automotive technologies.</p>

            <div class="about-point">
                <span>01</span>
                <div>
                    <strong>Professional & Expert</strong>
                    <p style="margin: 5px 0;">A professional expert sees solutions where others see problems.</p>
                </div>
            </div>

            <div class="about-point">
                <span>02</span>
                <div>
                    <strong>Quality Servicing Center</strong>
                    <p style="margin: 5px 0;">Precision, care, and speed—hallmarks of quality servicing.</p>
                </div>
            </div>

            <div class="about-point">
                <span>03</span>
                <div>
                    <strong>Awards Winning Workers</strong>
                    <p style="margin: 5px 0;">Excellence on the road, powered by award-winning hands.</p>
                </div>
            </div>

            <a href="#" class="about-btn">READ MORE →</a>
        </div>
    </section>
    <!-- counter section -->
  <section class="counter-section" id="counter-section">
    <div class="counter-container">
      <div class="counter-box">
        <i class="fas fa-check"></i>
        <h2 class="counter" data-target="15">0</h2>
        <p>Years Experience</p>
      </div>
      <div class="counter-box">
        <i class="fas fa-user-cog"></i>
        <h2 class="counter" data-target="652">0</h2>
        <p>Expert Technicians</p>
      </div>
      <div class="counter-box">
        <i class="fas fa-users"></i>
        <h2 class="counter" data-target="856">0</h2>
        <p>Satisfied Clients</p>
      </div>
      <div class="counter-box">
        <i class="fas fa-car"></i>
        <h2 class="counter" data-target="875">0</h2>
        <p>Complete Projects</p>
      </div>
    </div>
  </section>
  <!-- our mechanic section -->
<section class="technician-section animate" id="technicianSection">
  <div class="tech-header">
    <span style=" font-family: 'Audiowide', cursive;">// OUR MECHANICS //</span>
    <h2>Our Expert Technicians</h2>
  </div>


  <div class="tech-grid">
    <div class="tech-card">
      <img src="usrimage/login1.jpg" alt="Ratan Sarkar">
      <div class="tech-info">
        <h3>Ratan Sarkar</h3>
        <p>Service Mechanic</p>
      </div>
    </div>
    <div class="tech-card">
      <img src="usrimage/mechanic7.jpg" alt="Pradip Sharma">
      <div class="tech-info">
        <h3>Pradip Sharma</h3>
        <p>ASE Certified Technician</p>
      </div>
    </div>
    <div class="tech-card">
      <img src="usrimage/service-bg.jpg" alt="Montu Pal">
      <div class="tech-info">
        <h3>Montu Pal</h3>
        <p>Workshop Supervisor</p>
      </div>
    </div>
    <div class="tech-card">
      <img src="usrimage/mechanic6.jpg" alt="Sanjib Patra">
      <div class="tech-info">
        <h3>Sanjib Patra</h3>
        <p>Service Advisor</p>
      </div>
    </div>
  </div>
</section>

    <?php include "footer.php";?>
<script>
    document.addEventListener('DOMContentLoaded', () => {
            const serviceCards = document.querySelectorAll('.service-card');

            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.animationPlayState = 'running';
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.10
            });

            serviceCards.forEach(card => {
                card.style.animationPlayState = 'paused';
                observer.observe(card);
            });
        });

        document.addEventListener("DOMContentLoaded", () => {
      const counters = document.querySelectorAll(".counter");
      const boxes = document.querySelectorAll(".counter-box");
      let started = false;

      const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
          if (entry.isIntersecting && !started) {
            boxes.forEach(box => box.classList.add("active"));
            counters.forEach(counter => {
              animateCounter(counter);
            });
            started = true;
            obs.disconnect();
          }
        });
      }, {
        threshold: 0.2
      });

      observer.observe(document.querySelector("#counter-section"));

      function animateCounter(counter) {
        const target = +counter.getAttribute("data-target");
        let count = 0;
        const increment = Math.ceil(target / 100);

        function updateCount() {
          count += increment;
          if (count < target) {
            counter.textContent = count;
            requestAnimationFrame(updateCount);
          } else {
            counter.textContent = target;
          }
        }
        updateCount();
      }
    });

const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("active");
      }
    });
  }, { threshold: 0.2 });

  document.querySelectorAll('.animate').forEach(el => {
    observer.observe(el);
  });
  

</script>
</body>
</html>