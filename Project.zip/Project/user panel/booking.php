<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

if (!isset($_SESSION['user_id'])) {
    header("location:signin.php");
    exit();
}

$host = "localhost";
$user = "root";
$pass = "";
$db = "mechano";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

header('Content-Type: text/html; charset=utf-8');

// AJAX handling
if (isset($_GET['action'])) {
    header('Content-Type: application/json');
    $action = $_GET['action'];

    if ($action === 'fetch_categories') {
        $vehical_type = $_GET['vehical_type'] ?? '';
        $sql = "SELECT DISTINCT category_name FROM vehicle_category WHERE vehical_type = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $vehical_type);
        $stmt->execute();
        $result = $stmt->get_result();
        $categories = [];
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row['category_name'];
        }
        echo json_encode($categories);
        exit;
    }

    if ($action === 'fetch_brands') {
        $vehical_type = $_GET['vehical_type'] ?? '';
        $vehicle_category = $_GET['vehicle_category'] ?? '';
        $sql = "SELECT brand_name FROM brand WHERE vehical_type = ? AND vehicle_category = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $vehical_type, $vehicle_category);
        $stmt->execute();
        $result = $stmt->get_result();
        $brands = [];
        while ($row = $result->fetch_assoc()) {
            $brands[] = $row['brand_name'];
        }
        echo json_encode($brands);
        exit;
    }

    if ($action === 'fetch_models') {
        $vehical_type = $_GET['vehical_type'] ?? '';
        $vehicle_category = $_GET['vehicle_category'] ?? '';
        $brand = $_GET['brand'] ?? '';
        $sql = "SELECT model FROM vehical WHERE vehical_type = ? AND vehicle_category = ? AND brand = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $vehical_type, $vehicle_category, $brand);
        $stmt->execute();
        $result = $stmt->get_result();
        $models = [];
        while ($row = $result->fetch_assoc()) {
            $models[] = $row['model'];
        }
        echo json_encode($models);
        exit;
    }
}

// Load vehicle types
$vehicalTypes = [];
$sql = "SELECT DISTINCT vehical_type FROM vehical_type";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $vehicalTypes[] = $row['vehical_type'];
}

$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addVehical'])) {
    $vehical_type = $_POST['vehical_type'] ?? '';
    $vehicle_category = $_POST['vehicle_category'] ?? '';
    $brand = $_POST['brand'] ?? '';
    $model = $_POST['model'] ?? '';
    $location = $_POST['location'] ?? '';
    $contact = $_POST['contact'] ?? '';
    $breakdown_type = $_POST['breakdown_type'] ?? '';
    $mechanic_id = $_POST['mec_id'] ?? '';

    if ($vehical_type && $vehicle_category && $brand && $model && $location && $contact && $breakdown_type) {
        $request_time = date('Y-m-d (l) H:i:s');
        $stmt = $conn->prepare("INSERT INTO breakdown_requests (vehicle_type, vehicle_category, brand, model, location, contact, breakdown_type, mechanic_id, request_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssis", $vehical_type, $vehicle_category, $brand, $model, $location, $contact, $breakdown_type, $mechanic_id, $request_time);

        if ($stmt->execute()) {
            $success = "Vehicle request submitted successfully.";
        } else {
            $error = "Error: " . $stmt->error;
        }
    } else {
        $error = "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Breakdown Request Form</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link rel="stylesheet" href="assets/css/booking.css" />
</head>

<body class="book-body">
    <?php include "header.php"; ?>

    <div class="wrapper">
        <div class="left">
            <img src="usrimage/signup3.jpg" alt="car1" />
            <img src="usrimage/login3.jpg" alt="car2" />
            <img src="usrimage/login.jpg" alt="car3" />
            <img src="usrimage/signup1.jpg" alt="car4" />
        </div>

        <div class="right">
            <div class="break-container">
                <h2>Breakdown Request</h2>

                <?php if ($success) : ?>
                    <p class="message-text message-success"><?= htmlspecialchars($success) ?></p>
                <?php endif; ?>
                <?php if ($error) : ?>
                    <p class="message-text message-error"><?= htmlspecialchars($error) ?></p>
                <?php endif; ?>

                <form method="POST" novalidate>
                    <input type="hidden" name="mec_id" id="mec_id" value="<?php echo $_GET['mec_id'] ?>">

                    <label>Vehicle Type</label>
                    <div class="input-icon">
                        <i class="fa fa-car"></i>
                        <select name="vehical_type" id="vehical_type" required>
                            <option value="" disabled selected>Select vehicle type</option>
                            <?php foreach ($vehicalTypes as $type) : ?>
                                <option value="<?= htmlspecialchars($type) ?>"><?= htmlspecialchars($type) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <label>Vehicle Category</label>
                    <div class="input-icon">
                        <i class="fa-solid fa-truck-fast"></i>
                        <select name="vehicle_category" id="vehicle_category" required disabled>
                            <option value="" disabled selected>Select category</option>
                        </select>
                    </div>

                    <label>Brand</label>
                    <div class="input-icon">
                        <i class="fa fa-tags"></i>
                        <select name="brand" id="brand" required disabled>
                            <option value="" disabled selected>Select brand</option>
                        </select>
                    </div>

                    <label>Model</label>
                    <div class="input-icon">
                        <i class="fa fa-cogs"></i>
                        <select name="model" id="model" required disabled>
                            <option value="" disabled selected>Select model</option>
                        </select>
                    </div>

                    <label>Location</label>
                    <div class="input-icon">
                        <i class="fa fa-location-dot"></i>
                        <input class="place" type="text" name="location" placeholder="Enter location" required />
                    </div>

                    <label>Contact</label>
                    <div class="input-icon">
                        <i class="fa fa-phone"></i>
                        <input class="place" type="text" name="contact" placeholder="Enter contact number" required />
                    </div>

                    <label>Breakdown Type</label>
                    <div class="input-icon">
                        <i class="fa fa-exclamation-triangle"></i>
                        <input class="place" type="text" name="breakdown_type" placeholder="Enter breakdown type" required />
                    </div>

                    <button type="submit" name="addVehical">Submit Request</button>
                </form>

                <?php if ($success) : ?>
                <script>
                    setTimeout(function () {
                        window.location.href = 'booking1.php';
                    }, 2000);
                </script>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <?php include("footer.php"); ?>

    <script>
        function setOptions(selectEl, options) {
            selectEl.innerHTML = '<option value="" disabled selected>Select ' + selectEl.name.replace('_', ' ') + '</option>';
            options.forEach(opt => {
                const option = document.createElement('option');
                option.value = opt;
                option.textContent = opt;
                selectEl.appendChild(option);
            });
            selectEl.disabled = options.length === 0;
        }

        const vehicalType = document.getElementById('vehical_type');
        const vehicleCategory = document.getElementById('vehicle_category');
        const brand = document.getElementById('brand');
        const model = document.getElementById('model');

        vehicalType.addEventListener('change', () => {
            vehicleCategory.disabled = true;
            brand.disabled = true;
            model.disabled = true;

            setOptions(vehicleCategory, []);
            setOptions(brand, []);
            setOptions(model, []);

            if (!vehicalType.value) return;

            fetch(`?action=fetch_categories&vehical_type=${encodeURIComponent(vehicalType.value)}`)
                .then(res => res.json())
                .then(data => {
                    setOptions(vehicleCategory, data);
                });
        });

        vehicleCategory.addEventListener('change', () => {
            brand.disabled = true;
            model.disabled = true;

            setOptions(brand, []);
            setOptions(model, []);

            if (!vehicleCategory.value) return;

            fetch(`?action=fetch_brands&vehical_type=${encodeURIComponent(vehicalType.value)}&vehicle_category=${encodeURIComponent(vehicleCategory.value)}`)
                .then(res => res.json())
                .then(data => {
                    setOptions(brand, data);
                });
        });

        brand.addEventListener('change', () => {
            model.disabled = true;

            setOptions(model, []);

            if (!brand.value) return;

            fetch(`?action=fetch_models&vehical_type=${encodeURIComponent(vehicalType.value)}&vehicle_category=${encodeURIComponent(vehicleCategory.value)}&brand=${encodeURIComponent(brand.value)}`)
                .then(res => res.json())
                .then(data => {
                    setOptions(model, data);
                });
        });
    </script>
</body>
</html>
