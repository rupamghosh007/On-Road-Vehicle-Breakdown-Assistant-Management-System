<?php
session_start();
if (!isset($_SESSION['user_id'])){
    header("location:signin.php");
    exit();
}

$mysqli = new mysqli("localhost", "root", "", "mechano");

// Handle AJAX request for suggestions
if (isset($_GET['ajax']) && $_GET['ajax'] == 1 && isset($_GET['term'])) {
    $term = $mysqli->real_escape_string($_GET['term']);
    $suggestions = [];
    if ($term !== '') {
        $query = "
            SELECT DISTINCT specialization
            FROM specialization
            WHERE specialization LIKE '%$term%'
            LIMIT 10
        ";
        $result = $mysqli->query($query);
        while ($row = $result->fetch_assoc()) {
            $suggestions[] = $row['specialization'];
        }
    }
    header('Content-Type: application/json');
    echo json_encode($suggestions);
    exit;
}

// Normal search load
$search = isset($_GET['search']) ? $mysqli->real_escape_string($_GET['search']) : '';
$limit = 6;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Count total
$countQuery = "
    SELECT COUNT(DISTINCT m.id) AS total
    FROM mechanic m
    LEFT JOIN mechanic_spe_map map ON m.id = map.machenic_id
    LEFT JOIN specialization s ON s.id = map.specialization_id
";
if ($search !== '') {
    $countQuery .= " WHERE s.specialization LIKE '%$search%' ";
}
$countResult = $mysqli->query($countQuery);
$totalMechanics = $countResult->fetch_assoc()['total'];
$totalPages = ceil($totalMechanics / $limit);

// Fetch mechanics
$query = "
    SELECT 
        m.id, m.name, m.phone, m.photo, 
        GROUP_CONCAT(s.specialization SEPARATOR ', ') AS specializations,
        (
            SELECT status FROM breakdown_requests br 
            WHERE br.mechanic_id = m.id 
            ORDER BY br.id DESC LIMIT 1
        ) AS current_status
    FROM mechanic m
    LEFT JOIN mechanic_spe_map map ON m.id = map.machenic_id
    LEFT JOIN specialization s ON s.id = map.specialization_id
";
if ($search !== '') {
    $query .= " WHERE s.specialization LIKE '%$search%' ";
}
$query .= " GROUP BY m.id LIMIT $limit OFFSET $offset ";
$result = $mysqli->query($query);

$results = [];
while ($row = $result->fetch_assoc()) {
    $results[] = $row;
}

$uploadsDir = realpath(__DIR__ . '/../Admin pannel/uploads/') . DIRECTORY_SEPARATOR;
$uploadsUrl = '../Admin%20pannel/uploads/';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Search Mechanic</title>
    <link rel="stylesheet" href="assets/css/booking1.css" />
</head>
<style>





</style>
<body onload="loadNotification();">
<?php include "header.php"; ?>

<h2 style= "font-family: Audiowide, sans-serif;">Search Mechanic</h2>

<form method="GET" class="search-box" autocomplete="off">
    <div class="search-wrapper">
        <input type="text" name="search" placeholder="Enter Breakdown Type..." value="<?= htmlspecialchars($search) ?>" />
        <button type="submit">Search</button>
    </div>
    <div id="suggestions"></div>
</form>
<div id="demo"></div>
<div class="mechanic-container">
<?php if (!empty($results)): ?>
    <?php foreach ($results as $mechanic): ?>
        <div class="mechanic-card">
            <div class="mechanic-card <?php echo ($status === 'unavailable') ? 'unavailable' : ''; ?>"></div>
            <div class="mechanic-photo">
                <?php
                $photoFile = $mechanic['photo'];
                $photoFilePath = $uploadsDir . $photoFile;
                $photoUrl = $uploadsUrl . rawurlencode($photoFile);

                if (!empty($photoFile) && file_exists($photoFilePath)) {
                    echo '<img src="' . $photoUrl . '" alt="Mechanic Photo">';
                } else {
                    echo '<span>N/A</span>';
                }
                ?>
            </div>
            <div class="mechanic-info">
                <h3><?= htmlspecialchars($mechanic['name']) ?></h3>
                <p><strong>Phone:</strong> <?= htmlspecialchars($mechanic['phone']) ?></p>
                <p><strong>Specializations:</strong> <?= htmlspecialchars($mechanic['specializations']) ?></p>

                <?php
                $status = strtolower($mechanic['current_status'] ?? '');
                if ($status === 'assigned' || $status === 'pending') {
                   echo '<span class="status-unavailable" style="font-family: \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;">Currently Unavailable</span>';

                } else {
                    echo '<button class="action-btn"><a href="booking.php?mec_id=' . $mechanic['id'] . '">Book Now</a></button>';
                }
                ?>
            </div>
        </div>
    <?php endforeach; ?>
<?php elseif ($search): ?>
    <p class="centered-message">No mechanics found for "<?= htmlspecialchars($search) ?>"</p>
<?php else: ?>
    <p class="centered-message">Start typing a specialization to find mechanics.</p>
<?php endif; ?>
</div>

<?php if ($totalPages > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">&laquo; Prev</a>
        <?php endif; ?>
        Page <?= $page ?> of <?= $totalPages ?>
        <?php if ($page < $totalPages): ?>
            <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">Next &raquo;</a>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php include("footer.php");?>

<script>
const input = document.querySelector('input[name="search"]');
const suggestions = document.getElementById('suggestions');

// Listen for input
input.addEventListener('input', function () {
    const val = this.value.trim();

    if (val === '') {
        suggestions.innerHTML = '';
        suggestions.style.display = 'none';
        return;
    }

    fetch(`?ajax=1&term=${encodeURIComponent(val)}`)
        .then(response => response.json())
        .then(data => {
            if (data.length === 0) {
                suggestions.innerHTML = '';
                suggestions.style.display = 'none';
                return;
            }

            suggestions.innerHTML = data.map(item =>
                `<div class="suggestion-item">${item}</div>`
            ).join('');

            suggestions.style.display = 'block';

            document.querySelectorAll('.suggestion-item').forEach(elem => {
                elem.addEventListener('click', () => {
                    input.value = elem.textContent;
                    suggestions.innerHTML = '';
                    suggestions.style.display = 'none';
                });
            });
        });
});

// Hide suggestions when clicking outside
document.addEventListener('click', function (e) {
    if (!suggestions.contains(e.target) && e.target !== input) {
        suggestions.innerHTML = '';
        suggestions.style.display = 'none';
    }
});
var i=0;
function loadNotification() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById("demo").innerHTML = this.responseText;
     console.log("Called : "+ i++);
    }
  };
  xhttp.open("GET", "get-notification.php", true);
  xhttp.send();

  setTimeout(loadNotification,2000);
}

</script>
</body>
</html>