<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="assets/css/contact.css">
</head>

<body>
<?php include("header.php"); ?>
    <div class="banner">
        <h1 style="font-size: 50px; font-family:'Audiowide', cursive;">Contact Us</h1>
        <div class="breadcrumb" style="font-size: 30px;">
            <a href="index.php">HOME</a>
           
            <span style="font-size: 30px; ">/</span>
            <a href="contact.php" style="color: #fff;">Contact US</a>

        </div>
    </div>

    <div class="contact-heading">
       <h4 class="subheading" style="font-family: 'Audiowide', cursive; text-align: center; color: #ff6f00; font-size: 20px;">// CONTACT //</h4>
    </div>

    <div class="contact-section">
        <div class="contact-form">
            <h2>Send Us a Message</h2>
            <form action="#" method="post">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="text" name="subject" placeholder="Subject" required>
                <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
                <button type="submit">Send Message</button>
            </form>
        </div>

        <div class="contact-details">
            <h2>Contact Information</h2>
            <p><strong>Address:</strong> 123, Service Street, Kolkata, West Bengal, India</p>
            <p><strong>Phone:</strong> +91 9876543210</p>
            <p><strong>Email:</strong> support@mechano.com</p>
            <p><strong>Working Hours:</strong> We're available 24/7 – anytime, anywhere!</p>
        </div>
    </div>

   <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3683.6314912291664!2d88.36389511496062!3d22.57264698517562!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a0277a7dbbf3b07%3A0x35d292918878f3a7!2sKolkata%2C%20West%20Bengal!5e0!3m2!1sen!2sin!4v1718453244971!5m2!1sen!2sin" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>


    <div class="chatbot-icon" onclick="toggleChatbot()">
        <i class="fas fa-user-astronaut"></i>
    </div>

    <div class="chatbot-label">Hi, I am nexa</div>

    <div class="chatbot-window" id="chatbotWindow">
        <div class="chatbot-header">
            <div class="font"><i class="fas fa-user-astronaut" style="font-size: 30px;"></i> Mechano Chatbot</div>
            
        </div>
        <div class="chatbot-body" id="chatbotBody">
            <div class="chatbot-message bot">
                <div class="icon"><i class="fas fa-user-astronaut"></i></div>
                <div class="text">Hi, I am nexa! How can I assist you today?</div>
            </div>
        </div>
        <div class="chatbot-input">
            <input type="text" id="userInput" placeholder="Type your message..." onkeydown="if(event.key==='Enter') sendMessage()">
            <button onclick="startListening()" id="micButton"><i class="fas fa-microphone"></i></button>
            <button onclick="sendMessage()">Send</button>
        </div>
    </div>

    <?php include("footer.php"); ?>

   <script>
    let selectedFemaleVoice = null;
    let selectedMaleVoice = null;
    let useFemaleVoice = true;

    function loadVoices() {
        const voices = window.speechSynthesis.getVoices();
        selectedFemaleVoice = voices.find(voice => voice.name.toLowerCase().includes('zira') || voice.name.toLowerCase().includes('samantha') || voice.name.toLowerCase().includes('karen'));
        selectedMaleVoice = voices.find(voice => voice.name.toLowerCase().includes('daniel') || voice.name.toLowerCase().includes('fred') || voice.name.toLowerCase().includes('alex'));
    }

    window.speechSynthesis.onvoiceschanged = loadVoices;

    function speak(text) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'en-US';
        if (useFemaleVoice && selectedFemaleVoice) {
            utterance.voice = selectedFemaleVoice;
        } else if (!useFemaleVoice && selectedMaleVoice) {
            utterance.voice = selectedMaleVoice;
        }
        window.speechSynthesis.speak(utterance);
    }

    function toggleChatbot() {
        const chatbotWindow = document.getElementById('chatbotWindow');
        if (chatbotWindow.style.display === 'flex') {
            chatbotWindow.style.display = 'none';
        } else {
            chatbotWindow.style.display = 'flex';
            speak('Hi, I am Nexa! How can I assist you today?');
        }
    }

    function sendMessage() {
        const input = document.getElementById('userInput');
        const message = input.value.trim();
        if (message === '') return;

        addMessage('user', message);
        input.value = '';

        showTypingIndicator();

        setTimeout(() => {
            hideTypingIndicator();
            const botReply = generateBotReply(message);
            addMessage('bot', botReply);
            speak(botReply);
            showQuickReplies();
        }, 1000);
    }

    function addMessage(sender, message) {
        const chatbotBody = document.getElementById('chatbotBody');
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('chatbot-message', sender);

        const iconDiv = document.createElement('div');
        iconDiv.classList.add('icon');
        iconDiv.innerHTML = sender === 'bot' ? '<i class="fas fa-user-astronaut"></i>' : '<i class="fas fa-desktop"></i>';

        const textDiv = document.createElement('div');
        textDiv.classList.add('text');
        textDiv.innerText = message;

        if (sender === 'user') {
            messageDiv.appendChild(textDiv);
            messageDiv.appendChild(iconDiv);
        } else {
            messageDiv.appendChild(iconDiv);
            messageDiv.appendChild(textDiv);
        }

        chatbotBody.appendChild(messageDiv);
        chatbotBody.scrollTop = chatbotBody.scrollHeight;

        removeQuickReplies();
    }

    function showTypingIndicator() {
        const chatbotBody = document.getElementById('chatbotBody');
        const typingDiv = document.createElement('div');
        typingDiv.classList.add('typing-indicator');
        typingDiv.id = 'typingIndicator';
        typingDiv.innerHTML = '<span></span><span></span><span></span>';
        chatbotBody.appendChild(typingDiv);
        chatbotBody.scrollTop = chatbotBody.scrollHeight;
    }

    function hideTypingIndicator() {
        const typingDiv = document.getElementById('typingIndicator');
        if (typingDiv) typingDiv.remove();
    }

    function showQuickReplies() {
        const chatbotBody = document.getElementById('chatbotBody');
        const quickRepliesDiv = document.createElement('div');
        quickRepliesDiv.classList.add('quick-replies');
        quickRepliesDiv.id = 'quickReplies';

        const replies = ['Contact Info', 'booking', 'Change Voice', 'Help','services','location','mechanic','thanks'];
        replies.forEach(reply => {
            const button = document.createElement('button');
            button.innerText = reply;
            button.onclick = () => {
                document.getElementById('userInput').value = reply;
                sendMessage();
            };
            quickRepliesDiv.appendChild(button);
        });

        chatbotBody.appendChild(quickRepliesDiv);
        chatbotBody.scrollTop = chatbotBody.scrollHeight;
    }

    function removeQuickReplies() {
        const quickReplies = document.getElementById('quickReplies');
        if (quickReplies) quickReplies.remove();
    }

  function toggleVoice() {
    useFemaleVoice = !useFemaleVoice;
    return 'Voice was changed to ' + (useFemaleVoice ? 'female' : 'male');
}

function generateBotReply(msg) {
    msg = msg.toLowerCase();

    if (msg.includes('change voice')) {
        const voiceChangeMessage = toggleVoice(); // Only return the message, do NOT speak here
        return voiceChangeMessage; // Return the message to speak in sendMessage()
    }

    // All your other message conditions...
    if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey nexa')) return 'Hello! I am Nexa, your smart car repair assistant. How can I help you today?';
    if (msg.includes('good morning')) return 'Good Morning! How can I assist you today?';
    if (msg.includes('good afternoon')) return 'Good Afternoon! How can I help you today?';
    if (msg.includes('good evening')) return 'Good Evening! How can I help you with your car issues?';
    if (msg.includes('good night')) return 'Good Night! Feel free to contact us anytime, we are available 24/7.';

    // Asking for help
    if (msg.includes('can you help me') || msg.includes('help me') || msg.includes('need help')) return 'Of course! Please tell me your issue and I will assist you.';

    // Services
    if (msg.includes('services')) return 'We offer car repair, engine checkup, tire replacement, oil change, battery replacement, and more.';
    if (msg.includes('mechanic') || msg.includes('technician')) return 'Our certified mechanics are highly trained and experienced to handle all vehicle breakdowns efficiently.';

    // Location & Contact
    if (msg.includes('location')) return 'We are located at 123, Service Street, Kolkata, India. You can find us here: https://maps.google.com/?q=123+Service+Street+Kolkata+India';
    if (msg.includes('contact') || msg.includes('support number')) return 'You can call us at +91 9876543210 or email us at support@mechano.com';

    // Working Hours
    if (msg.includes('working hours') || msg.includes('timing')) return 'We are available 24/7 to assist you anytime!';

    // Booking
    if (msg.includes('booking') || msg.includes('appointment')) return 'You can book a mechanic by visiting our booking page or calling our support number.';

    // Pricing
    if (msg.includes('price') || msg.includes('cost') || msg.includes('charges')) return 'Our service charges depend on the type of repair. Basic services start at ₹500. Please contact us for a detailed quote.';

    // Emergency
    if (msg.includes('emergency') || msg.includes('urgent')) return 'For emergencies, please call our hotline immediately: +91 9876543210. We are available 24/7!';

    // Payment
    if (msg.includes('payment') || msg.includes('pay') || msg.includes('cash')) return 'We accept payments via cash, UPI, debit/credit cards, and online wallets.';

    // Thank you / Goodbye
    if (msg.includes('thanks') || msg.includes('thank you') || msg.includes('thank you nexa')) return 'You’re most welcome! I am always here to assist you!';
    if (msg.includes('ok bye') || msg.includes('bye')) return 'Goodbye! Drive safe and have a great day!';

    // Fun & Personality
    if (msg.includes('i love you') || msg.includes('i love baby')) return 'I love you too, baby!';
    if (msg.includes('how are you')) return 'I am just a bot, but I am always ready to assist you!';
    if (msg.includes('what is your name') || msg.includes('who are you')) return 'I am Nexa, your smart car repair assistant!';
    if (msg.includes('what can you do')) return 'I can help you with car repair information, bookings, payments, emergency support, and more!';
    if (msg.includes('who made you')) return 'I was created by the Mechano team to help you with vehicle issues anytime!';
    if (msg.includes('are you real')) return 'I am a virtual assistant, but I am real when it comes to helping you!';
    if (msg.includes('what is your purpose')) return 'My purpose is to assist you with car repairs and make your experience smooth and easy!';
    if (msg.includes('tell me a joke')) return 'Why don’t cars ever get tired? Because they come with their own set of tires!';

    // Fallback
    return "I'm sorry, I didn't understand that. Please ask about services, booking, payment, location, working hours, or contact.";
}

function sendMessage() {
    const input = document.getElementById('userInput');
    const message = input.value.trim();
    if (message === '') return;

    addMessage('user', message);
    input.value = '';

    showTypingIndicator();

    setTimeout(() => {
        hideTypingIndicator();
        const botReply = generateBotReply(message);
        addMessage('bot', botReply);
        speak(botReply); // Speak the message once here only
        showQuickReplies();
    }, 1000);
}

    // Speech Recognition
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';
    recognition.interimResults = false;

    recognition.onresult = function (event) {
        const voiceInput = event.results[0][0].transcript;
        document.getElementById('userInput').value = voiceInput;
        sendMessage();
    };

    recognition.onstart = function () {
        document.getElementById('micButton').classList.add('listening');
    };

    recognition.onend = function () {
        document.getElementById('micButton').classList.remove('listening');
    };

    function startListening() {
        recognition.start();
    }

    // Dragging Functionality
    const chatbotWindow = document.getElementById('chatbotWindow');
    const chatbotHeader = document.querySelector('.chatbot-header');
    let offsetX = 0, offsetY = 0, isDragging = false;

    chatbotHeader.addEventListener('mousedown', (e) => {
        isDragging = true;
        offsetX = e.clientX - chatbotWindow.offsetLeft;
        offsetY = e.clientY - chatbotWindow.offsetTop;
    });

    document.addEventListener('mouseup', () => { isDragging = false; });
    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            chatbotWindow.style.left = `${e.clientX - offsetX}px`;
            chatbotWindow.style.top = `${e.clientY - offsetY}px`;
            chatbotWindow.style.right = 'auto';
            chatbotWindow.style.bottom = 'auto';
        }
    });
</script>

</body>
</html>
