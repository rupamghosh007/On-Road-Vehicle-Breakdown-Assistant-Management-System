<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer | Mechano</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
   body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background-color: #111;
    color: white;
    overflow-x: hidden; /* Prevent horizontal scrolling */
}

/* Quick Navbar Styling */
.quick-navbar {
    background-color: #ff6a00;
    padding: 15px 20px;
    display: flex;
    justify-content: space-around;
    align-items: center;
}

.quick-navbar a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    padding: 5px 10px;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.quick-navbar a:hover {
    background-color: #e65c00;
}

/* Footer Background */
.footer {
    background: url('usrimage/anim1-1920x957-1.jpg') no-repeat center center/cover;
    padding: 50px 20px 20px 20px;
    color: white;
    position: relative;
    margin-top: 15px;
}

.footer::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    z-index: 1;
}

/* Footer Content Layout */
.footer-content {
    position: relative;
    z-index: 2;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    text-align: left;
    gap: 20px;
}

/* Footer Section */
.footer-section {
    flex: 1;
    margin: 20px 0;
    box-sizing: border-box;
    text-align: left;
}

/* Footer Section Headings */
.footer-section h3 {
    margin-bottom: 15px;
    color: #ff6a00;
    text-align: left;
}

/* Footer Icons */
.footer-section i {
    color: #ff6a00;
}

/* Footer Text and Links */
.footer-section p,
.footer-section a {
    margin: 4px 0;
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 10px;
    text-align: left;
    justify-content: flex-start;
}

.footer-section a:hover {
    text-decoration: underline;
}

/* Bottom Bar Styling */
.bottom-bar {
    border-top: 1px solid #555;
    padding: 10px 0;
    text-align: center;
    position: relative;
    z-index: 2;
}

.bottom-bar a {
    margin: 0 15px;
    color: white;
    text-decoration: none;
}

.bottom-bar a:hover {
    text-decoration: underline;
}

/* Scroll to Top Button */
.scroll-top {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: #ff6a00;
    color: white;
    padding: 10px 12px;
    border-radius: 50%;
    font-size: 18px;
    cursor: pointer;
    z-index: 999;
}

/* Mobile Responsive */
@media (max-width: 768px) {
    .quick-navbar {
        flex-direction: column;
        padding: 10px;
    }

    .quick-navbar a {
        padding: 5px 8px;
        font-size: 14px;
    }

    .footer-content {
        flex-wrap: wrap;
        justify-content: flex-start; /* Keep all sections aligned left */
        gap: 10px; /* Reduce gap to avoid overflow */
    }

    .footer-section {
        flex: 1 1 100%; /* Full width on mobile */
        margin: 10px 0;
        text-align: left;
    }

    .footer-section h3 {
        font-size: 18px;
    }

    .footer-section p,
    .footer-section a {
        font-size: 14px;
        text-align: left;
        justify-content: flex-start;
    }

    .bottom-bar a {
        font-size: 14px;
    }

    .scroll-top {
        padding: 8px 10px;
        font-size: 16px;
    }
}


        </style>
</head>

<body>


    <!-- Footer Section -->
    <div class="footer">
        <div class="footer-content">

            <!-- Address Section -->
            <div class="footer-section">
                <h3>Address</h3>
                <p><i class="fas fa-map-marker-alt"></i> 123, Service Street, Kolkata, West Bengal, India</p>
                <p><i class="fas fa-phone-alt"></i> +91 9876543210</p>
                <p><i class="fas fa-envelope"></i> support@mechano.com</p>
            </div>

            <!-- Opening Hours Section -->
            <div class="footer-section">
                <h3>Opening Hours</h3>
                <p><i class="fas fa-clock"></i> We're available 24/7 – anytime, anywhere!</p>
            </div>

            <!-- Services Section -->
            <div class="footer-section">
                <h3>Services</h3>
                <p><i class="fas fa-angle-right"></i> Diagnostic Test</p>
                <p><i class="fas fa-angle-right"></i> Engine Servicing</p>
                <p><i class="fas fa-angle-right"></i> Tires Replacement</p>
                <p><i class="fas fa-angle-right"></i> Oil Changing</p>
                <p><i class="fas fa-angle-right"></i> Vacuum Cleaning</p>
            </div>

            <!-- Quick Access Section -->
            <div class="footer-section" >
                <h3>Quick Access</h3>
                 <a href="index.php"><i class="fas fa-home"></i> HOME</a>
      <a href="about.php"><i class="fas fa-user"></i> ABOUT</a>
      <a href="service.php"><i class="fas fa-tools"></i> SERVICES</a>
      
        <a href="booking1.php" ><i class="fas fa-copy"></i> Booking</a>
        
       <a href="mechanics.php"><i class="fas fa-wrench"></i> Mechanic</a>
<a href="testimonial.php"><i class="fas fa-comments"></i> Testimonial</a>
        
      <a href="contact.php"><i class="fas fa-envelope"></i> CONTACT</a>
            </div>

        </div>

        <div class="bottom-bar">
            <a href="#">Home</a> |
            <a href="#">Cookies</a> |
            <a href="#">Help</a>
            <p style="margin-top: 10px;">&copy; <span id="year"></span> Mechano. All Rights Reserved.</p>
        </div>
    </div>

    <!-- Scroll to Top Button -->
    <div class="scroll-top" onclick="scrollToTop()">
        <i class="fas fa-arrow-up"></i>
    </div>

    <script>
        // Scroll to Top Function
        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }

        // Show/Hide Scroll Button
        const scrollBtn = document.querySelector('.scroll-top');

        window.addEventListener('scroll', () => {
            if (window.scrollY > 100) {
                scrollBtn.style.display = 'block';
            } else {
                scrollBtn.style.display = 'none';
            }
        });

        // Initially hide the button
        scrollBtn.style.display = 'none';

        // Dynamic Year
        document.getElementById('year').textContent = new Date().getFullYear();
    </script>

</body>

</html>
