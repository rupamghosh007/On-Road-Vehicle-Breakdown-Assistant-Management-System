<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>OTP Verification</title>
  <link rel="stylesheet" href="assets/css/otp.css"
</head>
<body>
  <div class="container">
    <div class="otp-box">
      <h2>OTP Verification</h2>
      <p class="debug-otp"><span>DEBUG OTP:</span> <span id="debug-otp"></span></p>
      <p id="countdown"></p>
      <p>Enter the code that we sent to your email<br>
        <span class="email">m***********564@gmail.com</span><br>
        Be careful not to share the code with anyone.
      </p>
      <div class="otp-inputs">
        <input type="text" maxlength="1" inputmode="numeric" pattern="[0-9]*" />
        <input type="text" maxlength="1" inputmode="numeric" pattern="[0-9]*" />
        <input type="text" maxlength="1" inputmode="numeric" pattern="[0-9]*" />
        <input type="text" maxlength="1" inputmode="numeric" pattern="[0-9]*" />
        <input type="text" maxlength="1" inputmode="numeric" pattern="[0-9]*" />
        <input type="text" maxlength="1" inputmode="numeric" pattern="[0-9]*" />
      </div>
      <p class="error-msg" id="error-msg"></p>
      <button class="verify-btn">Verify email</button>
      <p class="resend-text">Didn't get the code? <span id="resend-btn">Resend OTP</span></p>
      <a href="signup.php" class="cancel-link">Cancel</a>
      <p class="signup-text">Don’t have an account? <a href="signup.php">sign up</a> for free</p>
    </div>
    <div class="illustration"></div>
    <img src="usrimage/login1.jpg" alt="illustration">
  </div>

  <script>
    const inputs = document.querySelectorAll('.otp-inputs input');
    const debugOTPDisplay = document.getElementById('debug-otp');
    const verifyBtn = document.querySelector('.verify-btn');
    const errorMsg = document.getElementById('error-msg');
    let generatedOTP = "";
    let attempts = 0;

    function generateOTP(length = 6) {
      let otp = '';
      for (let i = 0; i < length; i++) {
        otp += Math.floor(Math.random() * 10);
      }
      return otp;
    }

    function onOtpExpire() {
      inputs.forEach(input => input.value = "");
      inputs.forEach(input => input.disabled = true);
      errorMsg.textContent = "OTP expired. Click resend.";
    }

    function setOTP() {
      generatedOTP = generateOTP();
      debugOTPDisplay.textContent = generatedOTP;
      startCountdown();
      inputs.forEach(input => {
        input.value = "";
        input.disabled = false;
      });
      errorMsg.textContent = "";
      inputs[0].focus();
    }

    function startCountdown() {
      let countdown = 30;
      const countdownEl = document.getElementById('countdown');
      clearInterval(window.otpTimer);
      countdownEl.textContent = `OTP expires in ${countdown}s`;

      window.otpTimer = setInterval(() => {
        countdown--;
        if (countdown >= 0) {
          countdownEl.textContent = `OTP expires in ${countdown}s`;
        } else {
          clearInterval(window.otpTimer);
          countdownEl.textContent = "OTP expired. Click resend.";
          generatedOTP = "";
          onOtpExpire();
        }
      }, 1000);
    }

    function checkAutoSubmit() {
      const enteredOTP = Array.from(inputs).map(input => input.value).join('');
      if (enteredOTP.length === inputs.length) {
        verifyBtn.click();
      }
    }

    inputs.forEach((input, index) => {
      input.addEventListener('input', () => {
        input.value = input.value.replace(/\D/g, '');
        if (input.value.length === 1 && index < inputs.length - 1) {
          inputs[index + 1].focus();
        }
        checkAutoSubmit();
      });

      input.addEventListener('keydown', (e) => {
        if (e.key === "Backspace" && input.value === "" && index > 0) {
          inputs[index - 1].focus();
        }
      });
    });

    inputs[0].addEventListener('paste', (e) => {
      const paste = e.clipboardData.getData('text').trim();
      if (/^\d{6}$/.test(paste)) {
        [...paste].forEach((digit, idx) => {
          if (inputs[idx]) inputs[idx].value = digit;
        });
        checkAutoSubmit();
      }
    });

    verifyBtn.addEventListener('click', () => {
      const enteredOTP = Array.from(inputs).map(input => input.value).join('');
      if (enteredOTP.length < 6) {
        errorMsg.textContent = "Please enter all 6 digits of the OTP.";
        return;
      }

      if (!generatedOTP) {
        errorMsg.textContent = "OTP expired or not generated. Please resend.";
        return;
      }

      if (enteredOTP === generatedOTP) {
        errorMsg.textContent = "";

        document.body.innerHTML = `
          <style>
            html, body {
              margin: 0;
              padding: 0;
              height: 100%;
              background: #000;
              font-family: 'Segoe UI', sans-serif;
            }

          
          </style>

          <div class="success-screen">
            <div class="spinner" id="spinner"></div>
            <div class="verifying-text">Verifying email...</div>
            <img src="usrimage/verfiytick.png" alt="Verified" class="verified-image" id="verifiedImage" />
            <h2 class="message" id="message">You are verified!</h2>
          </div>
        `;

        setTimeout(() => {
          document.getElementById('spinner').style.display = 'none';
          document.querySelector('.verifying-text').style.display = 'none';
          document.getElementById('verifiedImage').style.display = 'block';
          document.getElementById('message').style.display = 'block';
        }, 3000);

        setTimeout(() => {
          window.location.href = "reset_pass.php";
        }, 5000);
      } else {
        attempts++;
        if (attempts >= 3) {
          errorMsg.textContent = "Too many failed attempts. Try again after 30 seconds.";
          inputs.forEach(input => input.disabled = true);
          setTimeout(() => {
            attempts = 0;
            errorMsg.textContent = "";
            inputs.forEach(input => input.disabled = false);
            inputs[0].focus();
          }, 30000);
        } else {
          errorMsg.textContent = `Invalid OTP. Attempt ${attempts} of 3.`;
        }
      }
    });

    document.getElementById('resend-btn').addEventListener('click', () => {
      if (!generatedOTP) {
        setOTP();
      }
    });

    setOTP();
  </script>
</body>
</html>
