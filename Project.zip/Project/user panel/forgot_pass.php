<?php
session_start();

$host = "localhost";
$user = "root";
$password = "";
$database = "mechano";

$conn = new mysqli($host, $user, $password, $database);
$message = "";
$link = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["email"])) {
  $email = trim($_POST["email"]);

  // Check in customer table
  $stmt = $conn->prepare("SELECT * FROM customers WHERE email = ?");
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $result_customer = $stmt->get_result();

  if ($result_customer->num_rows > 0) {
    $_SESSION['email'] = $email;
    $_SESSION['role'] = 'customer';
    $link = '<a href="forgot_otp.php">Click here to enter OTP</a>';
  } else {
    // Check in mechanic table
    $stmt = $conn->prepare("SELECT * FROM mechanic WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result_mechanic = $stmt->get_result();

    if ($result_mechanic->num_rows > 0) {
      $_SESSION['email'] = $email;
      $_SESSION['role'] = 'mechanic';
      $link = '<a href="forgot_otp.php">Click here to enter OTP</a>';
    } else {
      $message = "Invalid email address";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Forgot Password</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="assets/css/forgot_pass.css" />

  
</head>
<body>
  <div class="combined-box">
    <h2>Forgot Password?</h2>
    <p>Enter your email and we’ll send you a reset link.</p>
    <form id="resetForm" method="POST">
      <div class="input-icon" title="Enter your registered email">
        <i class="fas fa-envelope"></i>
        <input type="email" name="email" placeholder="Enter your email" required aria-label="Email address"
value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" />

      </div>
      <button type="submit" class="btn-link" id="sendBtn">
        Send Reset OTP
        <i class="fas fa-spinner fa-spin spinner" id="spinner"></i>
      </button>
      <div id="confirmation" class="confirmation-message">
        <?php if ($message) echo "<span style='color:red;'>$message</span>"; ?>
        <?php if ($link) echo $link; ?>
      </div>
    </form>
    <a href="signup.php" class="back-link">Back to Sign In</a>
  </div>

  <script>
    const form = document.getElementById("resetForm");
    const spinner = document.getElementById("spinner");
    const confirmation = document.getElementById("confirmation");

    form.addEventListener("submit", function () {
      spinner.style.display = "inline-block";
      confirmation.style.display = "none";

      setTimeout(() => {
        spinner.style.display = "none";
        confirmation.style.display = "block";
      }, 1000); // Simulated delay
    });
  </script>
</body>
</html>
