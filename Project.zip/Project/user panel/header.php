<?php


// Database connection
$conn = new mysqli('localhost', 'root', '', 'mechano');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle profile fetch (AJAX)
// Handle profile fetch (AJAX)
if (isset($_GET['fetch_profile']) && $_GET['fetch_profile'] == '1') {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
        echo 'Unauthorized access.';
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $result = $conn->query("SELECT * FROM customers WHERE id = '$user_id'");

    if ($result && $row = $result->fetch_assoc()) {
        // Check if photo exists
        if (!empty($row['photo']) && file_exists('usrimage/' . $row['photo'])) {
            $photoPath = 'usrimage/' . htmlspecialchars($row['photo']);
        } else {
            // Default avatar URL
            $photoPath = 'https://www.w3schools.com/howto/img_avatar.png';
        }
echo '<img src="' . $photoPath . '" style="width:80px; height:80px; border-radius:50%; object-fit:cover; border:2px solid #ff6f00; margin-bottom:15px;">';
echo '<p><strong>Name:</strong> ' . htmlspecialchars($row['name']) . '</p>';
echo '<p><strong>Email:</strong> ' . htmlspecialchars($row['email']) . '</p>';
echo '<p><strong>Phone:</strong> ' . htmlspecialchars($row['phone']) . '</p>';
echo '<div style="margin-top: 15px; display: flex; justify-content: space-between; align-items: center;">
        <button id="edit-profile-btn" style="background-color: #0B2154; color: white; padding: 5px 10px; border-radius: 5px; border: none; cursor: pointer;">Edit Profile</button>
        <a href="custm_logout.php" style="background-color: #ff6f00; color: white; padding: 5px 10px; border-radius: 5px;font-weight:bold; text-decoration: none; display: flex; align-items: center;">
            <i class="fas fa-sign-out-alt" style="margin-right: 5px;"></i> Logout
        </a>
      </div>';

    } else {
        echo 'Profile not found.';
    }
    exit();
}


// Handle profile update (AJAX)
if (isset($_POST['update_profile'])) {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
        echo 'Unauthorized access.';
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);

    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $photo_name = time() . '_' . basename($_FILES['photo']['name']);
        $target_path = "usrimage/" . $photo_name;

        if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_path)) {
            $conn->query("UPDATE customers SET name='$name', email='$email', phone='$phone', photo='$photo_name' WHERE id='$user_id'");
        } else {
            echo 'Error uploading image.';
            exit();
        }
    } else {
        $conn->query("UPDATE customers SET name='$name', email='$email', phone='$phone' WHERE id='$user_id'");
    }

    echo 'Profile updated successfully.';
    exit();
}

// Fetch customer photo if logged in
// Fetch customer photo if logged in
$profilePhoto = '';
if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'customer') {
    $user_id = $_SESSION['user_id'];
    $result = $conn->query("SELECT photo FROM customers WHERE id = '$user_id'");
    if ($result && $row = $result->fetch_assoc()) {
        if (!empty($row['photo']) && file_exists('usrimage/' . $row['photo'])) {
            $profilePhoto = 'usrimage/' . $row['photo'];
        } else {
            // Online default avatar if photo not found
            $profilePhoto = 'https://www.w3schools.com/howto/img_avatar.png';
        }
    } else {
        // Safety fallback if query fails
        $profilePhoto = 'https://www.w3schools.com/howto/img_avatar.png';
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Mechano | Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Audiowide&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/header.css">
</head>


<style>

@media (max-width: 768px) {

    .top-bar {
        flex-direction: column;
        align-items: flex-start;
        font-size: 12px;
        gap: 5px;
    }

    .navbar {
        flex-direction: column;
        align-items: flex-start;
        padding: 10px;
    }

    .navbar-left {
        flex-direction: row;
        align-items: center;
        justify-content: flex-start;
        width: 100%;
        gap: 15px;
    }

    .navbar-left img {
        height: 60px;
        width: 60px;
    }

    .navbar-left span {
        font-size: 30px;
        text-align: center;
        width: 100%;
    }

    .navbar-left small {
        font-size: 12px;
        text-align: center;
        width: 100%;
    }

    /* ✅ Show toggle button only on mobile */
    .menu-toggle {
        display: block;
        font-size: 24px;
        color: #ff6f00;
        cursor: pointer;
    }

    /* ✅ Hide navbar by default on mobile */
    .navbar-right {
        display: none;
        flex-direction: column;
        width: 100%;
        align-items: flex-start;
        gap: 10px;
        margin-top: 15px;
    }

    /* ✅ Show navbar when toggle is clicked */
    .navbar-right.show-menu {
        display: flex;
    }

    #profile-box {
        width: 60%;
        right: 5%;
        top: 120px;
        transform: translateX(0%);
        background-color: black;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
}</style>
<body>
   <!-- Top Bar -->
<div class="top-bar">
    <div>
        <i class="fas fa-map-marker-alt"></i> 123, Service Street, Kolkata, India
        <i class="fas fa-clock"></i> We're available 24/7 – anytime, anywhere!
    </div>
    <div>
        <i class="fas fa-envelope"></i> support@mechano.com
        <i class="fas fa-phone-alt call-icon"></i> +91 9876543210
    </div>
</div>

<!-- Navbar -->
<div class="navbar">
 <!-- Logo and Heading -->
    <!-- Logo and Heading -->
<div class="navbar-left">
    <div class="menu-toggle" id="menu-toggle">
        <i class="fas fa-bars"></i>
    </div>
    <img id="logo" class="animate-logo" src="usrimage/logologin.jpg" alt="Mechano Logo">
    <div id="logo-text">
        <span id="logo-span">MECHANO</span><br>
        <small id="logo-small">Your Vehicle’s Health, Our Priority.</small>
    </div>
</div>


    <!-- Menu Items -->
    <div class="navbar-right">
        <a href="index.php"><i class="fas fa-home"></i> HOME</a>
        <a href="about.php"><i class="fas fa-user"></i> ABOUT</a>
        <a href="service.php"><i class="fas fa-tools"></i> SERVICES</a>
        <a href="booking1.php"><i class="fas fa-copy"></i> Booking</a>
        <a href="mechanics.php"><i class="fas fa-wrench"></i> Mechanic</a>
        <a href="testimonial.php"><i class="fas fa-comments"></i> Testimonial</a>
        <a href="contact.php"><i class="fas fa-envelope"></i> CONTACT</a>

        <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'customer'): ?>
            <a href="#" id="profile-icon" title="Profile">
                <img src="<?php echo $profilePhoto; ?>" alt="Profile" style="height: 40px; width: 40px; border-radius: 50%; object-fit: cover; border: 2px solid #ff6f00; cursor: pointer;">
            </a>
        <?php else: ?>
            <a href="signin.php" class="login-btn">
                <i class="fas fa-sign-in-alt"></i> SIGN IN / LOGIN
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- Profile Box -->
<div id="profile-box">
    <span id="close-profile">&times;</span>
    <div id="profile-content">Loading...</div>
</div>

    <!-- AJAX Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const profileIcon = document.getElementById('profile-icon');
            const profileBox = document.getElementById('profile-box');
            const profileContent = document.getElementById('profile-content');
            const closeProfile = document.getElementById('close-profile');

            if (profileIcon) {
                profileIcon.addEventListener('click', function (e) {
                    e.preventDefault();
                    loadProfile();
                });
            }

            closeProfile.addEventListener('click', function () {
                profileBox.style.display = 'none';
            });

            document.addEventListener('click', function (e) {
                if (!e.target.closest('#profile-box') && !e.target.closest('#profile-icon')) {
                    profileBox.style.display = 'none';
                }
            });

            function loadProfile() {
                profileBox.style.display = 'block';
                profileContent.innerHTML = 'Loading...';

                const xhr = new XMLHttpRequest();
                xhr.open('GET', '?fetch_profile=1', true);
                xhr.onload = function () {
                    if (this.status === 200) {
                        profileContent.innerHTML = this.responseText;

                        const editButton = document.getElementById('edit-profile-btn');
                        if (editButton) {
                            editButton.addEventListener('click', showEditForm);
                        }
                    } else {
                        profileContent.innerHTML = 'Error loading profile.';
                    }
                };
                xhr.send();
            }

            function showEditForm() {
                const xhr = new XMLHttpRequest();
                xhr.open('GET', '?fetch_profile=1', true);
                xhr.onload = function () {
                    if (this.status === 200) {
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(this.responseText, 'text/html');
                        const name = doc.querySelector('p:nth-of-type(1)').innerText.split(': ')[1];
                        const email = doc.querySelector('p:nth-of-type(2)').innerText.split(': ')[1];
                        const phone = doc.querySelector('p:nth-of-type(3)').innerText.split(': ')[1];

                        profileContent.innerHTML = `
                            <form id="edit-profile-form" class="profile-form" enctype="multipart/form-data">
                                <label>Name:</label>
                                <input type="text" name="name" value="${name}" required>
                                <label>Email:</label>
                                <input type="email" name="email" value="${email}" required>
                                <label>Phone:</label>
                                <input type="tel" name="phone" value="${phone}" required>
                                <label>Photo:</label>
                                <input type="file" name="photo" accept="image/*">
                                <button type="submit">Save</button>
                            </form>
                        `;

                        document.getElementById('edit-profile-form').addEventListener('submit', function (e) {
                            e.preventDefault();
                            const formData = new FormData(this);
                            formData.append('update_profile', '1');

                            const xhr = new XMLHttpRequest();
                            xhr.open('POST', '', true);
                            xhr.onload = function () {
                                if (this.status === 200) {
                                    loadProfile(); // Reload profile after update
                                } else {
                                    profileContent.innerHTML = 'Error updating profile.';
                                }
                            };
                            xhr.send(formData);
                        });
                    }
                };
                xhr.send();
            }
        });
       


document.addEventListener('DOMContentLoaded', function() {
    const logo = document.getElementById('logo');
    const span = document.getElementById('logo-span');
    const small = document.getElementById('logo-small');
    const navbarRight = document.querySelector('.navbar-right');

    // Initially hide navbar
    navbarRight.style.opacity = '0';

    // Start logo spin
    logo.classList.add('animate-logo');

    // When logo spin ends
    logo.addEventListener('animationend', () => {
        span.classList.add('animate-span');
        small.classList.add('animate-small');
    });

    // When small text animation ends, show navbar with drop animation
    small.addEventListener('animationend', () => {
        navbarRight.style.opacity = '1';
        navbarRight.classList.add('show-nav');
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.getElementById('menu-toggle');
    const navbarRight = document.querySelector('.navbar-right');

    menuToggle.addEventListener('click', function () {
        navbarRight.classList.toggle('show-menu');
    });

    // Existing logo and animation scripts remain unchanged
});

</script>






  

</body>

</html>