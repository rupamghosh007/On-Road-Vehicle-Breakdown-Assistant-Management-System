<?php session_start()?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mechanic Page</title>
    <link rel="stylesheet" href="assets/css/mechanics.css">
    <link href="https://fonts.googleapis.com/css2?family=Audiowide&display=swap" rel="stylesheet">

</head>
<style>
@media (max-width: 768px) {
    .banner {
        height: 500px;
    }

    .banner h1 {
        font-size: 36px;
    }

    cursor {
        height: 20px; /* Smaller cursor height for mobile */
        width: 2px; /* Slightly thinner cursor */
        margin-left: 3px; /* Reduce spacing */
    }

    .typewriter-container {
        flex-wrap: wrap; /* Optional: allow text to wrap if needed */
    }

    .tech-grid {
        display: flex; /* Change from grid to flex for one-line scrolling */
        overflow-x: auto; /* Enable horizontal scrolling */
        gap: 15px; /* Reduce gap between cards */
        padding-bottom: 10px; /* Add space for scrollbar */
    }

    .tech-card {
        min-width: 180px; /* Smaller card width on mobile */
        flex: 0 0 auto; /* Prevent shrinking */
    }

    .tech-card img {
        height: 150px; /* Smaller image height on mobile */
    }

    .tech-info h3 {
        font-size: 16px; /* Smaller title text */
    }

    .tech-info p {
        font-size: 14px; /* Smaller description text */
    }

    .tech-header h2 {
        font-size: 24px; /* Smaller heading */
    }
}
.tech-grid::-webkit-scrollbar {
    display: none;
}
</style>

<body>

    <?php include "header.php"; ?>

    <!-- Banner Section -->
    <div class="banner">
        <h1 style="font-size: 50px; font-family:'Audiowide', cursive;">MECHANICS</h1>
        <div class="breadcrumb" style="font-size: 25px;">
            <a href="index.php">HOME</a>
           
            <span style="font-size: 30px; ">/</span>
            <a href="mechanics.php" style="color: #fff;">Services</a>

        </div>
    </div>

    <!-- Technician Section -->
    <section class="technician-section animate" id="technicianSection">
        <div class="tech-header">
<span style="font-family: 'Audiowide', cursive;"> // OUR MECHANICS //</span>

            <h2>Our Expert Technicians</h2>
        </div>

        <div class="tech-grid">
            <div class="tech-card">
                <img src="usrimage/login1.jpg" alt="Ratan Sarkar">
                <div class="tech-info">
                    <h3>Ratan Sarkar</h3>
                    <p>Service Mechanic</p>
                </div>
            </div>

            <div class="tech-card">
                <img src="usrimage/mechanic7.jpg" alt="Pradip Sharma">
                <div class="tech-info">
                    <h3>Pradip Sharma</h3>
                    <p>ASE Certified Technician</p>
                </div>
            </div>

            <div class="tech-card">
                <img src="usrimage/service-bg.jpg" alt="Montu Pal">
                <div class="tech-info">
                    <h3>Montu Pal</h3>
                    <p>Workshop Supervisor</p>
                </div>
            </div>

            <div class="tech-card">
                <img src="usrimage/mechanic6.jpg" alt="Sanjib Patra">
                <div class="tech-info">
                    <h3>Sanjib Patra</h3>
                    <p>Service Advisor</p>
                </div>
            </div>
        </div>
    </section>

    <?php include "footer.php"; ?>

    <!-- Scroll Animation Script -->
    <script>
        // Scroll Animation
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("active");
                }
            });
        }, { threshold: 0.2 });

        document.querySelectorAll('.animate').forEach(el => {
            observer.observe(el);
        });
    </script>

</body>

</html>
