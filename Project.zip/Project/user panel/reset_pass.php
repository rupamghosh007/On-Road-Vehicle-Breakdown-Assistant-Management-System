<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "mechano";

$conn = new mysqli($host, $user, $password, $database);
$message = "";
$redirect_script = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $email = trim($_POST["email"]);
  $new_password = $_POST["new_password"];
  $confirm_password = $_POST["confirm_password"];

  if (empty($email) || empty($new_password) || empty($confirm_password)) {
    $message = "Please fill in all fields.";
  } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $message = "Please enter a valid email address.";
  } elseif ($new_password !== $confirm_password) {
    $message = "Passwords do not match.";
  } elseif (!preg_match('/^(?=.*[A-Z])(?=(?:.*\d){3,})(?=.*[\W_]).+$/', $new_password)) {
    $message = "Password must include at least 1 uppercase letter, 3 digits, and 1 special character.";
  } else {
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Check in mechanic table
    $stmt = $conn->prepare("SELECT id FROM mechanic WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
      $stmt->close();

      $update = $conn->prepare("UPDATE mechanic SET password = ? WHERE email = ?");
      $update->bind_param("ss", $hashed_password, $email);
      $update->execute();
      $update->close();

      $message = "Password changed successfully. Redirecting to sign in...";
      $redirect_script = "<script>
        setTimeout(function() {
          window.location.href = 'signin.php';
        }, 3000);
      </script>";
    } else {
      $stmt->close();

      // Check in customer table
      $stmt = $conn->prepare("SELECT id FROM customers WHERE email = ?");
      $stmt->bind_param("s", $email);
      $stmt->execute();
      $stmt->store_result();

      if ($stmt->num_rows > 0) {
        $stmt->close();

        $update = $conn->prepare("UPDATE customers SET password = ? WHERE email = ?");
        $update->bind_param("ss", $hashed_password, $email);
        $update->execute();
        $update->close();

        $message = "Password changed successfully. Redirecting to sign in...";
        $redirect_script = "<script>
          setTimeout(function() {
            window.location.href = 'signin.php';
          }, 3000);
        </script>";
      } else {
        $message = "Email not found in system.";
      }
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Reset Password</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <link rel="stylesheet" href="assets/css/reset_pass.css"/>
</head>
<body>
  <div class="container">
    <div class="image-section"></div>
    <div class="form-section">
      <h2>Reset Your Password</h2>
      <form method="POST" action="">
        <div class="input-group">
          <i class="fa-solid fa-envelope input-icon"></i>
          <input type="email" name="email" placeholder="Email Address" required />
        </div>

        <div class="input-group">
          <i class="fa-solid fa-lock input-icon"></i>
          <input type="password" name="new_password" id="new-password" placeholder="New Password" required />
          <i class="fa-solid fa-eye toggle-password" onclick="togglePassword('new-password', this)"></i>
        </div>

        <!-- Password requirements -->
        <div id="password-feedback" style="font-weight:bold; font-size:14px; margin-top:5px; margin-bottom:10px;"></div>

        <div class="input-group">
          <i class="fa-solid fa-lock input-icon"></i>
          <input type="password" name="confirm_password" id="confirm-password" placeholder="Confirm New Password" required />
          <i class="fa-solid fa-eye toggle-password" onclick="togglePassword('confirm-password', this)"></i>
        </div>

        <div class="buttons">
          <button type="submit">Save</button>
          <button type="button" class="cancel" onclick="window.location.href='forgot_pass.php'">Cancel</button>
        </div>

        <?php if (!empty($message)): ?>
          <p id="message" style="color: green; font-weight: bold; margin-top: 15px;"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>
      </form>
    </div>
  </div>

  <script>
    function togglePassword(id, icon) {
      const input = document.getElementById(id);
      if (input.type === "password") {
        input.type = "text";
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
      } else {
        input.type = "password";
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
      }
    }

    // Password live feedback
    document.addEventListener("DOMContentLoaded", function () {
      const pwd = document.getElementById("new-password");
      const feedback = document.getElementById("password-feedback");

      pwd.addEventListener("input", function () {
        const val = pwd.value;

        const hasUpper = /[A-Z]/.test(val);
        const digitCount = (val.match(/\d/g) || []).length;
        const hasThreeDigits = digitCount >= 3;
        const hasSpecial = /[\W_]/.test(val);

        const style = (cond) => cond ? "color:green;" : "color:red;";
        feedback.innerHTML = `
          Must include:
          <span style="${style(hasUpper)}"> 1 uppercase,</span>
          <span style="${style(hasThreeDigits)}"> 3 digits,</span>
          <span style="${style(hasSpecial)}"> 1 special character</span>
        `;
      });
    });
  </script>

  <?= $redirect_script ?>
</body>
</html>
