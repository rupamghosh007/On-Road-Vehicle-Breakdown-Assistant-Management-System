<?php session_start()?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Audiowide&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/service.css">
</head>
</head>

<style>

</style>

<body>
      <?php include "header.php"; ?>
        <div class="banner">
        <h1 style="font-size: 50px; font-family:'Audiowide', cursive;">SERVICES</h1>
        <div class="breadcrumb" style="font-size: 25px;">
            <a href="index.php">HOME</a>
           
            <span style="font-size: 30px; ">/</span>
            <a href="about.php" style="color: #fff;">Services</a>

        </div>
    </div>

    <section class="services-heading">
    <span class="subheading" style=" font-family: 'Audiowide', cursive; ;">// OUR SERVICES //</span>
    <h2>Explore Our Services</h2>
  </section>

<section class="services-section">
  <div class="services-tabs">
    <div class="tab active" onclick="changeService(0)"><i class="fas fa-car"></i> Diagnostic Test</div>
    <div class="tab" onclick="changeService(1)"><i class="fas fa-car-side"></i> Engine Servicing</div>
    <div class="tab" onclick="changeService(2)"><i class="fas fa-cogs"></i> Tires Replacement</div>
    <div class="tab" onclick="changeService(3)"><i class="fas fa-oil-can"></i> Oil Changing</div>
  </div>

  <div class="service-content">
    <img id="service-img" src="usrimage/service-3.jpg" alt="Service Image" />
    <h2 id="service-title">15 Years Of Experience In Auto Servicing</h2>
    <p id="service-desc">Experience isn’t just years—it’s precision in every repair. Expertise that anticipates problems before they arise.</p>
    <ul class="service-features" id="feature-list">
      <li>Quality Servicing</li>
      <li>Expert Workers</li>
      <li>Modern Equipment</li>
    </ul>
    <a href="#" class="read-more-btn">READ MORE <i class="fas fa-arrow-right"></i></a>
  </div>
</section>
<section class="hero-banner" id="heroBanner">
  <div class="banner-content">
    <h1>Certified and Award Winning Vehicle Repair Service Provider</h1>
    <p>When precision meets passion, every repair transforms into an art form. Our expert team is dedicated to reviving your ride with integrity and unrivaled expertise. Trust in excellence—because your vehicle deserves nothing less than perfection.</p>
  </div>
</section>

    


    <?php include "footer.php";?>
    <script>
        const services = [
    {
      title: "15 Years Of Experience In Auto Servicing",
      desc: "Experience isn’t just years—it’s precision in every repair. Expertise that anticipates problems before they arise.",
      img: "usrimage/mechanic6.jpg",
      features: ["Quality Servicing", "Expert Workers", "Modern Equipment"]
    },
    {
      title: "Complete Engine Diagnosis & Servicing",
      desc: "We ensure optimal engine performance and longevity with expert maintenance solutions.",
      img: "usrimage/signup3.jpg",
      features: ["Engine Check", "Oil and Filter Change", "Timing Adjustment"]
    },
    {
      title: "Professional Tires Replacement Service",
      desc: "We offer fast, reliable tire replacements with quality brands and balanced fitting.",
      img: "usrimage/service-3.jpg",
      features: ["High-Quality Tires", "Balancing & Alignment", "Safety Inspection"]
    },
    {
      title: "Reliable Oil Change Service",
      desc: "Keep your vehicle running smoothly with regular oil changes by professionals.",
      img: "usrimage/service-4.jpg",
      features: ["Premium Oils", "Fast & Clean", "Engine Protection"]
    }
  ];

  function changeService(index) {
    // Update active tab
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach((tab, i) => {
      tab.classList.toggle('active', i === index);
    });

    // Update content
    document.getElementById('service-img').src = services[index].img;
    document.getElementById('service-title').textContent = services[index].title;
    document.getElementById('service-desc').textContent = services[index].desc;

    const featureList = document.getElementById('feature-list');
    featureList.innerHTML = "";
    services[index].features.forEach(feature => {
      const li = document.createElement("li");
      li.textContent = feature;
      featureList.appendChild(li);
    });
  }
  document.addEventListener("DOMContentLoaded", function () {
    const section = document.querySelector('.services-section');

    const observer = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          section.classList.add('animate');
          observer.unobserve(entry.target); // only animate once
        }
      });
    }, {
      threshold: 0.2
    });

    observer.observe(section);
  });
  document.addEventListener("DOMContentLoaded", function () {
  const banner = document.getElementById('heroBanner');

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        banner.classList.add('animate');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  observer.observe(banner);
});

const slider = document.getElementById('testimonialSlider');
  const dots = document.querySelectorAll('.dot');
  let currentGroup = 0;
  const groupCount = document.querySelectorAll('.testimonial-group').length;

  function showGroup(index) {
    const width = document.querySelector('.testimonial-slider-wrapper').offsetWidth;
    slider.style.transform = `translateX(-${index * width}px)`;

    dots.forEach(dot => dot.classList.remove('active'));
    dots[index].classList.add('active');

    currentGroup = index;
  }

  setInterval(() => {
    let next = (currentGroup + 1) % groupCount;
    showGroup(next);
  }, 6000);

  window.addEventListener('resize', () => showGroup(currentGroup));
    </script>
</body>
</html>