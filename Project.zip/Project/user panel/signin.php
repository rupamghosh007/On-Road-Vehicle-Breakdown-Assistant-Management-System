<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$error = '';
$email = '';

// Get remembered email from cookie
if (isset($_COOKIE['remember_email'])) {
    $email = $_COOKIE['remember_email'];
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $conn = new mysqli("localhost", "root", "", "mechano");
    if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $remember = isset($_POST['remember']);

    if (!$email || !$password) {
        $error = "Please enter both email/username and password.";
    } else {
        // 1. Try customer login
        $stmt = $conn->prepare("SELECT id, name, password FROM customers WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $name, $db_pass);
            $stmt->fetch();

            if (password_verify($password, $db_pass)) {
                $_SESSION['user_id'] = $id;
                $_SESSION['user_name'] = $name;
                $_SESSION['role'] = 'customer';
                $_SESSION['login_time'] = time();

                if ($remember) {
                    setcookie("remember_email", $email, time() + (86400 * 30), "/");
                } else {
                    setcookie("remember_email", "", time() - 3600, "/");
                }

                header("Location: index.php");
                exit();
            } else {
                $error = "Incorrect password.";
            }
        } else {
            // 2. Try mechanic login
            $stmt->close();
            $stmt = $conn->prepare("SELECT id, name, password FROM mechanic WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $stmt->bind_result($id, $name, $db_pass);
                $stmt->fetch();

                if (password_verify($password, $db_pass)) {
                    $_SESSION['mec_id'] = $id;
                    $_SESSION['user_name'] = $name;
                    $_SESSION['role'] = 'mechanic';
                    $_SESSION['login_time'] = time();

                    if ($remember) {
                        setcookie("remember_email", $email, time() + (86400 * 30), "/");
                    } else {
                        setcookie("remember_email", "", time() - 3600, "/");
                    }

                    header("Location: /project/mechanic_admin/mec_home.php");
                    exit();
                } else {
                    $error = "Incorrect password.";
                }
            } else {
                // 3. Try admin login
                $stmt->close();
                $stmt = $conn->prepare("SELECT id, name, username, password FROM admin WHERE username = ?");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows > 0) {
                    $stmt->bind_result($id, $name, $username, $db_pass);
                    $stmt->fetch();

                    if (password_verify($password, $db_pass)) {
                        $_SESSION["USR"] = true;
                        $_SESSION["username"] = $username;
                        $_SESSION['role'] = 'admin';
                        $_SESSION['login_time'] = time();

                        if ($remember) {
                            setcookie("remember_email", $email, time() + (86400 * 30), "/");
                        } else {
                            setcookie("remember_email", "", time() - 3600, "/");
                        }

                        header("Location: /project/Admin pannel/admin.php");
                        exit();
                    } else {
                        $error = "Incorrect password.";
                    }
                } else {
                    $error = "Email/Username not found.";
                }
            }
        }

        $stmt->close();
    }

    $conn->close();
}
?>


<!-- Your HTML Form remains unchanged -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="assets/css/signin.css" />
</head>
<body class="login-body">
  <div class="login-container">
    <img src="usrimage/logologin.jpg" alt="Logo" />
    <h2>Login</h2>

    <div id="loading-spinner">
      <i class="fas fa-spinner"></i>
      <p>Logging in...</p>
    </div>

    <form method="POST" id="loginForm" autocomplete="on">
      <div class="input-icon">
        <i class="fas fa-user icon-left"></i>
        <input type="text" name="email" placeholder="Email or Username" value="<?= htmlspecialchars($email) ?>" required />
      </div>

      <div class="input-icon">
        <i class="icon-left fas fa-lock"></i>
        <input type="password" placeholder="Password" name="password" required />
        <i class="toggle-password fas fa-eye" onclick="togglePassword(this)"></i>
      </div>

      <div class="remember-me">
        <input type="checkbox" name="remember" id="remember" <?= isset($_COOKIE['remember_email']) ? 'checked' : '' ?>>
        <label for="remember">Remember Me</label>
      </div>

      <button type="submit" class="btn-primary">Login</button>

      <?php if (!empty($error)): ?>
        <div class="message-text"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <div class="forgot-link">
        <a href="forgot_pass.php">Forgot password?</a>
      </div>
      <div class="auth-link">
        Don’t have an account? <a href="signup.php">Sign Up</a>
      </div>
    </form>
  </div>

  <script>
    function togglePassword(icon) {
      const input = icon.previousElementSibling;
      if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
      } else {
        input.type = "password";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
      }
    }

    const form = document.getElementById("loginForm");
    const spinner = document.getElementById("loading-spinner");

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      spinner.style.display = "block";
      const btn = form.querySelector(".btn-primary");
      btn.disabled = true;
      btn.innerText = "Please wait...";

      setTimeout(() => {
        form.submit();
      }, 5000);
    })
  </script>
</body>
</html>
