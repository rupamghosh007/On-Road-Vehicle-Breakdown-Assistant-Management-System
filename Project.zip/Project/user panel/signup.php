<?php
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = new mysqli("localhost", "root", "", "mechano");
    if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

    $fullname = ucwords(strtolower(trim($_POST['fullname'] ?? '')));
    $email = strtolower(trim($_POST['email'] ?? '')); // Normalize email
    $phone = trim($_POST['phone'] ?? '');
    $pass = $_POST['password'] ?? '';
    $confirm_pass = $_POST['confirm_password'] ?? '';

    if (!$fullname || !$email || !$phone || !$pass || !$confirm_pass) {
        $error = "Please fill all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (!preg_match('/^\d{10}$/', $phone)) {
        $error = "Phone number must be exactly 10 digits.";
    } elseif ($pass !== $confirm_pass) {
        $error = "Passwords do not match.";
    } elseif (!preg_match('/^(?=.*[A-Z])(?=(?:.*\d){3,})(?=.*[\W_]).+$/', $pass)) {
        $error = "Password must include at least 1 uppercase letter, 3 digits, and 1 special character.";
    } else {
        $table = 'customers';
        $checkStmt = $conn->prepare("SELECT id FROM $table WHERE email = ?");
        $checkStmt->bind_param("s", $email);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows > 0) {
            $error = "This email is already registered.";
        } else {
            $hashed_pass = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO $table (name, email, phone, password) VALUES (?, ?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("ssss", $fullname, $email, $phone, $hashed_pass);
                if ($stmt->execute()) {
                    header("Location: otp.php");
                    exit();
                } else {
                    $error = "Error inserting user: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $error = "Prepare failed: " . $conn->error;
            }
        }
        $checkStmt->close();
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Create Account</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="assets/css/signup.css"/>
</head>
<body class="sign-body">

  <div class="sign-container">
    <img src="usrimage/logologin.jpg" alt="Logo" />
    <h2>Create Account</h2>

    <div id="loading-spinner" style="display: none;">
      <i class="fas fa-spinner fa-spin"></i>
      <span>Signing up...</span>
    </div>

    <form id="signupForm" class="signup-form" method="POST" novalidate>
      <div class="input-icon">
        <i class="fas fa-user icon-left"></i>
        <input type="text" name="fullname" id="fullname" placeholder="Full Name" required />
      </div>

      <div class="input-icon">
        <i class="fas fa-envelope icon-left"></i>
        <input type="email" name="email" id="email" placeholder="Email" required />
      </div>

      <div class="input-icon">
        <i class="fas fa-phone icon-left"></i>
        <input type="tel" name="phone" placeholder="Phone Number" pattern="[0-9]{10}" required />
      </div>

      <div class="input-icon">
        <i class="fas fa-lock icon-left"></i>
        <input type="password" id="password" name="password" placeholder="Password" required />
        <i class="toggle-password fas fa-eye" onclick="togglePassword(this)"></i>
      </div>

      <!-- Password Requirements -->
      <div id="passwordFeedback" style="margin-top: -10px; margin-bottom: 10px; font-size: 14px; font-weight: bold;"></div>

      <div class="input-icon">
        <i class="fas fa-lock icon-left"></i>
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required />
        <i class="toggle-password fas fa-eye" onclick="togglePassword(this)"></i>
      </div>

      <button type="submit" class="btn-primary">Sign Up</button>

      <?php if ($error): ?>
        <div class="message error"><?php echo htmlspecialchars($error); ?></div>
      <?php endif; ?>
      <?php if ($success): ?>
        <div class="message success"><?php echo htmlspecialchars($success); ?></div>
      <?php endif; ?>

      <p class="auth-link">
        Already have an account? <a href="signin.php">Login</a>
      </p>
    </form>
  </div>

  <script>
  function togglePassword(icon) {
    const input = icon.previousElementSibling;
    input.type = input.type === "password" ? "text" : "password";
    icon.classList.toggle("fa-eye");
    icon.classList.toggle("fa-eye-slash");
  }

  document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById("signupForm");
    const spinner = document.getElementById("loading-spinner");
    const submitBtn = form.querySelector(".btn-primary");

    // Capitalize full name on blur
    const nameInput = document.getElementById('fullname');
    nameInput.addEventListener('blur', function () {
      this.value = this.value
        .toLowerCase()
        .replace(/\b\w/g, char => char.toUpperCase());
    });

    // Lowercase email on blur
    const emailInput = document.getElementById('email');
    emailInput.addEventListener('blur', function () {
      this.value = this.value.trim().toLowerCase();
    });

    // Password validation feedback
    const passwordInput = document.getElementById('password');
    const feedback = document.getElementById('passwordFeedback');

    passwordInput.addEventListener('input', function () {
      const value = passwordInput.value;
      const hasUppercase = /[A-Z]/.test(value);
      const hasThreeDigits = (value.match(/\d/g) || []).length >= 3;
      const hasSpecialChar = /[\W_]/.test(value);

      const upperColor = hasUppercase ? 'green' : 'red';
      const digitColor = hasThreeDigits ? 'green' : 'red';
      const specialColor = hasSpecialChar ? 'green' : 'red';

      feedback.innerHTML = `
        <span style="font-weight:bold;">Must include: </span>
        <span style="color:${upperColor}; font-weight:bold;">1 uppercase</span>, 
        <span style="color:${digitColor}; font-weight:bold;">3 digits</span>, 
        <span style="color:${specialColor}; font-weight:bold;">1 special character</span>
      `;

      passwordInput.style.borderColor = (hasUppercase && hasThreeDigits && hasSpecialChar) ? 'green' : 'red';
    });

    // Submit delay with spinner
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      spinner.style.display = "block";
      submitBtn.disabled = true;
      submitBtn.innerText = "Please wait...";
      setTimeout(() => {
        form.submit();
      }, 3000);
    });
  });
  </script>

</body>
</html>
