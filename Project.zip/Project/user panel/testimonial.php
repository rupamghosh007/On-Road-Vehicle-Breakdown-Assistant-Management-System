<?php session_start()?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Testimonial Page</title>
    <link rel="stylesheet" href="assets/css/testimonial.css">
</head>
<style>
   
</style>

<body>
    <?php include "header.php"; ?>

   <div class="banner">
        <h1 style="font-size: 40px; font-family:'Audiowide', cursive;">TESTIMONIAL</h1>
        <div class="breadcrumb" style="font-size: 25px;">
            <a href="index.php">HOME</a>
           
            <span style="font-size: 30px; ">/</span>
            <a href="testimonial.php" style="color: #fff;">TESTIMONIAL</a>

        </div>
    </div>


    <div class="testimonial-heading">
        <h4 class="subheading">// TESTIMONIAL //</h4>
        <h2 class="main-heading">Our Clients Say!</h2>
    </div>

    <!-- Introductory Paragraph -->
    <div class="testimonial-paragraph">
        <p>We take pride in delivering top-notch services to our customers. Over the years, we have built lasting
            relationships and provided reliable solutions for vehicle maintenance and repairs. But don't just take our
            word for it — hear what our valued clients have to say about their experience with us!</p>
    </div>

    <div class="testimonial-slider-wrapper testimonial-section">
        <div class="testimonial-slider" id="testimonialSlider">
            <!-- Testimonials Group 1 -->
            <div class="testimonial-group">
                <div class="testimonial-card">
                    <div class="profile">
                        <img src="usrimage/user11.jpg">
                        <h3>Ramandeep Singh</h3>
                        <p>Shop Owner</p>
                    </div>
                    <blockquote>Excellent repairs and fair pricing!</blockquote>
                </div>
                <div class="testimonial-card orange">
                    <div class="profile">
                        <img src="usrimage/user10.jpg">
                        <h3 >Rana Ray</h3>
                        <p>Engineer</p>
                    </div>

                    <blockquote>Fast service and great experience overall.</blockquote>
                </div>
                <div class="testimonial-card">
                    <div class="profile">
                        <img src="usrimage/user1.jpg">
                        <h3>Minakshi Sharma</h3>
                        <p>Artist</p>
                    </div>
                    <blockquote>Loved the warranty and product quality.</blockquote>
                </div>
            </div>

            <!-- Testimonials Group 2 -->
            <div class="testimonial-group">
                <div class="testimonial-card">
                    <div class="profile">
                        <img src="usrimage/user9.jpg">
                        <h3>Raj Malhotra</h3>
                        <p>Photographer</p>
                    </div>
                    <blockquote>My scooter was fixed in no time!</blockquote>
                </div>
                <div class="testimonial-card orange">
                    <div class="profile">
                        <img src="usrimage/user2.jpg">
                        <h3>Priya Das</h3>
                        <p>Marketing Lead</p>
                    </div>
                    <blockquote>Great staff and transparent process.</blockquote>
                </div>
                <div class="testimonial-card">
                    <div class="profile">
                        <img src="usrimage/user8.jpg">
                        <h3>Amit Joshi</h3>
                        <p>Engineer</p>
                    </div>
                    <blockquote>Very professional and trustworthy.</blockquote>
                </div>
            </div>

            <!-- Testimonials Group 3 -->
            <div class="testimonial-group">
                <div class="testimonial-card">
                    <div class="profile">
                        <img src="usrimage/testimonial-4.jpg">
                        <h3>Sneha Kapoor</h3>
                        <p>Student</p>
                    </div>
                    <blockquote>Bike feels brand new!</blockquote>
                </div>
                <div class="testimonial-card orange">
                    <div class="profile">
                        <img src="usrimage/user6.jpg">
                        <h3>Mohit Batra</h3>
                        <p>Retailer</p>
                    </div>
                    <blockquote>Great paint job and affordable too.</blockquote>
                </div>
                <div class="testimonial-card">
                    <div class="profile">
                        <img src="usrimage/user3.jpg">
                        <h3>Ankita Verma</h3>
                        <p>Designer</p>
                    </div>
                    <blockquote>Creative solutions to complex issues.</blockquote>
                </div>
            </div>

            <!-- Testimonials Group 4 -->
            <div class="testimonial-group">
                <div class="testimonial-card">
                    <div class="profile">
                        <img src="usrimage/user5.jpg">
                        <h3>Kunal Sehgal</h3>
                        <p>Banker</p>
                    </div>
                    <blockquote>Super convenient and reliable.</blockquote>
                </div>
                <div class="testimonial-card orange">
                    <div class="profile">
                        <img src="usrimage/testimonial-1.jpg">
                        <h3>Ritika Sharma</h3>
                        <p>Chef</p>
                    </div>
                    <blockquote>Service was deliciously smooth!</blockquote>
                </div>
                <div class="testimonial-card">
                    <div class="profile">
                        <img src="usrimage/user7.jpg">
                        <h3>Abhay Kumar</h3>
                        <p>Mechanic</p>
                    </div>
                    <blockquote>They understand both customer and machine!</blockquote>
                </div>
            </div>
        </div>
    </div>

    <div class="dots">
        <div class="dot active" onclick="showGroup(0)"></div>
        <div class="dot" onclick="showGroup(1)"></div>
        <div class="dot" onclick="showGroup(2)"></div>
        <div class="dot" onclick="showGroup(3)"></div>
    </div>

    <?php include "footer.php"; ?>

    <script>
        const slider = document.getElementById('testimonialSlider');
        const dots = document.querySelectorAll('.dot');
        let currentGroup = 0;
        const groupCount = document.querySelectorAll('.testimonial-group').length;

        function showGroup(index) {
            const width = document.querySelector('.testimonial-slider-wrapper').offsetWidth;
            slider.style.transform = `translateX(-${index * width}px)`;

            dots.forEach(dot => dot.classList.remove('active'));
            dots[index].classList.add('active');

            currentGroup = index;
        }

        setInterval(() => {
            let next = (currentGroup + 1) % groupCount;
            showGroup(next);
        }, 6000);

        window.addEventListener('resize', () => showGroup(currentGroup));

        // Scroll animation trigger
        function onScroll() {
            const paragraph = document.querySelector('.testimonial-paragraph');
            const section = document.querySelector('.testimonial-section');
            const triggerPoint = window.innerHeight * 0.85;

            if (paragraph.getBoundingClientRect().top < triggerPoint) {
                paragraph.classList.add('animate');
            }
            if (section.getBoundingClientRect().top < triggerPoint) {
                section.classList.add('animate');
            }
        }

        window.addEventListener('scroll', onScroll);
        window.addEventListener('load', onScroll);
    </script>

</body>

</html>
